"""Small, randomly initialized portfolio Transformer; return-only first run."""
import argparse
import hashlib
import json
import random
import time

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from baseline import ASSETS, ROOT, backtest, metrics


def features(prices):
    r = prices.pct_change(fill_method=None)
    return pd.concat({'return': r, 'volatility20': r.rolling(20).std(),
                      'momentum20': prices.pct_change(20, fill_method=None)}, axis=1)


def samples(prices, mean=None, std=None):
    f = features(prices)
    if mean is None:
        fit = f.loc['2005-01-01':'2017-12-31'].dropna()
        mean, std = fit.mean(), fit.std().clip(lower=1e-8)
    z = ((f-mean)/std).to_numpy(dtype=np.float32)
    returns = prices.pct_change(fill_method=None).to_numpy(dtype=np.float32)
    x, y, dates = [], [], []
    for k in range(61, len(prices)):
        # k = return date; last input k-2; execution k-1.
        window = z[k-61:k-1]
        if prices.index[k] < pd.Timestamp('2005-01-01') or not np.isfinite(window).all():
            continue
        x.append(window)
        y.append(returns[k])
        dates.append(prices.index[k])
    return (torch.from_numpy(np.stack(x)), torch.from_numpy(np.stack(y)),
            pd.DatetimeIndex(dates), mean, std)


class PortfolioTransformer(nn.Module):
    def __init__(self, dropout=.1, n_assets=5):
        super().__init__()
        self.projection = nn.Linear(3*n_assets, 32)
        positions = torch.arange(60).unsqueeze(1)
        div = torch.exp(torch.arange(0, 32, 2) * (-np.log(10000.)/32))
        pe = torch.zeros(60, 32)
        pe[:, 0::2], pe[:, 1::2] = torch.sin(positions*div), torch.cos(positions*div)
        self.register_buffer('position', pe)
        layer = nn.TransformerEncoderLayer(32, 4, dim_feedforward=64,
                                           dropout=dropout, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=1,
                                            enable_nested_tensor=False)
        self.head = nn.Linear(32, n_assets)

    def forward(self, x):
        # Every token is already historical at the signal close; no future token.
        h = self.encoder(self.projection(x) + self.position)
        return torch.softmax(self.head(h[:, -1]), dim=-1)


def infer(model, x):
    model.eval()
    with torch.no_grad():
        return torch.cat([model(batch) for batch in x.split(128)]).numpy()


def run(epochs=10, seed=42):
    torch.set_num_threads(2)
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.use_deterministic_algorithms(True)
    data_path = ROOT / 'data/adjusted_close.csv'
    # Exclude final-test rows before any feature calculation or training.
    prices = pd.read_csv(data_path, index_col=0, parse_dates=True).loc[:'2020-12-31', ASSETS]
    x, y, dates, mean, std = samples(prices)
    train = dates <= pd.Timestamp('2017-12-31')
    valid = dates >= pd.Timestamp('2018-01-01')
    train_x, train_y = x[train], y[train]
    val_x, val_dates = x[valid], dates[valid]
    loader = DataLoader(TensorDataset(train_x, train_y), batch_size=128,
                        shuffle=True, generator=torch.Generator().manual_seed(seed))
    model = PortfolioTransformer()
    optimizer = torch.optim.Adam(model.parameters(), lr=.001)
    out = ROOT / 'outputs' / f'transformer_seed{seed}'
    out.mkdir(parents=True, exist_ok=True)
    config = dict(seed=seed, epochs=epochs, device='cpu', torch_version=str(torch.__version__),
                  assets=ASSETS, feature_order=[list(c) for c in mean.index],
                  model='TransformerEncoder', d_model=32, heads=4, layers=1,
                  feedforward=64, dropout=.1, window=60, pooling='last token',
                  optimizer='Adam', learning_rate=.001, batch_size=128,
                  objective='negative mean daily gross return; no risk or turnover penalty',
                  pretrained=False, parameter_count=sum(p.numel() for p in model.parameters()),
                  train_samples=int(train.sum()), validation_samples=int(valid.sum()),
                  train_first=str(dates[train][0].date()), train_last=str(dates[train][-1].date()),
                  validation_first=str(val_dates[0].date()), validation_last=str(val_dates[-1].date()),
                  checkpoint_selection='maximum validation net Sharpe at 10 bps across fixed epoch budget',
                  data_sha256=hashlib.sha256(data_path.read_bytes()).hexdigest())
    (out / 'config.json').write_text(json.dumps(config, indent=2))
    pd.DataFrame({'mean': mean, 'std': std}).to_csv(out / 'scaler.csv')
    history, best = [], -np.inf
    begin = time.time()
    for epoch in range(1, epochs+1):
        model.train()
        total = 0.
        for bx, by in loader:
            optimizer.zero_grad()
            loss = -(model(bx)*by).sum(dim=1).mean()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.)
            optimizer.step()
            total += loss.item()*len(bx)
        weights = pd.DataFrame(infer(model, val_x), index=val_dates, columns=ASSETS)
        frame = backtest(prices, 'Transformer', supplied_weights=weights)
        score = metrics(frame)
        history.append(dict(epoch=epoch, train_loss=total/len(train_x), **score))
        if score['net_sharpe_zero_rf'] > best:
            best, best_epoch = score['net_sharpe_zero_rf'], epoch
            torch.save({'state_dict': model.state_dict(), 'config': config,
                        'scaler_mean': mean.to_numpy().tolist(),
                        'scaler_std': std.to_numpy().tolist(), 'epoch': epoch}, out / 'best.pt')
        print(f'Epoch {epoch}/{epochs}: train loss {total/len(train_x):.6f}; '
              f'validation net Sharpe {score["net_sharpe_zero_rf"]:.3f}', flush=True)
    pd.DataFrame(history).to_csv(out / 'training_history.csv', index=False)
    checkpoint = torch.load(out / 'best.pt', weights_only=True)
    model.load_state_dict(checkpoint['state_dict'])
    weights = pd.DataFrame(infer(model, val_x), index=val_dates, columns=ASSETS)
    weights.to_csv(out / 'validation_weights.csv')
    summaries, frames = [], {}
    for method in ['Equal Weight', 'Minimum Variance', 'Transformer']:
        for cost in [0, 5, 10, 20]:
            frame = backtest(prices, method, cost_bps=cost,
                             supplied_weights=weights if method == 'Transformer' else None)
            summaries.append(dict(method=method, cost_bps=cost, **metrics(frame)))
            if method == 'Transformer':
                frame.to_csv(out / f'validation_{cost}bps.csv')
            if cost == 10:
                frames[method] = frame
    summary = pd.DataFrame(summaries)
    summary.to_csv(out / 'comparison.csv', index=False)
    config.update(best_epoch=best_epoch, runtime_seconds=time.time()-begin)
    (out / 'config.json').write_text(json.dumps(config, indent=2))
    plot(frames, weights, out, seed)
    print(summary[summary.cost_bps == 10].to_string(index=False), flush=True)
    print(f'Selected epoch {best_epoch}; runtime {time.time()-begin:.1f}s', flush=True)


def plot(frames, weights, out, seed):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True)
    for method, frame in frames.items():
        nav = pd.concat([pd.Series([1.], index=[frame.execution_date.iloc[0]]), frame.net_value])
        axes[0].plot(nav.index, nav, label=method)
        axes[1].plot(frame.index, -100*frame.drawdown, label=method)
    axes[0].set(title=f'Preliminary validation 2018–2020 | 10 bps | Transformer seed {seed}', ylabel='Net value')
    axes[1].set(ylabel='Drawdown (%)')
    axes[2].stackplot(weights.index, weights.to_numpy().T, labels=ASSETS, alpha=.85)
    axes[2].set(ylabel='Transformer allocation', ylim=(0, 1), xlabel='Return date')
    for ax in axes:
        ax.grid(alpha=.2)
        ax.legend(loc='upper left', ncol=3)
    fig.tight_layout()
    fig.savefig(out / 'validation_comparison.png', dpi=160)
    plt.close(fig)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--epochs', type=int, default=10)
    p.add_argument('--seed', type=int, default=42)
    args = p.parse_args()
    if args.epochs < 1:
        p.error('epochs must be positive')
    run(args.epochs, args.seed)
