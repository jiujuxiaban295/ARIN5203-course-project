"""Performance metrics and paired studentized circular-block inference.

Sharpe annualization assumes 252 daily trading periods. Statistical intervals
use a HAC delta-method standard error of the difference in Sharpe ratios,
recomputed in every bootstrap draw. This is an explicitly specified
studentized circular-block procedure; it is not a reproduction of the full
Ledoit--Wolf automatic block-length selection algorithm. Block length must be
chosen before test-set inspection. Random training seeds do not create
independent market histories and are never concatenated as observations.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def _array(value, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=float)
    if result.ndim != 1 or not np.isfinite(result).all():
        raise ValueError(f"{name} must be a finite one-dimensional series.")
    return result


def _aligned_rf(returns, risk_free) -> np.ndarray:
    if risk_free is None:
        return np.zeros(len(returns), dtype=float)
    if isinstance(returns, pd.Series) and isinstance(risk_free, pd.Series):
        if not returns.index.equals(risk_free.index):
            raise ValueError("Returns and risk-free series must have identical ordered dates.")
    rf = _array(risk_free, "risk_free")
    if len(rf) != len(returns):
        raise ValueError("Risk-free and return series must have equal lengths.")
    return rf


def sharpe(returns, risk_free=None, periods_per_year: int = 252) -> float:
    r = _array(returns, "returns")
    excess = r - _aligned_rf(returns, risk_free)
    if len(excess) < 2 or excess.std(ddof=1) <= 1e-15:
        return float("nan")
    return float(np.sqrt(periods_per_year) * excess.mean() / excess.std(ddof=1))


def summarize(
    result: pd.DataFrame,
    risk_free: pd.Series | np.ndarray | None = None,
    periods_per_year: int = 252,
) -> dict:
    """Summarize daily net returns; RF must cover exactly these return dates."""
    if "net_return" not in result or result.empty:
        raise ValueError("A nonempty backtest frame with net_return is required.")
    returns = result["net_return"]
    r = _array(returns, "net_return")
    rf = _aligned_rf(returns, risk_free)
    if (r <= -1).any():
        raise ValueError("Returns must be greater than -1.")
    wealth = np.cumprod(1 + r)
    running_peak = np.maximum.accumulate(np.concatenate(([1.0], wealth)))[1:]
    turnover = _array(result["turnover"], "turnover") if "turnover" in result else np.zeros(len(r))
    costs = _array(result["cost"], "cost") if "cost" in result else np.zeros(len(r))
    trades = int(np.count_nonzero(turnover > 1e-12))
    return {
        "n_days": int(len(r)),
        "total_net_return": float(wealth[-1] - 1),
        "annualized_net_return": float(np.exp(np.log1p(r).sum() * periods_per_year / len(r)) - 1),
        "annualized_volatility": float(np.std(r, ddof=1) * np.sqrt(periods_per_year)) if len(r) > 1 else float("nan"),
        "net_sharpe": sharpe(r, rf, periods_per_year),
        "max_drawdown": float(np.min(wealth / running_peak - 1)),
        "average_daily_turnover": float(turnover.mean()),
        "average_rebalance_turnover": float(turnover.sum() / trades) if trades else 0.0,
        "annualized_turnover": float(turnover.sum() * periods_per_year / len(r)),
        "total_cost_fractions": float(costs.sum()),
        "n_trades": trades,
        "rf_assumption": "zero" if risk_free is None else "provided lagged daily risk-free returns",
    }


def _sharpe_influence(x: np.ndarray, annualization: float) -> np.ndarray:
    centered = x - x.mean()
    variance = np.mean(centered**2)
    if variance <= 1e-24:
        raise ValueError("Sharpe inference requires nonzero excess-return variance.")
    sigma = np.sqrt(variance)
    return annualization * (centered / sigma - x.mean() * (centered**2 - variance) / (2 * sigma**3))


def _hac_se(x: np.ndarray, y: np.ndarray, max_lag: int, annualization: float) -> float:
    influence = _sharpe_influence(x, annualization) - _sharpe_influence(y, annualization)
    influence -= influence.mean()
    n = len(influence)
    lrv = float(influence @ influence / n)
    for lag in range(1, max_lag + 1):
        covariance = float(influence[lag:] @ influence[:-lag] / n)
        lrv += 2 * (1 - lag / (max_lag + 1)) * covariance
    return float(np.sqrt(max(lrv, 0) / n))


def paired_sharpe_bootstrap(
    a,
    b,
    rf=None,
    n_boot: int = 999,
    block_length: int = 20,
    seed: int = 42,
    confidence: float = 0.95,
    periods_per_year: int = 252,
    hac_lags: int | None = None,
) -> dict:
    """CI for annualized Sharpe(a)-Sharpe(b), preserving paired daily blocks.

    Circular blocks of ``block_length`` wrap around each observed series.
    Both returns and contemporaneous RF use identical sampled indices. The
    studentized statistic centers each resampled difference on the observed
    difference, and the confidence interval inverts its quantiles. P-values
    use a centered, two-sided bootstrap-t test with a +1 finite-draw correction.
    """
    if isinstance(a, pd.Series) and isinstance(b, pd.Series) and not a.index.equals(b.index):
        raise ValueError("Paired return series must have identical ordered dates.")
    av, bv = _array(a, "a"), _array(b, "b")
    if len(av) != len(bv) or len(av) < 32:
        raise ValueError("Paired inference requires equal lengths and at least 32 daily observations.")
    if not isinstance(n_boot, int) or n_boot < 99:
        raise ValueError("n_boot must be an integer of at least 99.")
    n = len(av)
    if not isinstance(block_length, int) or not 1 <= block_length < n:
        raise ValueError("block_length must be an integer in [1, n).")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be in (0, 1).")
    lag = block_length - 1 if hac_lags is None else hac_lags
    if not isinstance(lag, int) or not 0 <= lag < n:
        raise ValueError("hac_lags must be an integer in [0, n).")
    rf_values = _aligned_rf(a, rf)
    x, y = av - rf_values, bv - rf_values
    annualization = float(np.sqrt(periods_per_year))
    estimate = sharpe(x, periods_per_year=periods_per_year) - sharpe(y, periods_per_year=periods_per_year)
    if not np.isfinite(estimate):
        raise ValueError("Sharpe inference requires nonzero excess-return variance.")
    se = _hac_se(x, y, lag, annualization)
    metadata = {
        "sharpe_difference": float(estimate),
        "confidence": float(confidence),
        "n_observations": n,
        "n_boot": n_boot,
        "block_length": block_length,
        "hac_lags": lag,
        "seed": seed,
        "method": "paired studentized circular-block bootstrap; Bartlett HAC delta-method SE",
    }
    if se <= 1e-14:
        if np.allclose(x, y, atol=1e-15, rtol=0):
            return {**metadata, "ci_low": 0.0, "ci_high": 0.0, "p_value": 1.0, "standard_error": 0.0, "valid_bootstrap_draws": n_boot}
        raise ValueError("Degenerate Sharpe-difference standard error; studentization is undefined.")
    rng = np.random.default_rng(seed)
    blocks = int(np.ceil(n / block_length))
    offsets = np.arange(block_length)
    t_values = []
    for _ in range(n_boot):
        starts = rng.integers(0, n, size=blocks)
        indices = ((starts[:, None] + offsets) % n).ravel()[:n]
        xb, yb = x[indices], y[indices]
        delta = sharpe(xb, periods_per_year=periods_per_year) - sharpe(yb, periods_per_year=periods_per_year)
        seb = _hac_se(xb, yb, lag, annualization)
        if seb > 1e-14 and np.isfinite(delta):
            t_values.append((delta - estimate) / seb)
    if len(t_values) < 0.9 * n_boot:
        raise ValueError("Too many degenerate bootstrap draws for a reliable studentized interval.")
    t_values = np.asarray(t_values)
    alpha = (1 - confidence) / 2
    low_t, high_t = np.quantile(t_values, [alpha, 1 - alpha])
    p_value = (1 + np.count_nonzero(np.abs(t_values) >= abs(estimate / se))) / (1 + len(t_values))
    return {
        **metadata,
        "ci_low": float(estimate - high_t * se),
        "ci_high": float(estimate - low_t * se),
        "p_value": float(p_value),
        "standard_error": float(se),
        "valid_bootstrap_draws": int(len(t_values)),
    }
