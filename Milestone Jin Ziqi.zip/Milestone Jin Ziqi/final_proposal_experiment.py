"""Six assets, weekly next-open execution, FRED excess Sharpe. Validation only."""
import hashlib
import itertools
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from baseline import ROOT, target_weights
from transformer_baseline import PortfolioTransformer, features, infer
from transformer_ablation import objective

ASSETS=['SPY','EFA','EEM','IEF','TLT','GLD']
DATA=ROOT/'data/final_proposal'
OUT=ROOT/'outputs/final_proposal'
SEEDS=[42,43,44]
GRIDS={'Return only':[(0.,0.)], 'Risk':[(1.,0.),(5.,0.)],
       'Turnover':[(0.,.001),(0.,.005)],
       'Risk + Turnover':list(itertools.product([1.,5.],[.001,.005]))}


def weekly_samples(close, opening):
    f=features(close)
    fit=f.loc['2006':'2017'].dropna()
    mean,std=fit.mean(),fit.std().clip(lower=1e-8)
    z=((f-mean)/std).to_numpy(dtype=np.float32)
    # First available session of each Monday-Sunday week; previous close is signal.
    periods=close.index.to_period('W-SUN')
    starts=np.flatnonzero(~periods.duplicated())
    x,y,rows=[],[],[]
    for s,e in zip(starts[:-1],starts[1:]):
        if s<60 or not np.isfinite(z[s-60:s]).all(): continue
        ds,de=close.index[s],close.index[e]
        split=None
        for name,a,b in [('train','2006-01-01','2017-12-31'),('validation','2018-01-01','2020-12-31')]:
            if pd.Timestamp(a)<=ds and de<=pd.Timestamp(b): split=name
        if split is None: continue
        x.append(z[s-60:s]); y.append((opening.iloc[e]/opening.iloc[s]-1).to_numpy())
        rows.append(dict(start=s,end=e,signal_date=close.index[s-1],execution_date=ds,
                         holding_end=de,split=split))
    return torch.tensor(np.stack(x)),torch.tensor(np.stack(y),dtype=torch.float32),pd.DataFrame(rows),mean,std


def rf_returns(index, rates):
    rates=rates.dropna().sort_index()
    rows=[]
    for a,b in zip(index[:-1],index[1:]):
        eligible=rates.loc[rates.index<a]
        if eligible.empty: raise ValueError('Missing prior DTB3 observation')
        d=float(eligible.iloc[-1])/100
        # DTB3 is bank-discount yield. Explicit 91-day constant maturity proxy.
        price=1-d*91/360
        rows.append(dict(start=a,end=b,rate_date=eligible.index[-1],dtb3_percent=d*100,
                         rf_return=(1/price)**((b-a).days/91)-1))
    return pd.DataFrame(rows).set_index('start')


def backtest_weekly(opening, schedule, weights, rf, cost_bps=10):
    w=np.asarray(weights,dtype=float)
    if w.shape!=(len(schedule),6) or not np.isfinite(w).all() or (w<0).any() or not np.allclose(w.sum(1),1,atol=1e-6):
        raise ValueError('Invalid weekly weights')
    pre=np.ones(6)/6
    rows=[]
    last_end=None
    for (_,week),target in zip(schedule.iterrows(),w):
        s,e=int(week.start),int(week.end)
        if last_end is not None and s!=last_end: raise ValueError('Noncontiguous evaluation schedule')
        for j in range(s,e):
            turnover=np.abs(target-pre).sum() if j==s else 0.
            holding=target.copy() if j==s else pre.copy()
            r=(opening.iloc[j+1]/opening.iloc[j]-1).to_numpy()
            gross=holding@r
            cost=cost_bps/10000*turnover
            rate=rf.loc[opening.index[j]]
            row=dict(date=opening.index[j+1],period_start=opening.index[j],
                     signal_date=week.signal_date,execution_date=week.execution_date,
                     gross_return=gross,net_return=gross-cost,cost=cost,turnover=turnover,
                     rf_return=rate.rf_return,rf_rate_date=rate.rate_date,rebalanced=j==s)
            row.update({f'weight_{a}':v for a,v in zip(ASSETS,holding)})
            rows.append(row)
            pre=holding*(1+r)/(1+gross)
        last_end=e
    frame=pd.DataFrame(rows).set_index('date')
    frame['net_value']=(1+frame.net_return).cumprod()
    frame['drawdown']=1-frame.net_value/frame.net_value.cummax().clip(lower=1)
    return frame


def metric(frame):
    r=frame.net_return
    ex=r-frame.rf_return
    return dict(days=len(r),annualized_net_return=frame.net_value.iloc[-1]**(252/len(r))-1,
                annualized_volatility=r.std(ddof=1)*np.sqrt(252),
                net_sharpe=ex.mean()/ex.std(ddof=1)*np.sqrt(252),
                max_drawdown=frame.drawdown.max(),mean_daily_turnover=frame.turnover.mean(),
                mean_weekly_turnover=frame.loc[frame.rebalanced,'turnover'].mean())


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    torch.set_num_threads(2); torch.use_deterministic_algorithms(True)
    close=pd.read_csv(DATA/'adjusted_close.csv',index_col=0,parse_dates=True).loc[:'2020-12-31',ASSETS]
    opening=pd.read_csv(DATA/'adjusted_open.csv',index_col=0,parse_dates=True).loc[close.index,ASSETS]
    assert close.index.is_monotonic_increasing and not close.index.has_duplicates
    assert (opening>0).all().all() and (close>0).all().all()
    raw_rf=pd.read_csv(DATA/'fred_dtb3.csv',index_col=0,parse_dates=True)
    rates=pd.to_numeric(raw_rf.iloc[:,0],errors='coerce').loc[:'2020-12-31']
    rf=rf_returns(opening.index[opening.index>=pd.Timestamp('2018-01-01')],rates)
    x,y,schedule,mean,std=weekly_samples(close,opening)
    train=schedule.split.eq('train').to_numpy()
    tx,ty=x[train],y[train]; vx=x[~train]
    vs=schedule.loc[~train].reset_index(drop=True)
    schedule.to_csv(OUT/'weekly_schedule.csv',index=False)
    pd.DataFrame({'mean':mean,'std':std}).to_csv(OUT/'scaler.csv')
    config=dict(assets=ASSETS,grids=GRIDS,seeds=SEEDS,epochs=10,block_weeks=26,
                model=dict(layers=1,d_model=32,heads=4,feedforward=64,dropout=0.,inputs=18,outputs=6),
                train_weeks=len(tx),train_scored_weeks=len(tx)-1,validation_weeks=len(vx),
                training='2006–2017; weekly gross open-to-open returns, within-block population variance',
                weekly_rule='first session of calendar week; previous session close signal; next session open execution',
                boundary_rule='exclude any whole weekly target with start/end outside its split',
                risk_free='FRED DTB3, strictly prior-date observation, 91-day discount-price daily accrual proxy; not a tradable T-bill index',
                costs_bps=[0,10,25],checkpoint='max validation net excess Sharpe at 10 bps per seed/candidate',
                parameter_selection='maximize mean validation net excess Sharpe across 3 seeds within each variant',
                learning_rate=.001,optimizer='Adam',gradient_clip=1.,final_test_used=False,
                data_metadata=json.loads((DATA/'metadata.json').read_text()))
    (OUT/'config.json').write_text(json.dumps(config,indent=2))
    candidate_rows=[]; init_hashes={}; paths={}; begin=time.time()
    for name,grid in GRIDS.items():
        for risk,turn in grid:
            for seed in SEEDS:
                torch.manual_seed(seed)
                model=PortfolioTransformer(dropout=0.,n_assets=6)
                digest=hashlib.sha256(b''.join(v.numpy().tobytes() for v in model.state_dict().values())).hexdigest()
                if seed in init_hashes: assert digest==init_hashes[seed]
                init_hashes[seed]=digest
                opt=torch.optim.Adam(model.parameters(),lr=.001)
                rng=np.random.default_rng(seed)
                folder=OUT/'candidates'/f'risk{risk}_turn{turn}'/f'seed{seed}'
                folder.mkdir(parents=True,exist_ok=True)
                best=-np.inf; history=[]
                for epoch in range(1,11):
                    model.train(); totals=np.zeros(4); count=0
                    for s in rng.permutation(np.arange(1,len(tx),26)):
                        e=min(s+26,len(tx)); opt.zero_grad()
                        terms=objective(model(tx[s-1:e]),ty[s-1:e],risk,turn)
                        if not torch.isfinite(terms[0]): raise ValueError('Nonfinite loss')
                        terms[0].backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); opt.step()
                        totals+=np.array([v.item() for v in terms])*(e-s); count+=e-s
                    weights=infer(model,vx)
                    score=metric(backtest_weekly(opening,vs,weights,rf))
                    history.append(dict(epoch=epoch,loss=totals[0]/count,train_gross=totals[1]/count,
                                        train_weekly_variance=totals[2]/count,train_turnover=totals[3]/count,**score))
                    if score['net_sharpe']>best:
                        best=score['net_sharpe']; selected_epoch=epoch
                        torch.save(dict(state_dict=model.state_dict(),config=config,seed=seed,epoch=epoch,
                                        risk=risk,turnover=turn,initial_hash=digest,
                                        feature_order=[list(c) for c in mean.index],
                                        scaler_mean=mean.to_list(),scaler_std=std.to_list()),folder/'best.pt')
                pd.DataFrame(history).to_csv(folder/'training_history.csv',index=False)
                model.load_state_dict(torch.load(folder/'best.pt',weights_only=True)['state_dict'])
                weights=infer(model,vx)
                pd.DataFrame(weights,index=vs.execution_date,columns=ASSETS).to_csv(folder/'weekly_weights.csv')
                candidate_rows.append(dict(method=name,risk=risk,turnover=turn,seed=seed,
                                           epoch=selected_epoch,**metric(backtest_weekly(opening,vs,weights,rf))))
                paths[(name,risk,turn,seed)]=folder
                print(f'{name} risk={risk} turnover={turn} seed={seed}: Sharpe={best:.3f}',flush=True)
    candidates=pd.DataFrame(candidate_rows)
    candidates.to_csv(OUT/'candidate_metrics.csv',index=False)
    selected={}; results=[]; curves={}
    for name in GRIDS:
        grouped=candidates[candidates.method==name].groupby(['risk','turnover']).net_sharpe.mean()
        risk,turn=grouped.idxmax(); selected[name]=dict(risk=float(risk),turnover=float(turn))
        for seed in SEEDS:
            folder=paths[(name,risk,turn,seed)]
            weights=pd.read_csv(folder/'weekly_weights.csv',index_col=0).to_numpy()
            for cost in [0,10,25]:
                frame=backtest_weekly(opening,vs,weights,rf,cost)
                frame.to_csv(folder/f'validation_{cost}bps.csv')
                results.append(dict(method=name,seed=seed,cost_bps=cost,risk=risk,turnover=turn,**metric(frame)))
                if cost==10: curves[(name,seed)]=frame.net_value
    r=close.pct_change(fill_method=None)
    for method in ['Equal Weight','Minimum Variance']:
        weights=np.stack([target_weights(r.iloc[int(w.start)-60:int(w.start)].to_numpy(),method) for _,w in vs.iterrows()])
        for cost in [0,10,25]:
            frame=backtest_weekly(opening,vs,weights,rf,cost)
            frame.to_csv(OUT/f'{method.lower().replace(" ","_")}_{cost}bps.csv')
            results.append(dict(method=method,seed=-1,cost_bps=cost,risk=np.nan,turnover=np.nan,**metric(frame)))
    results=pd.DataFrame(results); results.to_csv(OUT/'selected_results.csv',index=False)
    config.update(selected_penalties=selected,initial_hashes=init_hashes,runtime_seconds=time.time()-begin)
    (OUT/'config.json').write_text(json.dumps(config,indent=2))
    write_report(results,config,vs,OUT)
    plot(results,curves,OUT)
    print(results[results.cost_bps==10].groupby('method')[['annualized_net_return','net_sharpe','mean_weekly_turnover']].mean().to_string())


def plot(results,curves,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    fig,ax=plt.subplots(1,2,figsize=(12,4.5))
    for name in GRIDS:
        values=pd.concat([curves[(name,s)] for s in SEEDS],axis=1)
        line,=ax[0].plot(values.index,values.mean(axis=1),label=name)
        ax[0].fill_between(values.index,values.min(axis=1),values.max(axis=1),alpha=.12,color=line.get_color())
        sub=results[results.method==name].groupby('cost_bps').net_sharpe.agg(['mean','std'])
        ax[1].errorbar(sub.index,sub['mean'],yerr=sub['std'],label=name,capsize=3)
    ax[0].xaxis.set_major_locator(mdates.YearLocator()); ax[0].xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax[0].set(title='Weekly strategy | 10 bps | seed mean and range',ylabel='Net value')
    ax[1].set(title='Excess Sharpe vs FRED DTB3 | mean ± seed SD',xlabel='Cost (bps)',ylabel='Net excess Sharpe')
    for a in ax: a.grid(alpha=.2); a.legend(fontsize=8)
    fig.suptitle('FINAL PROPOSAL DATA | 6 ETFs | validation 2018–2020')
    fig.tight_layout(); fig.savefig(out/'final_proposal_comparison.png',dpi=170); plt.close(fig)


def write_report(result,config,schedule,out):
    lines=['# 最终版 Proposal：数据纠正后重训结果','',
           '最终依据：data/final_proposal/ARIN5203_Proposal.pdf。旧五资产、日调仓、收盘执行结果不可作为最终版实验结果。','',
           '资产：SPY、EFA、EEM、IEF、TLT、GLD。研究期 2006–2025，额外下载 2005 年作为特征预热。训练 2006–2017、验证 2018–2020；最终测试期未用于此次特征拟合、训练或选型。','',
           f'训练有效周目标 {config["train_weeks"]} 个，首个只作前置持仓，因此每轮评分 {config["train_scored_weeks"]} 个；验证 {config["validation_weeks"]} 个完整周目标。验证实际执行从 {schedule.execution_date.iloc[0].date()} 至持有期终点 {schedule.holding_end.iloc[-1].date()}。跨 split 边界的周目标整段剔除。','',
           '## 实现口径','',
           '- 输入：60 日 × 6 资产 × 3 特征（日收盘收益、20 日波动率、20 日动量），18 维；训练期拟合标准化。',
           '- 每个自然周首个交易日开盘调仓，前一交易日收盘后形成信号；持有至下周首个交易日开盘。仅周初调仓，周内权重随价格漂移。',
           '- 复权开盘价由 Open × Adj Close / Close 构造。日净值按开盘至下一开盘记账。仅执行日产生总买卖金额 L1 换手成本；沿用小成本近似，未模拟精确自融资成交。',
           '- DTB3 是贴现报价而非收益指数；采用 91 天面值贴现价格 P=1−(DTB3/100)×91/360，再用 P^(−日历天数/91)−1 近似期间无风险收益。每个期间只使用开始日前已有日期的最近非缺失报价；假设该报价已发布，不是实时发布时点数据库。',
           '- 净 Sharpe 基于每日净收益减上述无风险收益，按 √252 年化；CAGR/波动按 252 日口径。最大回撤包含初始净值 1。',
           '- 三个种子各训练 10 epochs；每块 26 个连续周目标，额外一周上下文，训练优化周收益均值、块内周收益方差及周换手。风险强度候选 1/5，换手强度候选 0.001/0.005。每候选每种子按 10 bps 验证净 Sharpe 选 epoch，再按三种子平均选择每个版本的系数。',
           '- 所有配置为一层、32 维、4 heads、前馈64、dropout0、输出6权重的小型 Transformer；相同种子初始化与时间块顺序相同。各变体候选组合数不同，结果包含选参预算差异；本轮定位为初步验证，不是等搜索预算的最终方法比较。','',
           '## 10 bps 验证结果','',
           '| 方法 | 年化净收益 | 波动率 | 净超额 Sharpe | 最大回撤 | 周均换手 |',
           '|---|---:|---:|---:|---:|---:|']
    sub=result[result.cost_bps==10]
    cols=['annualized_net_return','annualized_volatility','net_sharpe','max_drawdown','mean_weekly_turnover']
    for name in [*GRIDS,'Equal Weight','Minimum Variance']:
        rows=sub[sub.method==name]; vals=[]
        for c in cols:
            scale=1 if c=='net_sharpe' else 100; suffix='' if scale==1 else '%'
            v=f'{rows[c].mean()*scale:.3f}{suffix}'
            if len(rows)>1: v+=f' ± {rows[c].std()*scale:.3f}{suffix}'
            vals.append(v)
        lines.append('| '+name+' | '+' | '.join(vals)+' |')
    lines+=['','Transformer 为三个种子的均值 ± 样本标准差，标准差不是市场置信区间。传统策略为单个确定性结果。这里的验证集参与选参，不能作为最终样本外测试结果。','',
            '选定系数：`'+json.dumps(config['selected_penalties'])+'`。','',
            '## 尚未完成的最终版承诺','',
            '本轮完成数据与执行口径纠正、传统等权/最小方差、Transformer 消融及三种子与成本比较。DeepDow 组件复用、LSTM、均值—方差 baseline、配对 studentized circular-block bootstrap 尚未完成；不能声称已完成全部 proposal。最终测试期 2021–2025 保留。','',
            '复现：先运行 download_final_data.py 下载冻结数据，再运行 final_proposal_experiment.py。全部原始数据、公司行动、FRED 序列、哈希、配置、模型、标准化参数、周目标权重和训练日志均已保存。']
    (out/'milestone_final_proposal_notes.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__': main()
