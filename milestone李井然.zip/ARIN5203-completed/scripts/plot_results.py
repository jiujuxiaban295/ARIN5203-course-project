#!/usr/bin/env python3
"""Export inspectable research figures, without generating a report."""
import argparse
import json
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR",str(Path(__file__).resolve().parents[1]/".cache"/"matplotlib"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd

LABELS={"equal_weight":"Equal weight","minimum_variance":"Minimum variance",
 "mean_variance":"Mean–variance","transformer_return_ensemble":"Transformer: return only",
 "transformer_risk_ensemble":"Transformer: risk","transformer_turnover_ensemble":"Transformer: turnover",
 "transformer_full_ensemble":"Transformer: risk + turnover","lstm_full_ensemble":"LSTM: risk + turnover",
 "chronos2_synth":"Chronos-2-Synth (frozen)"}
COLORS={"equal_weight":"#555555","minimum_variance":"#A78316","mean_variance":"#746F38",
 "transformer_return_ensemble":"#D66A32","transformer_risk_ensemble":"#746F38",
 "transformer_turnover_ensemble":"#A78316","transformer_full_ensemble":"#2264A5",
 "lstm_full_ensemble":"#AC4F7E","chronos2_synth":"#6F4E8B"}
STYLES={"equal_weight":"--","minimum_variance":":","mean_variance":"-.",
 "transformer_return_ensemble":"--","transformer_full_ensemble":"-","lstm_full_ensemble":"-."}


def export(fig,path):
    fig.savefig(str(path)+".png",dpi=180,bbox_inches="tight",facecolor="white")
    fig.savefig(str(path)+".pdf",bbox_inches="tight",facecolor="white")
    plt.close(fig)


def style(ax):
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y",color="#E1E4E8",lw=.7)
    ax.set_axisbelow(True)


def plot(root):
    root=Path(root); figures=root/"figures"; figures.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.titlesize":14,
                         "axes.labelsize":11,"legend.fontsize":9,"pdf.fonttype":42})
    metrics=pd.read_csv(root/"metrics.csv")
    test=metrics[(metrics.split=="test") & (metrics.cost_bps==10)].set_index("strategy")
    names=["equal_weight","minimum_variance","mean_variance","lstm_full_ensemble",
           "transformer_return_ensemble","transformer_full_ensemble"]
    if "chronos2_synth" in test.index:
        names.append("chronos2_synth")
    daily={name:pd.read_csv(root/"daily"/"test"/f"{name}_10bps.csv",index_col="date",parse_dates=True) for name in names}
    for metric,ylabel,title,filename in [("wealth","Portfolio value (initial = 1)","Test-period net portfolio value","cumulative_wealth"),
             ("drawdown","Drawdown","Test-period drawdown","drawdown")]:
        fig,ax=plt.subplots(figsize=(11,6.5),layout="constrained")
        for name,frame in daily.items():
            # Include starting unit wealth so the first-day cost is visible.
            initial=pd.Timestamp(frame.execution_date.iloc[0])
            values=pd.concat([pd.Series([1.],index=[initial]),frame.wealth])
            if metric=="drawdown": values=values/values.cummax()-1
            ax.plot(values.index,values,color=COLORS[name],linestyle=STYLES.get(name,":"),lw=1.6,label=LABELS[name])
        ax.set_title(title+" | 10 bps per traded dollar")
        ax.set_ylabel(ylabel);style(ax)
        endpoints=list(daily.values())[0]
        first=pd.Timestamp(endpoints.execution_date.iloc[0]); last=endpoints.index[-1]
        ticks=[first]+[pd.Timestamp(f"{year}-01-01") for year in range(first.year+1,last.year+1)]+[last]
        ax.set_xlim(first,last);ax.set_xticks(ticks,[date.strftime("%Y-%m") for date in ticks])
        if metric=="drawdown":ax.yaxis.set_major_formatter(PercentFormatter(1))
        ax.legend(ncol=2,loc="upper center",bbox_to_anchor=(.5,-.12),frameon=False)
        export(fig,figures/filename)
    # Four objective variants, with seed spread shown as points, not a CI.
    variants=["transformer_return","transformer_risk","transformer_turnover","transformer_full"]
    fig,axes=plt.subplots(1,3,figsize=(13,4.8),layout="constrained")
    for ax,key,title in zip(axes,["net_sharpe","annualized_volatility","annualized_turnover"],
                           ["Net excess Sharpe","Annualized volatility","Annualized L1 turnover"]):
        for i,family in enumerate(variants):
            rows=test.loc[[x for x in test.index if x.startswith(family+"_s")]]
            ensemble=test.loc[family+"_ensemble",key]
            ax.scatter(np.full(len(rows),i),rows[key],color="#8B9299",s=25,label="Individual seeds" if i==0 else None)
            ax.scatter(i,ensemble,marker="D",s=65,color=COLORS[family+"_ensemble"],label="Weight ensemble" if i==0 else None)
        ax.set_xticks(range(4),["Return","+ Risk","+ Turnover","+ Both"],rotation=20)
        ax.set_title(title);style(ax)
        if key=="annualized_volatility":ax.yaxis.set_major_formatter(PercentFormatter(1))
        if key=="net_sharpe":ax.axhline(0,color="#666",lw=.7)
        else:ax.set_ylim(bottom=0)
    axes[0].legend(frameon=False,fontsize=9)
    fig.suptitle("Objective ablations | test 2021–2025, 10 bps | seed points show training variability")
    export(fig,figures/"ablations")
    # All constituent weights, with a stable, explicitly declared asset palette.
    weights=pd.read_csv(root/"targets"/"test"/"transformer_full_ensemble.csv",index_col=0,parse_dates=True)
    asset_colors=["#2264A5","#7295B8","#D66A32","#A78316","#746F38","#AC4F7E"]
    fig,ax=plt.subplots(figsize=(11,4.8),layout="constrained")
    ax.stackplot(weights.index,weights.to_numpy().T,labels=weights.columns,colors=asset_colors,alpha=.9)
    ax.set_ylim(0,1);ax.yaxis.set_major_formatter(PercentFormatter(1));ax.set_ylabel("Target allocation")
    ax.set_title("Transformer with risk + turnover | three-seed weight ensemble")
    first,last=weights.index[0],weights.index[-1]
    ticks=[first]+[pd.Timestamp(f"{year}-01-01") for year in range(first.year+1,last.year+1)]+[last]
    ax.set_xlim(first,last);ax.set_xticks(ticks,[date.strftime("%Y-%m") for date in ticks])
    ax.legend(ncol=6,loc="upper center",bbox_to_anchor=(.5,-.08),frameon=False);style(ax)
    export(fig,figures/"allocation_weights")
    # Transaction cost sensitivity, all on identical daily dates.
    fig,ax=plt.subplots(figsize=(9,5),layout="constrained")
    for name in names:
        rows=metrics[(metrics.split=="test") & (metrics.strategy==name)].sort_values("cost_bps")
        ax.plot(rows.cost_bps,rows.net_sharpe,marker="o",color=COLORS[name],linestyle=STYLES.get(name,":"),label=LABELS[name])
    ax.set_xticks([0,10,25]);ax.set_xlabel("Transaction cost (bps per dollar bought or sold)")
    ax.set_ylabel("Net excess Sharpe");ax.set_title("Trading-cost sensitivity | test 2021–2025")
    ax.legend(ncol=2,frameon=False);style(ax);export(fig,figures/"cost_sensitivity")
    fig,ax=plt.subplots(figsize=(11,5.5),layout="constrained")
    markers=["o","s","^","D","P","X","v"]
    for i,name in enumerate(names):
        row=test.loc[name]
        ax.scatter(row.annualized_volatility,row.annualized_net_return,color=COLORS[name],s=70,marker=markers[i],label=LABELS[name])
    ax.set_xlabel("Annualized volatility");ax.set_ylabel("Annualized net return")
    ax.set_xlim(left=0);ax.xaxis.set_major_formatter(PercentFormatter(1));ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.set_title("Risk and return | test 2021–2025, 10 bps")
    ax.legend(loc="center left",bbox_to_anchor=(1.02,.5),frameon=False)
    style(ax);export(fig,figures/"risk_return")
    # Validation-selected model histories do not show test measurements.
    selection=json.loads((root/"selection.json").read_text())
    fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout="constrained")
    for family in ["transformer_return","transformer_full","lstm_full"]:
        run=selection["selected"][family]["runs"][0]
        hist=pd.read_csv((root/run["checkpoint"]).parent/"history.csv")
        color=COLORS[family+"_ensemble"]
        axes[0].plot(hist.epoch,hist.train_loss,label=family,color=color)
        axes[1].plot(hist.epoch,hist.validation_net_sharpe,label=family,color=color)
    for ax in axes:style(ax);ax.set_xlabel("Epoch")
    axes[0].set_title("Training objective (different penalties)");axes[1].set_title("Validation net excess Sharpe | 10 bps")
    axes[1].legend(frameon=False);export(fig,figures/"training_curves")
    # This table and every plot are exports, not a generated academic report.
    cols=["strategy","cost_bps","annualized_net_return","annualized_volatility","net_sharpe","max_drawdown","annualized_turnover"]
    main=metrics[(metrics.split=="test") & metrics.strategy.isin(names)][cols]
    main.to_csv(root/"main_results.csv",index=False)
    print(f"Exported {len(list(figures.glob('*.png')))} figures to {figures}")

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--results",default="results/full")
    plot(p.parse_args().results)
