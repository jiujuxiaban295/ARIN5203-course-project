# Milestone Jin Ziqi

ARIN5203 milestone 材料包，整理日期 2026-11-03。本包只使用最终版 proposal 的六资产实验结果。

## 从这里开始

1. `docs/Code_and_Experiment_Analysis_ZH.md`：中文代码解释、实验结果分析和评估。
2. `docs/Milestone_Report.pdf`：三页英文 milestone report。
3. `docs/Milestone_Report.md`：同一报告的可编辑正文。
4. `outputs/final_proposal/selected_results.csv`：选定参数后的全部种子及成本结果。
5. `data/final_proposal/ARIN5203_Proposal.pdf`：本包采用的最终 proposal。

报告注明 Jin Ziqi 为本材料整理人，并列出 proposal 中的团队成员；没有推断成员个人贡献。本文不是已经提交的课程文件。当前 2–3 页要求来自此前项目记录，提交前仍应核对课程平台的模板和页数规则。

## 已有结果的范围

六只 ETF：SPY、EFA、EEM、IEF、TLT、GLD。2006–2017 训练，2018–2020 验证；2005 仅预热。2021–2025 数据已打包，尚未用于本次训练、选参或测试。每周调仓、下一交易日开盘执行；净超额 Sharpe 采用 FRED DTB3 现金收益近似。所有结果来自真实下载数据，不含模拟实验数字。

主模型为从头训练的小型 Transformer；本包有四组消融、三个随机种子、27 个候选训练及 42 行选定策略/成本汇总。验证集同时参与选型，因此不能当作最终测试表现。DeepDow 复用、LSTM、均值—方差和统计置信区间仍待完成。

## 复现环境

原实验运行在 macOS ARM、Python 3.9.6、CPU、PyTorch 2.8.0；主要依赖固定在 `requirements.txt`。不同平台的浮点或底层库实现可能有微小差异。

在解压后的本目录执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v test_baseline.py test_transformer.py test_ablation.py test_final_proposal.py
python tools/verify_package.py
```

数据已经包含在包内。要重跑最终版实验：

```bash
python final_proposal_experiment.py
```

这会覆盖 `outputs/final_proposal/` 的训练输出。建议先复制本包再重跑。若只是阅读或验证已有指标，不需要重新训练。`python download_final_data.py` 会联网重下载并覆盖数据快照；要复现当前结果，应使用包内冻结数据，而非重新下载可能修订的行情。

## 代码入口

| 文件 | 用途 |
|---|---|
| `final_proposal_experiment.py` | 最终版的采样、训练、选参、回测和结果汇总入口 |
| `download_final_data.py` | 六资产与 FRED 数据下载 |
| `transformer_baseline.py` | 复用特征、Transformer 类和推断函数 |
| `transformer_ablation.py` | 复用连续目标函数 `objective` |
| `baseline.py` | 复用传统权重优化函数和项目根目录 |
| `test_*.py` | 共 11 项测试 |
| `tools/verify_package.py` | 校验文件哈希、模型快照和保存结果 |

三个辅助模块仍保留旧版五资产的独立 `main()`，供记录和测试；**不要把它们作为本包最终版实验入口运行**。最终版只运行 `final_proposal_experiment.py`，它显式传入六资产输入与输出。

## 文件与证据

- `data/final_proposal/metadata.json` 保存数据来源、时间和 SHA256。
- `outputs/final_proposal/config.json` 保存网络、种子、系数网格与选型规则。
- `outputs/final_proposal/candidates/` 保存全部候选模型、训练日志和周权重；选定候选另含三个成本场景的逐日回测。
- `yearly_diagnostics.csv` 和 `allocation_diagnostics.csv` 是保存结果的诊断汇总。2020 年只评价到 12 月 28 日开盘，不是完整自然年。
- `MANIFEST_SHA256.json` 校验本包文件；`verification.json` 记录打包验证。不要把三个种子的标准差理解为市场置信区间。

`tools/build_report.py` 生成英文 PDF；仅生成报告需要额外的 `reportlab` 库。Markdown 中的 `<!-- PAGE BREAK -->` 对应 PDF 的明确分页。
