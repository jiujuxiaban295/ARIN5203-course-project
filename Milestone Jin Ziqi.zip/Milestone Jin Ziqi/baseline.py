"""Reproducible traditional baselines; validation results only by default."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

ASSETS = ['SPY', 'QQQ', 'IWM', 'TLT', 'GLD']
ROOT = Path(__file__).resolve().parent


def download():
    import yfinance as yf
    yf.set_tz_cache_location('/private/tmp/arin5203-yfinance-cache')
    folder = ROOT / 'data'
    folder.mkdir(exist_ok=True)
    raw = yf.download(ASSETS, start='2004-01-01', end='2026-01-01',
                      auto_adjust=False, actions=True, threads=False)
    if raw.empty:
        raise RuntimeError('No market data returned; no synthetic substitute is used.')
    raw.to_csv(folder / 'yahoo_raw.csv')
    prices = raw['Adj Close'].reindex(columns=ASSETS)
    missing = prices.isna().sum().to_dict()
    # No forward fill: retain only dates where all assets have observed prices.
    prices = prices.dropna()
    prices.to_csv(folder / 'adjusted_close.csv')
    metadata = dict(source='Yahoo Finance via yfinance', yfinance_version=yf.__version__,
                    downloaded_utc=pd.Timestamp.now(tz='UTC').isoformat(),
                    assets=ASSETS, missing_before_common_calendar=missing,
                    common_start=str(prices.index.min()), common_end=str(prices.index.max()),
                    rows=len(prices), sha256=hashlib.sha256(
                        (folder / 'adjusted_close.csv').read_bytes()).hexdigest())
    (folder / 'metadata.json').write_text(json.dumps(metadata, indent=2))


def target_weights(history, method):
    n = history.shape[1]
    if method == 'Equal Weight':
        return np.ones(n) / n
    cov = np.cov(history, rowvar=False) * 252
    result = minimize(lambda w: w @ cov @ w, np.ones(n) / n,
                      jac=lambda w: 2 * cov @ w, method='SLSQP',
                      bounds=[(0, 1)] * n,
                      constraints=[dict(type='eq', fun=lambda w: w.sum() - 1,
                                        jac=lambda w: np.ones(n))],
                      options=dict(ftol=1e-12, maxiter=500))
    if not result.success:
        raise RuntimeError(result.message)
    w = np.maximum(result.x, 0)
    return w / w.sum()


def backtest(prices, method, start='2018-01-01', end='2020-12-31', cost_bps=10,
             supplied_weights=None):
    returns = prices.pct_change(fill_method=None).dropna()
    values = returns.to_numpy()
    previous = np.ones(len(prices.columns)) / len(prices.columns)
    rows = []
    for j, date in enumerate(returns.index):
        if not (pd.Timestamp(start) <= date <= pd.Timestamp(end)):
            continue
        if j < 61:
            raise ValueError('Insufficient prehistory for 60 observations and execution lag')
        # Return dated j is earned from close j-1 to close j.
        # Target executed at close j-1 uses data only through close j-2.
        history = values[j-61:j-1]
        w = (target_weights(history, method) if supplied_weights is None else
             supplied_weights.loc[date, prices.columns].to_numpy(dtype=float))
        if (not np.isfinite(w).all() or (w < -1e-7).any()
                or not np.isclose(w.sum(), 1, atol=1e-6)):
            raise ValueError('Invalid allocation weights')
        if rows:
            drift = previous * (1 + values[j-1])
            pre = drift / drift.sum()
        else:
            # Existing equal-weight holdings at first execution close, no cash entry.
            pre = previous.copy()
        turnover = np.abs(w - pre).sum()
        gross = w @ values[j]
        cost = cost_bps / 10000 * turnover
        row = dict(date=date, signal_date=returns.index[j-2],
                   execution_date=returns.index[j-1], gross_return=gross,
                   net_return=gross-cost, turnover=turnover, cost=cost)
        row.update({f'weight_{a}': x for a, x in zip(prices.columns, w)})
        row.update({f'pre_{a}': x for a, x in zip(prices.columns, pre)})
        rows.append(row)
        previous = w
    result = pd.DataFrame(rows).set_index('date')
    result['net_value'] = (1 + result.net_return).cumprod()
    result['drawdown'] = 1 - result.net_value / result.net_value.cummax().clip(lower=1)
    return result


def metrics(frame):
    r = frame.net_return
    std = r.std(ddof=1)
    return dict(days=len(r), cumulative_net_return=frame.net_value.iloc[-1]-1,
                annualized_net_return=frame.net_value.iloc[-1]**(252/len(r))-1,
                annualized_volatility=std*np.sqrt(252),
                net_sharpe_zero_rf=r.mean()/std*np.sqrt(252) if std > 0 else np.nan,
                max_drawdown=frame.drawdown.max(), mean_daily_turnover=frame.turnover.mean())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--download', action='store_true')
    args = parser.parse_args()
    if args.download:
        download()
    prices = pd.read_csv(ROOT / 'data/adjusted_close.csv', index_col=0, parse_dates=True)
    if prices.index.has_duplicates or not prices.index.is_monotonic_increasing:
        raise ValueError('Invalid date index')
    if prices.isna().any().any() or not (prices > 0).all().all():
        raise ValueError('Invalid adjusted prices')
    out = ROOT / 'outputs/baseline_validation'
    out.mkdir(parents=True, exist_ok=True)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    summaries = []
    for method in ['Equal Weight', 'Minimum Variance']:
        for cost in [0, 5, 10, 20]:
            frame = backtest(prices, method, cost_bps=cost)
            summaries.append(dict(method=method, cost_bps=cost, **metrics(frame)))
            frame.to_csv(out / f'{method.lower().replace(" ", "_")}_{cost}bps.csv')
            if cost == 10:
                # Include initial NAV so first-period losses remain visible.
                nav = pd.concat([pd.Series([1.], index=[frame.execution_date.iloc[0]]),
                                 frame.net_value])
                axes[0].plot(nav.index, nav, label=method)
                axes[1].plot(frame.index, -100*frame.drawdown, label=method)
    summary = pd.DataFrame(summaries)
    summary.to_csv(out / 'metrics.csv', index=False)
    axes[0].set(title='Validation 2018–2020 | 10 bps per traded dollar', ylabel='Net portfolio value')
    axes[1].set(ylabel='Drawdown (%)', xlabel='Date')
    for ax in axes:
        ax.grid(alpha=.2)
        ax.legend()
    fig.tight_layout()
    fig.savefig(out / 'validation_performance.png', dpi=180)
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
