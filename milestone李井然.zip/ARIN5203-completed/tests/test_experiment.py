"""Training-cache provenance and locked-test safeguards."""
import copy
import hashlib
import json
import shutil

import numpy as np
import pandas as pd
import pytest
import torch

import portfolio.experiment as experiment
from portfolio.features import WeeklySamples


@pytest.fixture
def identity_fixture(tmp_path):
    data = tmp_path/"data"
    data.mkdir()
    (data/"market.csv").write_text("date,ticker,open,close\n2020-01-01,A,1,1\n")
    (data/"risk_free.csv").write_text("date,DTB3\n2019-12-30,1.2\n")
    output = tmp_path/"output"
    output.mkdir()
    config = {"epochs": 120, "device": "cpu", "seeds": [11, 29, 47]}
    identity = experiment._prepare_training_output(data,output,config)
    experiment.write_json(output/"config.json",config)
    return data,output,config,identity


def completed_run(output, identity):
    directory = output/"training"/"example"
    directory.mkdir(parents=True)
    checkpoint = directory/"checkpoint.pt"
    checkpoint.write_bytes(b"fixed-checkpoint-payload")
    (directory/"history.csv").write_text("epoch,validation_net_sharpe\n1,0.5\n")
    run = {
        "run_id": "example", "architecture": "transformer", "risk": 5.0,
        "turnover": 0.0025, "seed": 11, "checkpoint": "training/example/checkpoint.pt",
        "run_signature_sha256": experiment._candidate_signature(identity,"transformer",5,0.0025,11),
        "checkpoint_sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
        "validation_net_sharpe": 0.5, "best_epoch": 1,
    }
    experiment.write_json(directory/"run.json",run)
    return run,directory


def locked_run(output, identity):
    run,directory = completed_run(output,identity)
    selection = {"selected": {"transformer_full": {"runs": [run]}}}
    experiment.write_json(output/"selection.json",selection)
    manifest = {
        "experiment_identity": identity,
        "config_sha256": experiment._sha256(output/"config.json"),
        "selection_sha256": experiment._sha256(output/"selection.json"),
        "checkpoints": {"example": experiment._sha256(directory/"checkpoint.pt")},
    }
    experiment.write_json(output/"locked_manifest.json",manifest)
    return run,directory


def test_training_resume_accepts_exact_inputs_only(identity_fixture):
    data,output,config,identity = identity_fixture
    run,directory = completed_run(output,identity)
    cached = experiment._load_or_train_candidate(data,None,None,config,"transformer",5,0.0025,11,directory,identity)
    assert cached == run
    changed = {**config,"epochs":121}
    with pytest.raises(RuntimeError,match="differ"):
        experiment._prepare_training_output(data,output,changed)
    with pytest.raises(RuntimeError,match="does not match"):
        experiment._load_or_train_candidate(data,None,None,config,"lstm",5,0.0025,11,directory,identity)


@pytest.mark.parametrize("change",["market", "risk_free", "checkpoint", "missing_history"])
def test_training_resume_refuses_changed_or_incomplete_artifacts(identity_fixture, change):
    data,output,config,identity = identity_fixture
    _,directory = completed_run(output,identity)
    if change in ["market","risk_free"]:
        with (data/f"{change}.csv").open("a") as stream:
            stream.write("changed\n")
        with pytest.raises(RuntimeError,match="differ"):
            experiment._prepare_training_output(data,output,config)
    else:
        if change == "checkpoint":
            (directory/"checkpoint.pt").write_bytes(b"different-checkpoint")
        else:
            (directory/"history.csv").unlink()
        with pytest.raises(RuntimeError,match="differs|incomplete"):
            experiment._load_or_train_candidate(data,None,None,config,"transformer",5,0.0025,11,directory,identity)


@pytest.mark.parametrize("change",["config_argument", "stored_config", "market", "risk_free", "checkpoint", "selection", "identity"])
def test_test_evaluation_refuses_every_mutated_lock_input(identity_fixture, change):
    data,output,config,identity = identity_fixture
    _,directory = locked_run(output,identity)
    assert experiment._validate_locked_experiment(data,output,config)["selected"]
    if change == "config_argument":
        config = {**config,"epochs":121}
    elif change == "stored_config":
        experiment.write_json(output/"config.json",{**config,"epochs":121})
    elif change in ["market","risk_free"]:
        with (data/f"{change}.csv").open("a") as stream:
            stream.write("changed\n")
    elif change == "checkpoint":
        (directory/"checkpoint.pt").write_bytes(b"changed")
    elif change == "selection":
        experiment.write_json(output/"selection.json",{"selected":{}})
    elif change == "identity":
        experiment.write_json(output/"experiment_identity.json",{})
    with pytest.raises(RuntimeError):
        experiment._validate_locked_experiment(data,output,config)


def test_locked_experiment_can_be_copied_without_absolute_checkpoint_paths(identity_fixture):
    data,output,config,identity = identity_fixture
    run,_ = locked_run(output,identity)
    copied = output.with_name("copied")
    shutil.copytree(output,copied)
    selection = experiment._validate_locked_experiment(data,copied,config)
    assert selection["selected"]["transformer_full"]["runs"][0] == run
    assert experiment._checkpoint_path(copied,run).is_relative_to(copied)


def test_train_candidate_never_reads_test_split(tmp_path, monkeypatch):
    class RestrictedSamples(dict):
        def __getitem__(self,key):
            if key == "test":
                raise AssertionError("Training attempted to read locked test samples")
            return super().__getitem__(key)

    class TinyAllocator(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.layer = torch.nn.Linear(2,2)

        def forward(self,x):
            return self.layer(x[:,-1]).softmax(-1)

    dates = pd.bdate_range("2020-01-01",periods=12)
    x = np.random.default_rng(4).normal(size=(10,3,2)).astype(np.float32)
    y = np.random.default_rng(5).normal(0,.01,size=(10,2)).astype(np.float32)
    sample = WeeklySamples(x,y,dates[:10],dates[:10]-pd.Timedelta(days=1),dates[1:11],["A","B"])
    samples = RestrictedSamples(train=sample,validation=sample)
    monkeypatch.setattr(experiment,"model_for",lambda architecture,config:TinyAllocator())
    fake_result = pd.DataFrame({"net_return":np.linspace(-.01,.02,10),"turnover":0.,"cost":0.},index=dates[:10])
    monkeypatch.setattr(experiment,"evaluate_weights",lambda *args:fake_result)
    monkeypatch.setattr(experiment,"load_risk_free",lambda data,index:pd.Series(0.,index=index))
    config = {"device":"cpu","learning_rate":.001,"weight_decay":0.,"epochs":2,
              "selection_cost_bps":10,"patience":20}
    result = experiment.train_candidate(None,None,samples,config,"transformer",1,.0025,11,tmp_path/"candidate",run_signature="known-signature")
    assert result["epochs_run"] == 2
    assert result["run_signature_sha256"] == "known-signature"
    checkpoint = torch.load(tmp_path/"candidate"/"checkpoint.pt",weights_only=True)
    assert checkpoint["run_signature_sha256"] == "known-signature"
