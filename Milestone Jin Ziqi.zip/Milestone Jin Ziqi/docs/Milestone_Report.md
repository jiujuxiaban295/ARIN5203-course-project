# End to End Deep Portfolio Optimization
## Milestone report on risk and turnover aware objectives

Prepared by Jin Ziqi (21418846) | ARIN5203 | 3 November 2026

Team: Yiyang Lu (21383493), Jin Ziqi (21418846), Jingran Li (21327865)

### 1 Research objective and progress

We investigate whether risk and turnover penalties improve the net performance of a Transformer that directly allocates capital across ETFs. Following end-to-end portfolio learning [1] and attention-based allocation [2], our contribution is a controlled empirical study of objective functions rather than a new architecture. We have implemented a six-asset data pipeline, weekly execution backtester, equal-weight and minimum-variance benchmarks, and four Transformer objectives with three random seeds. Preliminary validation results favor the joint objective on net excess Sharpe, while revealing a return sacrifice and important selection limitations.

### 2 Data and experimental design

The final proposal specifies SPY, EFA, EEM, IEF, TLT and GLD, covering U.S. and international equities, Treasuries and gold. We use daily Yahoo Finance data obtained through yfinance [3] for 2006–2025, with 2005 retained only for feature warm-up. The study contains 5,031 common price dates. Required adjusted prices have no missing values or duplicate dates. Adjusted open equals raw open multiplied by adjusted close divided by raw close; original observations, corporate actions and hashes are retained.

Training uses 2006–2017 and validation uses 2018–2020. The 2021–2025 test period remains untouched by feature fitting, training and model selection. Each input contains the previous 60 trading days of close-to-close returns, 20-day rolling volatility and 20-day momentum: 60 × 18 features. Standardization is fitted only on training-period features. Weekly targets crossing split boundaries are excluded, leaving 625 training weeks and 156 validation weeks; the first training week supplies holding context, so 624 weeks contribute to each epoch. Validation covers 752 daily open-to-open returns from the 2 January 2018 open to the 28 December 2020 open.

### 3 Model and implementation

A randomly initialized Transformer projects 18 features to 32 dimensions, adds sinusoidal position encoding, and uses one encoder layer with four attention heads and a 64-unit feedforward layer. A softmax head maps the last historical token to six nonnegative weights summing to one. No pretrained weights are used. All variants disable dropout to avoid treating stochastic allocation changes as turnover.

The weekly training objective is L = −mean(G) + λr Var(G) + λt mean(T), where G is gross portfolio return and T is the L1 distance between target weights and drifted holdings. Training uses contiguous blocks of 26 weeks plus a preceding context week. Adam uses learning rate 0.001 and gradient clipping at 1. Each candidate runs for 10 epochs with seeds 42, 43 and 44; paired seeds share initialization and block order. Risk coefficients are 1 or 5 and turnover coefficients are 0.001 or 0.005, with zero-valued ablations. Nine configurations produce 27 training runs. We select each checkpoint by validation net excess Sharpe at 10 bps, then select coefficients by the three-seed mean.

We rebalance at the first session open each week using the previous session close signal. Weights drift between rebalances. Daily net return approximates gross return minus cost rate times traded notional; costs are 0, 10 or 25 bps per traded dollar. Benchmarks share this convention. Sharpe uses daily net returns in excess of a cash-return proxy derived from the preceding available FRED DTB3 quote [4], using a 91-day discount-price conversion and actual calendar-day accrual. Annualization uses 252 trading days. Eleven tests cover temporal alignment, boundary exclusion, allocations, gradients, drift and costs.

<!-- PAGE BREAK -->

### 4 Preliminary validation results

Table 1 reports three-seed means for selected Transformer configurations at 10 bps; benchmarks are deterministic. Sharpe uses excess net returns. Turnover is total weekly buys plus sells relative to portfolio value, without a one-half multiplier.

| Method | Net CAGR % | Volatility % | Net Sharpe | Max DD % | Turnover % |
|---|---:|---:|---:|---:|---:|
| Return only | 11.61 | 14.90 | 0.717 | 22.47 | 31.98 |
| Risk | 11.39 | 11.49 | 0.867 | 15.57 | 44.27 |
| Turnover | 13.79 | 17.35 | 0.747 | 25.81 | 22.26 |
| Risk + Turnover | 10.72 | 9.11 | 0.998 | 14.59 | 6.17 |
| Equal Weight | 9.29 | 10.42 | 0.762 | 16.81 | 1.32 |
| Minimum Variance | 5.20 | 4.63 | 0.799 | 9.19 | 8.07 |

The selected joint objective uses λr = 5 and λt = 0.005. Relative to return-only training, it raises mean Sharpe from 0.717 to 0.998 and reduces volatility, drawdown and turnover, while lowering net CAGR by about 0.90 percentage points. Joint-objective Sharpe values are 1.042, 0.910 and 1.042 across seeds: mean 0.998 and sample standard deviation 0.076. Every seed improves on its paired return-only model. This is training-seed evidence, not a confidence interval for market performance.

Risk-only training reduces average volatility and drawdown but increases weekly turnover to 44.27%. Turnover-only training has the highest mean return, yet higher volatility and drawdown than return-only training. Allocation diagnostics show that it assigns approximately 69% to SPY on average, with one asset exceeding 80% weight at approximately 53% of weekly decisions. Trading less can therefore coexist with concentrated risk.

![Validation performance and transaction cost sensitivity](../outputs/final_proposal/final_proposal_comparison.png)

Figure 1. Left: mean net value and the range across seeds at 10 bps. Right: mean excess Sharpe with one sample standard deviation across seeds. Shading and error bars are not statistical confidence intervals. All cost scenarios use the same selected allocation paths.

At zero cost, risk-only Sharpe is 1.067 versus 1.032 for the joint objective. At 25 bps, these become 0.565 and 0.946. The joint objective retains more performance as costs rise. Its mean annual interval returns are approximately −3.3%, 19.9% and 16.9% in 2018, 2019 and 2020 respectively; the last interval ends on 28 December. It does not maximize returns in every year, and minimum variance retains lower overall volatility and drawdown.

<!-- PAGE BREAK -->

### 5 Evaluation and limitations

The results provisionally support combining risk and turnover penalties to improve the risk–return–cost balance. They do not establish universal superiority or statistical significance. Both epochs and coefficients were selected on the same validation period, creating selection optimism. The joint variant searches four coefficient combinations, compared with two for each single penalty and one for return-only training. Its gain therefore mixes objective design with search opportunity. Moreover, the selected turnover coefficient differs between the single and joint objectives, so their comparison does not isolate a pure interaction effect.

Three seeds measure optimization variability within one market path. They do not establish robustness across independent markets. Only 10 epochs were run, and some selected checkpoints occur at the final epoch, so convergence is not demonstrated. The validation period includes the 2020 shock but remains a limited historical sample of a fixed, retrospectively chosen asset universe. Vendor-adjusted observations may be revised. Execution costs are a linear approximation, and the DTB3 conversion is a cash-return proxy rather than a tradable Treasury-bill index or a point-in-time publication database.

The six-asset implementation supersedes an earlier five-asset daily-rebalancing development run; those earlier results are excluded here. We currently use native PyTorch components. Reuse of DeepDow data and allocation components, the LSTM and mean–variance benchmarks, and the paired studentized circular-block bootstrap specified in the proposal remain outstanding. We do not report significance claims before implementing and checking that inference procedure [5].

### 6 Remaining work and schedule

Our next priority is to separate objective effects from selection effects through matched-coefficient ablations and more comparable search budgets. We will check learning curves, concentration and regime dependence before freezing the evaluation protocol. The following schedule is proposed for team coordination; individual task ownership remains to be agreed.

| Period | Planned deliverable |
|---|---|
| 7–15 November | Add LSTM and mean–variance benchmarks; resolve DeepDow reuse; check matched objectives and training convergence. |
| 16–23 November | Complete parameter sensitivity and paired-seed comparisons; predefine bootstrap design and final model selection. |
| 24–30 November | Freeze the protocol, evaluate 2021–2025 once, and calculate planned confidence intervals and failure-case diagnostics. |
| 1–5 December | Consolidate figures, limitations, reproducibility materials and the final report. |

The current deliverable includes frozen data, all 27 candidate checkpoints and logs, selected weekly weights, daily cost-adjusted returns, and figures. Saved checkpoints and 42 selected strategy–cost summaries have been checked against their underlying outputs. The final test must remain separate from model selection; any changes prompted by its results must be disclosed rather than presented as an untouched test.

### References

[1] Zhang, Z., Zohren, S., and Roberts, S. (2020). Deep Learning for Portfolio Optimization. The Journal of Financial Data Science, 2(4), 8–20. doi:10.3905/jfds.2020.1.042.

[2] Kisiel, D., and Gorse, D. (2023). Portfolio Transformer for Attention-Based Asset Allocation. ICAISC 2022, LNCS 13588. doi:10.1007/978-3-031-23492-7_6.

[3] Aroussi, R. yfinance. github.com/ranaroussi/yfinance. Data provider: Yahoo Finance; snapshot retrieved 3 November 2026.

[4] Board of Governors of the Federal Reserve System. 3-Month Treasury Bill Secondary Market Rate, Discount Basis [DTB3]. FRED, Federal Reserve Bank of St. Louis. fred.stlouisfed.org/series/DTB3.

[5] Ledoit, O., and Wolf, M. (2008). Robust Performance Hypothesis Testing with the Sharpe Ratio. Journal of Empirical Finance, 15(5), 850–859. doi:10.1016/j.jempfin.2008.03.002.
