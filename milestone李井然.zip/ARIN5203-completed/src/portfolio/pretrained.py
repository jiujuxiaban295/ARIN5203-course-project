"""Optional, frozen Chronos-2-Synth forecast-to-allocation baseline.

The model is separate from the trainable end-to-end allocation experiment. Its
official card states synthetic-only pretraining. No model fine-tuning, financial
parameter fitting or test-set temperature selection is performed here.

Official API: https://github.com/amazon-science/chronos-forecasting
Checkpoint: https://huggingface.co/autogluon/chronos-2-synth
"""

from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import version
import json
import os
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

MODEL_ID = "autogluon/chronos-2-synth"
PACKAGE_VERSION = "2.3.2"


def history_windows(
    adjusted_close: pd.DataFrame,
    signal_dates: Sequence,
    context_length: int = 60,
) -> tuple[np.ndarray, pd.DatetimeIndex]:
    """Return [decision, asset, history], including each signal day's close.

    The caller must pass the same decision dates used by the common next-open
    backtester. Different decisions must remain separate Chronos tasks.
    """
    if context_length < 2:
        raise ValueError("context_length must be at least 2")
    if adjusted_close.empty or not adjusted_close.columns.is_unique:
        raise ValueError("Need a nonempty adjusted-close matrix with unique assets")
    calendar = pd.DatetimeIndex(adjusted_close.index)
    if calendar.tz is not None:
        raise ValueError("Use timezone-naive market session dates")
    if calendar.has_duplicates or not calendar.is_monotonic_increasing:
        raise ValueError("Adjusted closes must have unique, sorted dates")
    signals = pd.DatetimeIndex(signal_dates)
    if signals.has_duplicates or not signals.is_monotonic_increasing:
        raise ValueError("Signal dates must be unique and sorted")
    if len(signals) == 0:
        raise ValueError("Need at least one signal date")
    positions = calendar.get_indexer(signals)
    if (positions < context_length - 1).any():
        raise ValueError("Every signal needs a complete, observed historical window")
    values = adjusted_close.to_numpy(dtype=np.float64)
    windows = np.stack([values[p-context_length+1:p+1].T for p in positions])
    if not np.isfinite(windows).all() or (windows <= 0).any():
        raise ValueError("Historical adjusted closes must be finite and positive")
    return windows.astype(np.float32), signals


def returns_to_weights(forecast_prices: np.ndarray, current_prices: np.ndarray,
                       temperature: float = 0.05) -> np.ndarray:
    """Fixed long-only mapping: softmax((forecast/current - 1) / 0.05).

    The temperature is declared before evaluation and never selected on test
    returns. Five-session median close forecasts are a signal proxy; the actual
    strategy is still executed at next open by the common backtester.
    """
    forecast_prices = np.asarray(forecast_prices, dtype=float)
    current_prices = np.asarray(current_prices, dtype=float)
    if temperature <= 0 or not np.isfinite(temperature):
        raise ValueError("temperature must be finite and positive")
    if forecast_prices.shape != current_prices.shape or forecast_prices.ndim != 2:
        raise ValueError("Forecast and current prices must share [decision, asset] shape")
    if not np.isfinite(forecast_prices).all() or not np.isfinite(current_prices).all():
        raise ValueError("Forecast and current prices must be finite")
    if (current_prices <= 0).any():
        raise ValueError("Current adjusted closes must be positive")
    scores = (forecast_prices / current_prices - 1.0) / temperature
    scores -= scores.max(axis=1, keepdims=True)
    probability = np.exp(scores)
    return probability / probability.sum(axis=1, keepdims=True)


def cache_environment(cache_dir: str | Path) -> Path:
    """Keep Hugging Face caches in project work, never the home directory."""
    root = Path(cache_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    os.environ["HF_HOME"] = str(root)
    os.environ["HF_HUB_CACHE"] = str(root / "hub")
    os.environ["HF_XET_CACHE"] = str(root / "xet")
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    return root


def download_checkpoint(cache_dir: str | Path, model_id: str = MODEL_ID,
                        revision: str = "main") -> tuple[Path, dict]:
    """Download official safe tensor weights and record the resolved commit.

    A matching existing manifest reuses the exact saved snapshot. Request an
    explicit different revision to refresh; this prevents mutable main from
    silently changing the baseline on reruns.
    """
    root = cache_environment(cache_dir)
    manifest_path = root / "checkpoint_manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        existing = Path(manifest["snapshot_path"])
        if (manifest["model_id"] == model_id and
                manifest["requested_revision"] == revision and existing.is_dir()):
            return existing, manifest
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise ImportError(f"Install chronos-forecasting=={PACKAGE_VERSION}") from exc
    snapshot = Path(snapshot_download(
        repo_id=model_id, revision=revision, cache_dir=str(root / "hub"),
        allow_patterns=["config.json", "*.safetensors", "*.safetensors.index.json",
                        "README.md", "LICENSE", "LICENSE.*"],
    ))
    if not list(snapshot.glob("*.safetensors")):
        raise RuntimeError("The official snapshot has no safe tensor weights")
    manifest = {
        "model_id": model_id, "requested_revision": revision,
        "resolved_revision": snapshot.name, "snapshot_path": str(snapshot),
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "license": "Apache-2.0", "pretraining": "synthetic-only, per official model card",
        "source": f"https://huggingface.co/{model_id}/tree/{snapshot.name}",
        "checkpoint_bytes": sum(p.stat().st_size for p in snapshot.glob("*.safetensors")),
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    return snapshot, manifest


def forecast_weights(
    adjusted_close: pd.DataFrame,
    signal_dates: Sequence,
    *,
    cache_dir: str | Path,
    output_dir: str | Path,
    model_id: str = MODEL_ID,
    revision: str = "main",
    context_length: int = 60,
    prediction_length: int = 5,
    temperature: float = 0.05,
    batch_size: int = 96,
    device: str = "cpu",
) -> tuple[pd.DataFrame, dict]:
    """Run/cached frozen forecasts; return signal-date weights and provenance.

    cross_learning=False is essential: each historical week is a distinct task,
    preventing later histories in the batch from leaking into earlier weeks.
    Within each task the six assets are modeled jointly.
    """
    if prediction_length < 1 or batch_size < len(adjusted_close.columns):
        raise ValueError("Need a positive horizon and batch_size >= number of assets")
    histories, signals = history_windows(adjusted_close, signal_dates, context_length)
    assets = adjusted_close.columns.astype(str).tolist()
    signature = {"model_id": model_id, "requested_revision": revision,
                 "context_length": context_length, "prediction_length": prediction_length,
                 "temperature": temperature, "assets": assets, "cross_learning": False,
                 "signals": signals.strftime("%Y-%m-%d").tolist(),
                 "mapping": "softmax((median_forecast_close_at_horizon/current_close - 1)/temperature)"}
    digest = sha256(json.dumps(signature, sort_keys=True).encode() + histories.tobytes()).hexdigest()
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    cache_file = output / "chronos_synth_forecasts.npz"
    metadata_file = output / "chronos_synth_metadata.json"
    if cache_file.exists() and metadata_file.exists():
        metadata = json.loads(metadata_file.read_text())
        if metadata.get("input_sha256") == digest:
            with np.load(cache_file, allow_pickle=False) as cached:
                weights = cached["weights"]
            return pd.DataFrame(weights, index=signals, columns=assets), metadata
    root = cache_environment(cache_dir)
    snapshot, checkpoint = download_checkpoint(root, model_id, revision)
    try:
        import torch
        from chronos import Chronos2Pipeline
    except ImportError as exc:
        raise ImportError(f"Install chronos-forecasting=={PACKAGE_VERSION}") from exc
    if version("chronos-forecasting") != PACKAGE_VERSION:
        raise RuntimeError(f"This adapter is verified against chronos-forecasting=={PACKAGE_VERSION}")
    pipeline = Chronos2Pipeline.from_pretrained(
        str(snapshot), device_map=device, torch_dtype=torch.float32,
        local_files_only=True,
    )
    pipeline.model.eval()
    quantiles = list(pipeline.quantiles)
    median_index = next((i for i, q in enumerate(quantiles) if abs(q - 0.5) < 1e-8), None)
    if median_index is None:
        raise RuntimeError("Official checkpoint has no median quantile")
    # Batch by decision to bound memory. Each task contains only contemporaneous
    # asset histories; Chronos group attention is never shared between decisions.
    decisions_per_batch = max(1, batch_size // len(assets))
    forecasts = []
    for start in range(0, len(histories), decisions_per_batch):
        predictions = pipeline.predict(
            histories[start:start+decisions_per_batch],
            prediction_length=prediction_length, context_length=context_length,
            batch_size=batch_size, cross_learning=False,
        )
        forecasts.extend(p[:, median_index, :].detach().cpu().numpy() for p in predictions)
    median_forecasts = np.stack(forecasts)
    expected_shape = (len(signals), len(assets), prediction_length)
    if median_forecasts.shape != expected_shape or not np.isfinite(median_forecasts).all():
        raise RuntimeError(f"Invalid forecasts; expected {expected_shape}, got {median_forecasts.shape}")
    weights = returns_to_weights(median_forecasts[:, :, -1], histories[:, :, -1], temperature)
    metadata = {**signature, "input_sha256": digest, "checkpoint": checkpoint,
                "package_version": version("chronos-forecasting"),
                "torch_version": torch.__version__, "device": device,
                "generated_utc": datetime.now(timezone.utc).isoformat(),
                "decisions": len(signals), "negative_median_forecasts": int((median_forecasts <= 0).sum()),
                "fine_tuned": False, "test_tuning": False,
                "limitation": "Research backcast of a later-released frozen synthetic-trained model; not historically deployable performance"}
    np.savez_compressed(cache_file, weights=weights, median_forecasts=median_forecasts,
                        signal_dates=np.asarray(signature["signals"]), assets=np.asarray(assets))
    metadata_file.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
    frame = pd.DataFrame(weights, index=signals, columns=assets)
    frame.index.name = "date"
    frame.to_csv(output / "chronos_synth_weights.csv")
    return frame, metadata
