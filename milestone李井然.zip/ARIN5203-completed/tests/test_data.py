from pathlib import Path
import hashlib
import importlib.util
import io
import json
import zipfile

import numpy as np
import pandas as pd
import pytest

from portfolio.data import TICKERS, discount_yield_to_daily, load_market, load_risk_free, validate_market_long


def market_rows():
    return pd.DataFrame([{"date": d, "ticker": t, "open": 100.0, "close": 101.0}
                         for d in pd.bdate_range("2020-01-02", periods=3) for t in TICKERS])


def test_market_rejects_missing_asset_without_fill():
    with pytest.raises(ValueError, match="Incomplete"):
        validate_market_long(market_rows().iloc[1:])


def test_market_rejects_duplicates_and_invalid_prices():
    frame = market_rows()
    with pytest.raises(ValueError, match="Duplicate"):
        validate_market_long(pd.concat([frame, frame.iloc[:1]]))
    frame.loc[0, "open"] = np.nan
    with pytest.raises(ValueError, match="positive and finite"):
        validate_market_long(frame)


def test_market_load_keeps_declared_order(tmp_path: Path):
    market_rows().to_csv(tmp_path / "market.csv", index=False)
    loaded = load_market(tmp_path)
    assert loaded.columns.tolist() == [(field, ticker) for field in ["open", "close"] for ticker in TICKERS]
    assert loaded.index.is_monotonic_increasing
    assert not loaded.isna().any().any()


def test_discount_basis_conversion():
    yield_percent = 5.0
    price = 1 - 0.05 * 91 / 360
    daily = discount_yield_to_daily(yield_percent)
    assert daily == pytest.approx((1 / price) ** (365 / (91 * 252)) - 1)
    assert daily > yield_percent / 100 / 252
    assert discount_yield_to_daily(0.0) == 0


def test_risk_free_uses_only_available_prior_quote(tmp_path: Path):
    pd.DataFrame({"date": ["2020-01-02", "2020-01-03", "2020-01-06"], "DTB3": [1, 2, 99]}).to_csv(tmp_path / "risk_free.csv", index=False)
    rates = load_risk_free(tmp_path, pd.DatetimeIndex(["2020-01-06", "2020-01-07"]))
    np.testing.assert_allclose(rates.to_numpy(), [discount_yield_to_daily(1), discount_yield_to_daily(2)])
    # Altering a quote that is not yet available cannot alter earlier values.
    frame = pd.read_csv(tmp_path / "risk_free.csv")
    frame.loc[2, "DTB3"] = 0
    frame.to_csv(tmp_path / "risk_free.csv", index=False)
    np.testing.assert_allclose(load_risk_free(tmp_path, rates.index), rates)


def test_risk_free_never_backfills_and_rejects_staleness(tmp_path: Path):
    pd.DataFrame({"date": ["2020-01-02"], "DTB3": [1]}).to_csv(tmp_path / "risk_free.csv", index=False)
    with pytest.raises(ValueError, match="no prior"):
        load_risk_free(tmp_path, pd.DatetimeIndex(["2020-01-02"]))
    with pytest.raises(ValueError, match="stale"):
        load_risk_free(tmp_path, pd.DatetimeIndex(["2020-02-03"]))


def importer_module():
    script = Path(__file__).resolve().parents[1] / "scripts" / "import_dataset.py"
    spec = importlib.util.spec_from_file_location("import_dataset", script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_import_rejects_unapproved_archive_before_writing(tmp_path: Path):
    source = tmp_path / "other.zip"
    source.write_bytes(b"not the final dataset")
    output = tmp_path / "output"
    with pytest.raises(ValueError, match="SHA256 mismatch"):
        importer_module().import_dataset(source, output)
    assert not output.exists()


def test_import_rejects_zip_traversal(tmp_path: Path):
    source = tmp_path / "malicious.zip"
    with zipfile.ZipFile(source, "w") as archive:
        archive.writestr("proposal_final_2006_2025/../../outside.csv", "bad")
    checksum = hashlib.sha256(source.read_bytes()).hexdigest()
    with pytest.raises(ValueError, match="Unsafe archive"):
        importer_module().import_dataset(source, tmp_path / "output", checksum)
    assert not (tmp_path / "outside.csv").exists()


def test_adjusted_open_must_match_raw_factor():
    frame = pd.DataFrame({"Date": ["2006-01-03"], "Ticker": ["SPY"], "Open": [100.0],
                          "Close": [102.0], "Adjusted Open": [80.0],
                          "Adjusted Close": [81.6], "Adjustment Factor": [0.8]})
    importer_module().validate_adjustments(frame, "SPY")
    frame.loc[0, "Adjusted Open"] = 99.0
    with pytest.raises(ValueError, match="inconsistent adjusted open"):
        importer_module().validate_adjustments(frame, "SPY")


def test_offline_final_archive_import_and_source_provenance(tmp_path: Path):
    module = importer_module()
    archive = Path(__file__).resolve().parents[1] / module.FINAL_ARCHIVE
    if not archive.exists():
        pytest.skip("Versioned final dataset archive is not included in this checkout")
    output = tmp_path / "imported"
    quality = module.import_dataset(archive, output)
    assert quality["main_sessions_per_asset"] == 5031
    assert quality["warmup_sessions_per_asset"] == 252
    assert quality["wide_prices_match_single_ticker_files_exactly"]
    assert quality["imputed_market_prices"] == 0
    provenance = json.loads((output / "provenance.json").read_text())
    assert provenance["archive_filename"] == "5203最终版数据.zip"
    assert provenance["archive_sha256"] == module.FINAL_SHA256
    assert all(name.startswith(module.PREFIX) for name in provenance["source_members"])
    benchmark = load_risk_free(output, pd.bdate_range("2021-01-04", "2025-12-31"))
    assert benchmark.notna().all()
