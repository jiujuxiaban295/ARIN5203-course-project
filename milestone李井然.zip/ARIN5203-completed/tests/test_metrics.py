import numpy as np
import pandas as pd
import pytest

from portfolio.metrics import paired_sharpe_bootstrap, sharpe, summarize


def test_metrics_include_initial_wealth_in_drawdown():
    frame = pd.DataFrame({"net_return": [-0.2, 0.1], "turnover": [1, 0], "cost": [0, 0]})
    result = summarize(frame)
    assert result["total_net_return"] == pytest.approx(-0.12)
    assert result["max_drawdown"] == pytest.approx(-0.2)
    assert result["annualized_turnover"] == pytest.approx(126)
    assert result["average_rebalance_turnover"] == 1


def test_sharpe_uses_daily_excess_returns():
    r = np.array([0.001, 0.002, -0.001, 0.003])
    rf = np.full(4, 0.0001)
    expected = (r - rf).mean() / (r - rf).std(ddof=1) * np.sqrt(252)
    assert sharpe(r, rf) == pytest.approx(expected)


def test_rf_dates_cannot_silently_misalign():
    dates = pd.date_range("2020-01-01", periods=40)
    a = pd.Series(np.linspace(-0.01, 0.02, 40), index=dates)
    rf = pd.Series(0, index=dates + pd.Timedelta(days=1))
    with pytest.raises(ValueError, match="identical ordered dates"):
        summarize(pd.DataFrame({"net_return": a}), rf)


def correlated_returns():
    rng = np.random.default_rng(7)
    market = rng.normal(0.0004, 0.01, size=260)
    a = market + rng.normal(0.0001, 0.003, size=260)
    b = market + rng.normal(0, 0.003, size=260)
    return a, b


def test_paired_studentized_interval_swaps_sign_and_is_reproducible():
    a, b = correlated_returns()
    first = paired_sharpe_bootstrap(a, b, n_boot=99, seed=17)
    again = paired_sharpe_bootstrap(a, b, n_boot=99, seed=17)
    reverse = paired_sharpe_bootstrap(b, a, n_boot=99, seed=17)
    assert first == again
    assert first["ci_low"] == pytest.approx(-reverse["ci_high"])
    assert first["ci_high"] == pytest.approx(-reverse["ci_low"])
    assert first["p_value"] == reverse["p_value"]
    assert first["valid_bootstrap_draws"] == 99
    assert first["ci_low"] < first["ci_high"]


def test_identical_strategies_have_zero_difference_not_fake_significance():
    a, _ = correlated_returns()
    result = paired_sharpe_bootstrap(a, a.copy(), n_boot=99)
    assert result["sharpe_difference"] == 0
    assert result["ci_low"] == result["ci_high"] == 0
    assert result["p_value"] == 1


def test_inference_refuses_nonpaired_dates_or_tiny_samples():
    a, b = correlated_returns()
    dates = pd.date_range("2020-01-01", periods=len(a))
    with pytest.raises(ValueError, match="identical ordered dates"):
        paired_sharpe_bootstrap(pd.Series(a, index=dates), pd.Series(b, index=dates + pd.Timedelta(days=1)))
    with pytest.raises(ValueError, match="at least 32"):
        paired_sharpe_bootstrap(a[:20], b[:20])


def test_nonfinite_and_total_loss_are_rejected():
    with pytest.raises(ValueError, match="finite"):
        summarize(pd.DataFrame({"net_return": [0.1, np.nan]}))
    with pytest.raises(ValueError, match="greater than -1"):
        summarize(pd.DataFrame({"net_return": [0.1, -1]}))
