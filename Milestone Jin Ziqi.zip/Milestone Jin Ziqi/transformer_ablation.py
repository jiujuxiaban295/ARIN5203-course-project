"""Paired-seed, contiguous-block portfolio objective ablation."""
import hashlib
import json
import time

import numpy as np
import pandas as pd
import torch

from baseline import ASSETS, ROOT, backtest, metrics
from transformer_baseline import PortfolioTransformer, samples, infer

VARIANTS = {'Return only': (0., 0.), 'Risk': (1., 0.),
            'Turnover': (0., .001), 'Risk + Turnover': (1., .001)}
SEEDS = [42, 43, 44]
EPOCHS = 10
BLOCK = 126


def objective(weights, returns, risk, turnover):
    """First row is context, excluded from scored returns but used for drift."""
    gross = (weights[1:] * returns[1:]).sum(-1)
    pre = weights[:-1] * (1 + returns[:-1])
    pre = pre / pre.sum(-1, keepdim=True)
    trades = (weights[1:] - pre).abs().sum(-1)
    variance = gross.var(unbiased=False)
    return (-gross.mean() + risk*variance + turnover*trades.mean(),
            gross.mean(), variance, trades.mean())


def main():
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    path = ROOT / 'data/adjusted_close.csv'
    prices = pd.read_csv(path, index_col=0, parse_dates=True).loc[:'2020-12-31', ASSETS]
    x, y, dates, mean, std = samples(prices)
    train = dates <= pd.Timestamp('2017-12-31')
    tx, ty = x[train], y[train]
    vx, vd = x[~train], dates[~train]
    out = ROOT / 'outputs/transformer_ablation'
    out.mkdir(parents=True, exist_ok=True)
    # Freeze design before looking at this experiment's validation results.
    config = dict(variants=VARIANTS, seeds=SEEDS, epochs=EPOCHS, block_days=BLOCK,
                  risk_coefficient=1., turnover_coefficient=.001,
                  coefficient_selection='fixed pilot values; no validation coefficient search',
                  objective='negative mean daily gross return + lambda_risk * daily population variance + lambda_turn * mean total turnover',
                  variance_scope='within each contiguous training block',
                  train_scored_samples=len(tx)-1, first_scored_date=str(dates[train][1]),
                  prefix='recompute prior target using current parameters; prefix receives gradient; first overall sample context-only',
                  dropout=0., dropout_reason='avoid penalizing independent dropout noise as turnover',
                  d_model=32, heads=4, layers=1, feedforward=64, window=60,
                  learning_rate=.001, optimizer='Adam', gradient_clip=1.,
                  checkpoint_selection='max validation net Sharpe at 10 bps over 10 epochs',
                  validation_start=str(vd[0]), validation_end=str(vd[-1]),
                  scaler_fit='valid feature rows in 2005–2017 only',
                  data_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  torch_version=str(torch.__version__), device='cpu', final_test_used=False)
    (out/'config.json').write_text(json.dumps(config, indent=2))
    pd.DataFrame({'mean': mean, 'std': std}).to_csv(out/'scaler.csv')
    summaries, curves, starts_hashes = [], {}, {}
    begin = time.time()
    for name, (risk, turn) in VARIANTS.items():
        for seed in SEEDS:
            torch.manual_seed(seed)
            model = PortfolioTransformer(dropout=0.)
            init_hash = hashlib.sha256(b''.join(
                v.detach().numpy().tobytes() for v in model.state_dict().values())).hexdigest()
            if seed in starts_hashes:
                assert init_hash == starts_hashes[seed]
            starts_hashes[seed] = init_hash
            rng = np.random.default_rng(seed)
            optimizer = torch.optim.Adam(model.parameters(), lr=.001)
            folder = out / name.lower().replace(' + ', '_').replace(' ', '_') / f'seed{seed}'
            folder.mkdir(parents=True, exist_ok=True)
            best, history = -np.inf, []
            for epoch in range(1, EPOCHS+1):
                model.train()
                totals = np.zeros(4)
                count = 0
                for s in rng.permutation(np.arange(1, len(tx), BLOCK)):
                    e = min(s+BLOCK, len(tx))
                    optimizer.zero_grad()
                    terms = objective(model(tx[s-1:e]), ty[s-1:e], risk, turn)
                    if not torch.isfinite(terms[0]):
                        raise RuntimeError('Nonfinite loss')
                    terms[0].backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                    optimizer.step()
                    totals += np.array([v.item() for v in terms])*(e-s)
                    count += e-s
                weights = pd.DataFrame(infer(model, vx), index=vd, columns=ASSETS)
                score = metrics(backtest(prices, name, supplied_weights=weights))
                history.append(dict(epoch=epoch, **dict(zip(
                    ['train_loss','train_mean_gross','train_block_variance','train_turnover'], totals/count)), **score))
                if score['net_sharpe_zero_rf'] > best:
                    best, selected_epoch = score['net_sharpe_zero_rf'], epoch
                    torch.save(dict(state_dict=model.state_dict(), config=config,
                                    variant=name, seed=seed, epoch=epoch, initial_hash=init_hash,
                                    scaler_mean=mean.to_list(), scaler_std=std.to_list(),
                                    feature_order=[list(c) for c in mean.index]), folder/'best.pt')
            model.load_state_dict(torch.load(folder/'best.pt', weights_only=True)['state_dict'])
            weights = pd.DataFrame(infer(model, vx), index=vd, columns=ASSETS)
            weights.to_csv(folder/'validation_weights.csv')
            pd.DataFrame(history).to_csv(folder/'training_history.csv', index=False)
            for cost in [0, 5, 10, 20]:
                frame = backtest(prices, name, cost_bps=cost, supplied_weights=weights)
                frame.to_csv(folder/f'validation_{cost}bps.csv')
                summaries.append(dict(method=name, seed=seed, cost_bps=cost,
                                      selected_epoch=selected_epoch, **metrics(frame)))
                if cost == 10:
                    curves[(name, seed)] = frame.net_value
            print(f'{name}, seed {seed}: selected epoch {selected_epoch}, '
                  f'validation net Sharpe {best:.3f}', flush=True)
    result = pd.DataFrame(summaries)
    result.to_csv(out/'all_runs.csv', index=False)
    cols = ['annualized_net_return','annualized_volatility','net_sharpe_zero_rf',
            'max_drawdown','mean_daily_turnover']
    grouped = result.groupby(['method','cost_bps'])[cols].agg(['mean','std'])
    grouped.to_csv(out/'summary.csv')
    paired = result[result.cost_bps == 10].pivot(index='seed', columns='method', values=cols)
    deltas = []
    for name in list(VARIANTS)[1:]:
        for seed in SEEDS:
            deltas.append(dict(method=name, seed=seed, **{
                c: paired.loc[seed,(c,name)]-paired.loc[seed,(c,'Return only')] for c in cols}))
    pd.DataFrame(deltas).to_csv(out/'paired_differences.csv', index=False)
    baselines = []
    for method in ['Equal Weight', 'Minimum Variance']:
        frame = backtest(prices, method)
        baselines.append(dict(method=method, **metrics(frame)))
    pd.DataFrame(baselines).to_csv(out/'traditional_comparison.csv', index=False)
    config.update(initial_hashes=starts_hashes, runtime_seconds=time.time()-begin)
    (out/'config.json').write_text(json.dumps(config, indent=2))
    plot(result, curves, out)
    report(result, baselines, out)
    print(grouped.xs(10, level='cost_bps').to_string(), flush=True)


def plot(result, curves, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    fig, ax = plt.subplots(2, 2, figsize=(12, 8))
    for name in VARIANTS:
        frame = pd.concat([curves[(name,s)] for s in SEEDS], axis=1)
        line, = ax[0,0].plot(frame.index, frame.mean(axis=1), label=name)
        ax[0,0].fill_between(frame.index, frame.min(axis=1), frame.max(axis=1), alpha=.12, color=line.get_color())
        costs = result[result.method == name].groupby('cost_bps').net_sharpe_zero_rf.agg(['mean','std'])
        ax[0,1].errorbar(costs.index, costs['mean'], yerr=costs['std'], label=name, capsize=3)
    ax[0,0].set(title='Validation net value: mean and seed range (10 bps)', ylabel='Net value')
    ax[0,0].xaxis.set_major_locator(mdates.YearLocator())
    ax[0,0].xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax[0,1].set(title='Cost sensitivity: mean ± seed SD', xlabel='Cost (bps)', ylabel='Net Sharpe (zero rf)')
    sub = result[result.cost_bps == 10]
    for a, col, title in [(ax[1,0],'annualized_volatility','Annualized volatility (%)'),
                           (ax[1,1],'mean_daily_turnover','Mean daily total turnover (%)')]:
        g = sub.groupby('method')[col].agg(['mean','std']).reindex(VARIANTS)
        a.bar(range(4), 100*g['mean'], yerr=100*g['std'], capsize=4)
        a.set_xticks(range(4), ['Return only','Risk','Turnover','Both'])
        a.set(title=title)
    ax[0,0].legend(fontsize=8)
    ax[0,1].legend(fontsize=8)
    for a in ax.flat:
        a.grid(alpha=.2)
    fig.suptitle('Transformer ablation | validation 2018–2020 | seeds 42, 43, 44')
    fig.tight_layout()
    fig.savefig(out/'ablation.png', dpi=160)
    plt.close(fig)


def report(result, baselines, out):
    sub = result[result.cost_bps == 10]
    lines = ['# Transformer 消融：初步验证结果', '',
             '训练期 2005–2017；验证期 2018–2020。2021–2025 未用于本次实验。', '',
             '四种设置均从头训练，种子 42/43/44，配对种子使用相同初始权重和块顺序；每次 10 epochs，按验证净 Sharpe 选 checkpoint。', '',
             '| 设置 | 年化净收益 | 波动率 | 净 Sharpe | 最大回撤 | 日均总买卖换手 |',
             '|---|---:|---:|---:|---:|---:|']
    cols = ['annualized_net_return','annualized_volatility','net_sharpe_zero_rf','max_drawdown','mean_daily_turnover']
    for name in VARIANTS:
        rows = sub[sub.method == name]
        vals = []
        for c in cols:
            scale = 1 if c == 'net_sharpe_zero_rf' else 100
            suffix = '' if scale == 1 else '%'
            vals.append(f'{rows[c].mean()*scale:.3f} ± {rows[c].std()*scale:.3f}{suffix}')
        lines.append('| '+name+' | '+' | '.join(vals)+' |')
    for row in baselines:
        vals = [f'{row[c]:.3f}' if c == 'net_sharpe_zero_rf' else f'{100*row[c]:.3f}%' for c in cols]
        lines.append('| '+row['method']+' | '+' | '.join(vals)+' |')
    lines += ['', 'Transformer 数字为三个种子的均值 ± 样本标准差；传统策略为单个确定性结果。成本 10 bps，Sharpe 使用零无风险收益假设。标准差反映训练随机性，不是市场不确定性的置信区间。', '',
              '## 实验口径与限制', '',
              '- 风险系数固定为 1，换手系数固定为 0.001：风险项的系数以日收益方差口径定义，换手系数对应 10 bps 总买卖金额惩罚。它们是第一轮试验值，没有进行系数搜索。',
              '- 每块最多 126 个连续收益日期，额外输入前一日样本用于持仓漂移；块内按当前模型重新计算前置目标且保留梯度。训练序列第一个样本仅用作上下文，其余样本每轮恰好评分一次。',
              '- 风险为块内总体方差；换手为目标与漂移后持仓差的 L1 范数。评价仍扣除实际假设成本，不能把训练惩罚当成已付成本。',
              '- 四组均关闭 dropout，避免随机 dropout 造成虚假配置变动；架构仍为 1 层、32 维、4 heads。所有设置共同变更，因此内部可比。',
              '- 原先单种子随机 batch、dropout=0.1 的基础试跑保留，但不作为本轮消融的无惩罚对照。本轮重新训练 Return only。',
              '- 这也是选 checkpoint 的验证期，成绩存在选型偏差，不能当作独立最终测试。未计算统计显著性；后续需要系数敏感性、最终保留测试和配对移动块 bootstrap。', '',
              '复现：`python3 transformer_ablation.py`。完整配置、初始权重哈希、模型、标准化参数、训练日志、逐日权重和成本情景结果均保存在本目录。']
    (out/'milestone_ablation_notes.md').write_text('\n'.join(lines)+'\n')


if __name__ == '__main__':
    main()
