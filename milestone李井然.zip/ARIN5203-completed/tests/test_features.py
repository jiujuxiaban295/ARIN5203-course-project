import numpy as np
import pandas as pd
from portfolio.features import make_features, TrainScaler, weekly_samples


def market():
    dates = pd.bdate_range("2016-01-01", "2021-02-01")
    rng = np.random.default_rng(3)
    return pd.DataFrame(100*np.exp(np.cumsum(rng.normal(0,.01,(len(dates),2)),axis=0)),index=dates,columns=["a","b"])


def test_future_price_cannot_change_past_features_or_scaler():
    p = market(); f = make_features(p)
    s = TrainScaler().fit(f,"2016","2017")
    changed = p.copy(); changed.loc["2020":] *= 9
    f2 = make_features(changed); s2 = TrainScaler().fit(f2,"2016","2017")
    np.testing.assert_allclose(f.loc[:"2019"],f2.loc[:"2019"],equal_nan=True)
    np.testing.assert_allclose(s.mean,s2.mean)


def test_execution_is_after_last_feature_and_labels_do_not_cross_split():
    p = market(); f = make_features(p)
    samples = weekly_samples(p,f,"2018-01-01","2020-12-31",60)
    assert (samples.decision_dates < samples.execution_dates).all()
    assert samples.end_dates.max() <= pd.Timestamp("2020-12-31")
    for i, execution in enumerate(samples.execution_dates):
        pos = p.index.get_loc(execution)
        np.testing.assert_allclose(samples.x[i], f.iloc[pos-60:pos],rtol=1e-6)
    assert not (samples.end_dates > pd.Timestamp("2021-01-01")).any()
