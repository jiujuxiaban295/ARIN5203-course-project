import numpy as np
import pandas as pd
from portfolio.baselines import baseline_targets
from portfolio.features import make_features, weekly_samples


def test_baselines_do_not_see_prices_after_decision():
    rng=np.random.default_rng(4)
    dates=pd.bdate_range("2016-01-01","2019-02-01")
    prices=pd.DataFrame(100*np.exp(np.cumsum(rng.normal(0,.01,(len(dates),3)),axis=0)),
                        index=dates,columns=list("abc"))
    samples=weekly_samples(prices,make_features(prices),"2018-01-01","2018-02-01")
    # Only compare the first signal: every later price is unobserved for it.
    original,_=baseline_targets(prices,samples)
    changed=prices.copy();changed.loc[changed.index>samples.decision_dates[0]] *= np.array([2.,.5,4.])
    modified,_=baseline_targets(changed,samples)
    for name in original:
        np.testing.assert_allclose(original[name].iloc[0],modified[name].iloc[0],atol=1e-10)
        assert (original[name].to_numpy()>=0).all()
        np.testing.assert_allclose(original[name].sum(axis=1),1)
