import torch
from portfolio.models import TransformerAllocator, LSTMAllocator, sequential_objective


def test_neural_simplex_and_gradient():
    torch.manual_seed(1)
    for model in [TransformerAllocator(),LSTMAllocator()]:
        weights = model(torch.randn(8,60,18))
        assert torch.all(weights >= 0)
        torch.testing.assert_close(weights.sum(-1),torch.ones(8))
        loss = sequential_objective(weights,torch.randn(8,6)*.02,5,.0025)
        loss.backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())


def test_drift_turnover_is_not_target_weight_difference():
    w = torch.tensor([[.5,.5],[.5,.5]])
    r = torch.tensor([[1.,0.],[0.,0.]])
    # Second target equals first, but market drift still requires rebalancing.
    base = sequential_objective(w,r,0,0)
    with_turnover = sequential_objective(w,r,0,1)
    torch.testing.assert_close(with_turnover-base,torch.tensor((1+1/3)/2))
