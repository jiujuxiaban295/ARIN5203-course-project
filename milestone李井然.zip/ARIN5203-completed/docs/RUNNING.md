# 运行与交付说明

本次交付是代码、真实运行结果和图表，不生成课程报告正文。实验协议见 `EXPERIMENT_PROTOCOL.md`，模型来源见 `model_selection.md`。原始调研文件保留。

## 安装与数据

Python 3.11。已运行环境的精确依赖在 `requirements-lock.txt`。在独立虚拟环境中执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python -m pip install -e . --no-deps
python scripts/import_dataset.py
python -m pytest -q
```

导入器默认只接受仓库 `5203最终版数据.zip` 的固定 SHA256，离线校验内部文件并输出 `data/final_zip/`。不调用 Yahoo/FRED 另行下载，不读取根目录五资产旧 CSV，也不读取旧 `data/market.csv`。若团队未来更换数据，应建立新的实验目录、更新固定 SHA 并重新验证，不能覆盖结果后声称同一实验。

## 重跑

```bash
python scripts/run_experiment.py --data data/final_zip --output results/full --stage train
python scripts/run_experiment.py --data data/final_zip --output results/full --stage evaluate --foundation
python scripts/plot_results.py --results results/full
python scripts/diagnostics.py --results results/full
python scripts/verify_results.py --data data/final_zip --output results/full
```

首次运行预训练辅助模型需要从 Hugging Face 下载约 476 MB 官方 safetensors。默认缓存到仓库相邻的 `../foundation-cache`（可由 adapter 参数另设），不会把 checkpoint 加入补充材料。第一次训练后 `selection.json` 和 `locked_manifest.json` 固定配置、行情、RF、源代码及 checkpoint 哈希；不兼容的缓存会拒绝复用。改变设置请使用新的 `--output`。不要先看测试结果再改参数。

若结果包已包含 `foundation_cache/`，输入 SHA 一致时直接复用冻结预测，不需要重新下载大模型。训练模型的 checkpoint 单独留作研究复现；课程补充材料包按官方规定排除所有 checkpoint。完整实验包可以直接验证已有 checkpoint。若只有课程补充材料包，请使用新的输出目录重训，避免把缺少 checkpoint 的历史日志当作可恢复训练：

```bash
python scripts/run_experiment.py --output results/reproduced --stage train
python scripts/run_experiment.py --output results/reproduced --stage evaluate --foundation
python scripts/plot_results.py --results results/reproduced
python scripts/diagnostics.py --results results/reproduced
python scripts/verify_results.py --data data/final_zip --output results/reproduced
```

也可在训练前把 `results/full/foundation_cache` 复制到新输出目录同名子目录；预测输入一致时将复用缓存。否则重新下载官方权重推理。已打包的 `results/full` 保留为本次原始证据。

## 主要产物

| 路径 | 内容 |
|---|---|
| `data/final_zip/provenance.json`、`quality.json` | 指定 ZIP 来源、SHA、字段和完整性验证 |
| `results/full/config.json`、`scaler.json`、`*_calendar.csv` | 实际设置、仅训练拟合的缩放、信号／执行／估值日 |
| `results/full/training/*/history.csv`、`run.json` | 各候选训练轨迹与验证指标；checkpoint 独立保留 |
| `results/full/validation_search.csv`、`selection.json` | 网格搜索及选中参数，测试未参与选择 |
| `results/full/metrics.csv`、`main_results.csv` | 所有策略、各 seed／组合与三档费用的指标 |
| `results/full/daily/`、`targets/` | 逐日收益／成本／财富、每周目标权重 |
| `results/full/yearly_metrics.csv` | 各年度表现，包含失败期，不挑年份 |
| `results/full/bootstrap.json` | 配对 studentized block-bootstrap 区间 |
| `results/full/foundation_cache/` | Chronos 冻结预测、精确 revision、来源与固定映射 |
| `results/full/figures/` | PNG 与矢量 PDF 图，方便团队后续报告排版 |

收益率使用小数，交易费配置使用 bps，换手是买入加卖出 L1。`max_drawdown` 为负数。净 Sharpe 的无风险基准是两工作日滞后 DTB3 换算值。三种子权重平均组合是真实再回测的独立配置规则，不是对种子 Sharpe 求平均，也不是将三份收益序列拼成更大样本。

## 与已有调研／另一分支的关系

保持最终合并 proposal 的资产、切分、周频开盘执行和核心消融。实现使用 PyTorch、SciPy 等标准库，参考 DeepDow 的分层设计而独立实现顺序损失与 softmax，不声称调用了未安装的 DeepDow 组件。仓库另一分支的 Lightning/DeepDow 训练计划属于独立实现；本次所有运行命令明确使用 `scripts/run_experiment.py` 与 `src/portfolio/`，避免同名 `src/data.py` 等模块混用。

严格自融资费用、完整 split 连续 batch、固定正弦位置编码、三种子完整实验与明确的 RF 转换是本实现具体选择，协议已记录。最终写报告时应描述实际运行设置，而不是抄写未经运行的原计划。报告中应引用使用的模型、代码与数据来源；不要声称原始 Portfolio Transformer 的官方 checkpoint 已被加载。
