import unittest
import numpy as np
import pandas as pd
import torch
from final_proposal_experiment import weekly_samples,rf_returns,backtest_weekly,ASSETS
from transformer_baseline import PortfolioTransformer

class FinalProposalTests(unittest.TestCase):
    def prices(self):
        rng=np.random.default_rng(2)
        index=pd.bdate_range('2005-01-03','2020-12-31')
        p=pd.DataFrame(100*np.cumprod(1+rng.normal(0,.01,(len(index),6)),axis=0),index=index,columns=ASSETS)
        return p

    def test_split_features_and_next_open(self):
        p=self.prices()
        x,y,s,m,sd=weekly_samples(p,p)
        self.assertTrue((s.signal_date<s.execution_date).all())
        tr=s[s.split=='train']; va=s[s.split=='validation']
        self.assertTrue((tr.execution_date>=pd.Timestamp('2006-01-01')).all())
        self.assertTrue((tr.holding_end<=pd.Timestamp('2017-12-31')).all())
        self.assertTrue((va.execution_date>=pd.Timestamp('2018-01-01')).all())
        self.assertTrue((va.holding_end<=pd.Timestamp('2020-12-31')).all())
        self.assertEqual(tuple(x.shape[1:]),(60,18))
        changed=p.copy(); cut=va.execution_date.iloc[3]
        changed.loc[cut:]*=np.arange(1,7)
        xx,yy,ss,mm,sdd=weekly_samples(changed,changed)
        np.testing.assert_allclose(x[s.execution_date<=cut],xx[s.execution_date<=cut])
        np.testing.assert_allclose(m,mm); np.testing.assert_allclose(sd,sdd)
        row=s.iloc[20]
        np.testing.assert_allclose(y[20],(p.iloc[int(row.end)]/p.iloc[int(row.start)]-1).to_numpy(),atol=1e-7)

    def test_weekly_holdings_are_not_daily_rebalanced(self):
        p=self.prices(); _,_,s,_,_=weekly_samples(p,p)
        vs=s[s.split=='validation'].iloc[:3]
        idx=p.index[int(vs.start.iloc[0]):int(vs.end.iloc[-1])+1]
        rates=pd.Series(3.,index=pd.bdate_range('2017-01-01','2020-12-31'))
        rf=rf_returns(idx,rates)
        frame=backtest_weekly(p,vs,np.ones((3,6))/6,rf,0)
        self.assertEqual(frame.rebalanced.sum(),3)
        self.assertTrue((frame.loc[~frame.rebalanced,'turnover']==0).all())
        first=vs.iloc[0]; end=int(first.end); start=int(first.start)
        self.assertAlmostEqual(frame.loc[:p.index[end],'net_value'].iloc[-1],(p.iloc[end]/p.iloc[start]).mean())
        self.assertTrue((pd.to_datetime(frame.rf_rate_date)<pd.to_datetime(frame.period_start)).all())
        fee=backtest_weekly(p,vs,np.ones((3,6))/6,rf,25)
        np.testing.assert_allclose(fee.gross_return-fee.net_return,.0025*fee.turnover,atol=1e-12)

    def test_six_asset_output(self):
        m=PortfolioTransformer(dropout=0.,n_assets=6)
        w=m(torch.randn(2,60,18))
        self.assertEqual(tuple(w.shape),(2,6))
        torch.testing.assert_close(w.sum(-1),torch.ones(2))

if __name__=='__main__': unittest.main()
