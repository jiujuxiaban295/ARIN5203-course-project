"""Validated adjusted ETF prices and a lagged Treasury-bill benchmark.

Market prices are never forward- or backward-filled.  A missing asset/session is
an error rather than an implicit zero return.  FRED's current DTB3 history is not
a real-time vintage.  Its dates are observation dates, so the benchmark is
conservatively made available two business days later.  It is used only to score
excess returns, never as a model input.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

TICKERS = ("SPY", "EFA", "EEM", "IEF", "TLT", "GLD")


def _file(path: str | Path, filename: str) -> Path:
    path = Path(path)
    return path / filename if path.is_dir() else path


def validate_market_long(frame: pd.DataFrame, tickers: Sequence[str] = TICKERS) -> dict:
    """Fail closed on duplicate, missing, nonfinite, nonpositive or partial rows."""
    required = {"date", "ticker", "open", "close"}
    if not required.issubset(frame.columns):
        raise ValueError(f"Market data needs columns {sorted(required)}")
    if frame.empty:
        raise ValueError("Market data is empty")
    dates = pd.to_datetime(frame["date"], errors="raise").dt.normalize()
    if dates.isna().any() or frame["ticker"].isna().any():
        raise ValueError("Missing date or ticker")
    normalized = frame.assign(date=dates)
    if normalized.duplicated(["date", "ticker"]).any():
        raise ValueError("Duplicate date/ticker observations")
    actual = set(normalized["ticker"])
    if actual != set(tickers):
        raise ValueError(f"Expected tickers {list(tickers)}, got {sorted(actual)}")
    values = normalized[["open", "close"]].to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values <= 0).any():
        raise ValueError("Adjusted prices must be positive and finite; no fill is allowed")
    counts = normalized.groupby("date")["ticker"].nunique()
    if not counts.eq(len(tickers)).all():
        bad = counts[counts.ne(len(tickers))].index.strftime("%Y-%m-%d").tolist()
        raise ValueError(f"Incomplete cross-asset sessions; no fill is allowed: {bad[:10]}")
    unique_dates = pd.DatetimeIndex(dates.unique()).sort_values()
    if (unique_dates.day_of_week > 4).any():
        raise ValueError("Unexpected weekend equity session")
    prices = normalized.pivot(index="date", columns="ticker", values="close").sort_index()
    returns = prices.pct_change(fill_method=None)
    extreme = []
    for date, row in returns.iterrows():
        for ticker, value in row.items():
            if pd.notna(value) and abs(value) > 0.25:
                extreme.append({"date": date.strftime("%Y-%m-%d"), "ticker": ticker, "return": float(value)})
    # Holiday gaps are reported, not fabricated or treated as missing sessions.
    gaps = []
    for previous, current in zip(unique_dates[:-1], unique_dates[1:]):
        if (current - previous).days > 4:
            gaps.append({"from": previous.strftime("%Y-%m-%d"), "to": current.strftime("%Y-%m-%d"), "calendar_days": (current - previous).days})
    return {
        "tickers": list(tickers),
        "rows": int(len(normalized)),
        "sessions": int(len(unique_dates)),
        "start": unique_dates.min().strftime("%Y-%m-%d"),
        "end": unique_dates.max().strftime("%Y-%m-%d"),
        "duplicate_date_tickers": 0,
        "missing_prices": 0,
        "imputed_market_prices": 0,
        "extreme_close_returns_abs_gt_25pct": extreme,
        "calendar_gaps_gt_4_days": gaps,
    }


def load_market(path: str | Path, tickers: Sequence[str] = TICKERS) -> pd.DataFrame:
    """Load market.csv; columns are (open/close, ticker), in the declared order."""
    frame = pd.read_csv(_file(path, "market.csv"), parse_dates=["date"])
    validate_market_long(frame, tickers)
    market = frame.pivot(index="date", columns="ticker", values=["open", "close"])
    columns = pd.MultiIndex.from_product([["open", "close"], list(tickers)], names=["field", "ticker"])
    market = market.reindex(columns=columns).sort_index().astype(float)
    market.index = pd.DatetimeIndex(market.index).tz_localize(None).normalize()
    market.index.name = "date"
    return market


def discount_yield_to_daily(
    percent: pd.Series | np.ndarray | float,
    maturity_days: int = 91,
    trading_days: int = 252,
) -> pd.Series | np.ndarray | float:
    """Convert annual bank-discount percent to a trading-day-equivalent return.

    Treasury bill price / face = 1 - d * maturity_days / 360.  The holding-period
    return is face / price - 1, annualized with 365 calendar days and translated
    to 252 trading periods.  DTB3 gives a 3-month quotation, not a particular
    security; fixed 91-day maturity is an explicit benchmark approximation.
    """
    if maturity_days <= 0 or trading_days <= 0:
        raise ValueError("Maturity and trading-day basis must be positive")
    price = 1.0 - percent / 100.0 * maturity_days / 360.0
    if np.any(np.asarray(price) <= 0) or not np.isfinite(np.asarray(price)).all():
        raise ValueError("Invalid discount yield")
    return np.power(1.0 / price, 365.0 / (maturity_days * trading_days)) - 1.0


def load_risk_free(
    path: str | Path,
    index: pd.DatetimeIndex,
    lag_business_days: int = 2,
    max_staleness_days: int = 14,
) -> pd.Series:
    """Load a backward-asof, conservatively lagged DTB3 daily-return benchmark.

    Missing holiday quotes use the last *already available* observation.  There
    is no backward fill and observations older than 14 days are rejected.
    Return units are decimal return per trading day, not annual yield percent.
    Two business days deliberately allow for the next-day H.15/FRED release;
    true vintage publication timestamps are unavailable in the current CSV.
    """
    if lag_business_days < 1:
        raise ValueError("Risk-free observations must have at least one business-day lag")
    requested = pd.DatetimeIndex(index).tz_localize(None).normalize()
    if requested.has_duplicates or not requested.is_monotonic_increasing:
        raise ValueError("Risk-free target dates must be unique and sorted")
    if len(requested) == 0:
        return pd.Series([], index=requested, name="risk_free", dtype=float)
    frame = pd.read_csv(_file(path, "risk_free.csv"), parse_dates=["date"])
    if "DTB3" not in frame:
        raise ValueError("risk_free.csv requires date and DTB3 columns")
    if frame["date"].duplicated().any():
        raise ValueError("Duplicate risk-free observation dates")
    frame["DTB3"] = pd.to_numeric(frame["DTB3"], errors="coerce")
    frame = frame.dropna(subset=["DTB3"]).sort_values("date")
    if frame.empty or not np.isfinite(frame["DTB3"]).all():
        raise ValueError("No finite risk-free observations")
    frame["available_date"] = frame["date"] + pd.offsets.BDay(lag_business_days)
    matched = pd.merge_asof(
        pd.DataFrame({"target_date": requested}),
        frame[["date", "available_date", "DTB3"]],
        left_on="target_date", right_on="available_date", direction="backward",
    )
    if matched["DTB3"].isna().any():
        raise ValueError("Risk-free history has no prior available quote for an evaluation date")
    age = (matched["target_date"] - matched["date"]).dt.days
    if age.gt(max_staleness_days).any():
        raise ValueError("Risk-free quote is stale beyond the allowed threshold")
    result = pd.Series(discount_yield_to_daily(matched["DTB3"]).to_numpy(), index=requested, name="risk_free")
    result.attrs.update({"source": "FRED DTB3", "lag_business_days": lag_business_days,
                         "maturity_days_assumption": 91, "trading_days": 252,
                         "vintage": "current retrieved history; not point-in-time vintages",
                         "max_source_age_days": int(age.max())})
    return result
