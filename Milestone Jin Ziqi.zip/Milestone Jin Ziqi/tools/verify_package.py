"""Offline checks of frozen data and saved experiment artifacts; no retraining."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
import pandas as pd
import torch
from final_proposal_experiment import DATA,OUT,ASSETS,weekly_samples,metric
from transformer_baseline import PortfolioTransformer,infer

def main():
    manifest=ROOT/'MANIFEST_SHA256.json'
    if manifest.exists():
        for name,digest in json.loads(manifest.read_text()).items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    meta=json.loads((DATA/'metadata.json').read_text())
    for name,digest in meta['sha256'].items():
        assert hashlib.sha256((DATA/name).read_bytes()).hexdigest()==digest,name
    assert hashlib.sha256((DATA/'ARIN5203_Proposal.pdf').read_bytes()).hexdigest()==meta['proposal_sha256']
    close=pd.read_csv(DATA/'adjusted_close.csv',index_col=0,parse_dates=True).loc[:'2020-12-31',ASSETS]
    opening=pd.read_csv(DATA/'adjusted_open.csv',index_col=0,parse_dates=True).loc[close.index,ASSETS]
    x,y,s,mean,std=weekly_samples(close,opening)
    vx=x[s.split.eq('validation').to_numpy()]
    config=json.loads((OUT/'config.json').read_text());torch.set_num_threads(2)
    n=0
    for path in (OUT/'candidates').glob('*/seed*/best.pt'):
        c=torch.load(path,weights_only=True)
        assert c['initial_hash']==config['initial_hashes'][str(c['seed'])]
        np.testing.assert_allclose(c['scaler_mean'],mean)
        np.testing.assert_allclose(c['scaler_std'],std)
        m=PortfolioTransformer(dropout=0.,n_assets=6);m.load_state_dict(c['state_dict'])
        saved=pd.read_csv(path.parent/'weekly_weights.csv',index_col=0).to_numpy()
        np.testing.assert_allclose(infer(m,vx),saved,atol=1e-7)
        n+=1
    assert n==27
    result=pd.read_csv(OUT/'selected_results.csv')
    for _,row in result.iterrows():
        if row.seed==-1:path=OUT/f'{row.method.lower().replace(" ","_")}_{int(row.cost_bps)}bps.csv'
        else:path=OUT/'candidates'/f'risk{row.risk}_turn{row.turnover}'/f'seed{int(row.seed)}'/f'validation_{int(row.cost_bps)}bps.csv'
        frame=pd.read_csv(path,index_col=0,parse_dates=True)
        for key,val in metric(frame).items():np.testing.assert_allclose(val,row[key],atol=1e-10)
        assert frame.index.max()<=pd.Timestamp('2020-12-31')
        assert (pd.to_datetime(frame.rf_rate_date)<pd.to_datetime(frame.period_start)).all()
    assert len(result)==42
    print('PASS: hashes, 27 saved models, paired initializations, scalers and 42 strategy/cost summaries.')

if __name__=='__main__':main()
