# 基模选择与实现口径

核查日期：2026-11-03。本文是工程决策记录，不是课程报告正文。

## 采用的主模型

采用 **小型 Transformer Encoder 直接配置模型，从随机初始化训练**，研究依据是 Portfolio Transformer 的端到端配置思路，范围遵循 `proposal_merged.md`。明确区分：这是本项目的基础网络，不是下载了预训练权重的 foundation model，也不是完整复现原论文。

[Portfolio Transformer 原论文](https://arxiv.org/abs/2206.03246)直接输出资产配置并优化 Sharpe；原模型使用 encoder-decoder、专门的时间编码和门控。本次在作者 arXiv 页面和公开检索中没有核实到可直接加载的官方预训练 checkpoint，因此不引用不明第三方权重、不声称载入原作者模型。项目改为考察同一紧凑网络的风险／换手目标消融，保留 LSTM 与传统策略作对照。

建议结构（最终参数以实际运行配置和保存的 checkpoint 为准）：

| 部分 | 设计 |
|---|---|
| 输入 | 截至信号日收盘的 60 个交易日；6 资产 × 收益率、20 日波动率、20 日动量，共 18 个特征 |
| 投影 | 每个时间步的 18 维特征投影到 32 维 |
| 时间编码 | 确定性正弦位置编码 |
| 编码器 | 2 层、4 个 attention heads、小型 feed-forward、dropout |
| 配置头 | 编码序列最后一个时间步经 LayerNorm 后映射到 6 个 logits，再用 softmax 保证非负且总和为 1 |
| 训练 | 只使用 2006–2017 训练收益；2018–2020 选超参数和 epoch；2021–2025 仅最终评价 |
| 主对照 | Transformer 的无惩罚／仅风险／仅换手／双惩罚；LSTM 使用双惩罚 |

整个输入窗口在交易前已知，因此窗口内的双向 self-attention 不构成未来信息泄漏；禁止将窗口外未来价格输入编码器。信号收盘后生成，下一交易日开盘执行。

## 为什么不直接用 Chronos / TimesFM 替换

| 候选 | 核实的官方发布 | 项目决策 |
|---|---|---|
| [Chronos-T5](https://huggingface.co/amazon/chronos-t5-base) | 预训练概率预测模型；官方有 8M–710M 不同规模权重；Apache-2.0 | 预测输出并非权重；需要另加预测到配置环节，与本项目直接配置问题不同 |
| [Chronos-2](https://huggingface.co/amazon/chronos-2) | 120M encoder-only，多变量／协变量、多步分位数预测；真实与合成数据预训练；Apache-2.0 | 可作将来的辅助预测 baseline；当前资料不足以证明预训练语料与六 ETF 测试期完全无重叠，不纳入主回测 |
| [Chronos-2-Synth](https://huggingface.co/autogluon/chronos-2-synth) | 官方模型卡明确仅使用合成的单变量与多变量数据；Apache-2.0 | 已选为冻结的预训练辅助 baseline，独立于主模型；使用事先固定的预测→配置规则，保持预训练与端到端配置实验的区别 |
| [TimesFM](https://github.com/google-research/timesfm) | 官方提供预测 checkpoint；2.5 为 200M；3.0 支持多变量及协变量 | 同样需要额外配置层；预训练截止／语料重叠需要另行审计。3.0 下载权重采用非商业、非生产许可，不能将仓库代码的 Apache-2.0 泛化到所有权重 |

上述模型的预测能力不构成优于等权或传统配置的实证证据。将 2024–2026 发布的权重用于 2021 年起的历史测试，也不能表述为当时可部署的真实交易业绩。只输入历史窗口并不足以解决预训练污染；这需要另审计 checkpoint 的训练来源和日期。

## 已实现的预训练辅助基线

- checkpoint：`autogluon/chronos-2-synth`，固定实际下载 revision `3607918a9fd027d5c465d8213e46b98e2c041cea`；safe tensor 权重为 475,963,368 bytes。
- 官方包：`chronos-forecasting==2.3.2`。代码位于 `src/portfolio/pretrained.py`，下载及独立缓存入口为 `scripts/cache_foundation.py`；不需要云服务或付费 API。
- 输入：六 ETF 截至每个决策日收盘的 60 日 adjusted-close。每个历史决策日是一项独立任务、六资产在该任务内联合建模；显式设置 `cross_learning=False`，防止同一 batch 中更晚的历史窗口泄漏至较早的预测。
- 输出：5 个交易日预测路径的中位数。取第 5 日预测相对当前收盘的变化，固定 `softmax(预测收益 / 0.05)` 转成配置。该温度和 horizon 未根据测试收益调参；不做任何模型微调。真正执行仍由共用回测器在下一交易日开盘完成，预测收盘收益仅为配置信号。
- 缓存：保存 forecast、weights、信号日期、输入 SHA-256、checkpoint revision 和包版本。只接受完整、有限、正数的价格历史，不填补缺失价格。
- 数据：正式缓存仅来自 `5203最终版数据.zip`，SHA-256 为 `97bf4b43d1825dbe2b0a976c5ab9da6fb59d46a674e4149e5fe889893d512fe7`；使用导入到 `data/final_zip` 的数据，不使用其他价格文件替代。
- 实际运行：验证期 157 个决策、测试期 261 个决策已生成缓存，分别写到 `results/full/foundation_cache/validation` 和 `results/full/foundation_cache/test`。本机 CPU 4 线程此次耗时约 4.45 秒和 3.39 秒（含每次加载模型，非通用性能承诺）。权重和在浮点容差内为 1。
- 回归检查：未来价格修改不改变较早窗口；未观测／缺失历史拒绝；权重非负归一；共同改变价格单位不影响配置。测试不依赖网络或大模型下载。
- 真实模型批次隔离检查：2018-01-05 单独预测，与加入 2025-01-10 历史窗口后同批预测的早期配置，最大绝对差为 `1.85e-7`，通过 `rtol=1e-5, atol=1e-7` 浮点容差。检查记录为 `results/full/foundation_causality_check.json`；这项检查仅检验任务隔离，不使用未来收益选参。

主 runner 加 `--foundation` 后采用同一回测器评价这些冻结配置。仅生成预测缓存本身不代表已经完成收益回测或证明模型优于其他策略。

## DeepDow 与归属

[DeepDow 的官方 layers 文档](https://deepdow.readthedocs.io/en/latest/source/layers.html)提供数据形状与可组合 PyTorch 配置层的接口；[losses 文档](https://deepdow.readthedocs.io/en/latest/source/losses.html)明确标准 loss 要让 batch 样本相互独立。因此跨周持仓漂移与换手应由本项目的连续时间循环计算，不能把打乱样本后的相邻权重差当作换手。

[DeepDow 仓库](https://github.com/jankrepl/deepdow)为 Apache-2.0。如果实际运行仅参考其接口而没有调用其代码，应在最终实验记录中写“参考其设计、独立实现”，不声称复用组件。若后续复制或修改源码，应保留版权及许可证通知，记录来源 commit。[PyTorch 许可证](https://github.com/pytorch/pytorch/blob/main/LICENSE)要求保留其分发通知；正常作为依赖调用并记录安装版本即可。

## 结果解释的边界

- 数据量仅约十余年训练市场日，紧凑网络降低计算负担，但不能保证避免过拟合。
- 基础模型的训练 checkpoint 是本项目数据上的模型，不是通用预训练模型。
- 固定六只现存 ETF 是事先指定的研究宇宙；结论不能外推为全市场选股或消除 survivorship bias。
- 调参以验证期为准，不能看测试 Sharpe 后再改惩罚参数、资产列表或模型大小。
- 结果落后基准、置信区间跨零、成本提高后优势消失，都应保留在机器可读结果中。

## 原始来源索引

1. Kisiel & Gorse, *Portfolio Transformer for Attention-Based Asset Allocation*, arXiv:2206.03246，2022：[作者论文](https://arxiv.org/abs/2206.03246)。
2. Amazon Science, Chronos 官方代码与 checkpoint 列表：[仓库](https://github.com/amazon-science/chronos-forecasting)。
3. Google Research, TimesFM 官方版本及权重许可说明：[README](https://github.com/google-research/timesfm/blob/master/README.md)。
4. Krepl, DeepDow 官方接口与 loss 约束：[文档](https://deepdow.readthedocs.io/en/latest/)。

上游事实以访问当日为准。实际已运行的外部预训练模型仅为本文件明确记录的冻结 Chronos-2-Synth；其他候选只作来源核查与选择比较。
