"""Train/validation selection, locked test evaluation and inspectable artifacts."""
from __future__ import annotations
import hashlib
from importlib.metadata import version
import itertools
import json
import random
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from .data import load_market, load_risk_free
from .features import make_features, TrainScaler, weekly_samples
from .models import TransformerAllocator, LSTMAllocator, sequential_objective
from .baselines import baseline_targets
from .backtest import backtest
from .metrics import summarize, paired_sharpe_bootstrap


def write_json(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+".tmp")
    temporary.write_text(json.dumps(content, indent=2, default=str, allow_nan=False)+"\n")
    temporary.replace(path)


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _content_hash(content):
    return hashlib.sha256(json.dumps(content, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def experiment_identity(data, config):
    """Bind reusable training to exact inputs, software and modeling code.

    Paths are deliberately absent: copying a completed experiment directory
    preserves its identity, but modifying data, configuration or the relevant
    implementation never silently reuses an earlier validation search.
    """
    source = Path(__file__).parent
    return {
        "schema_version": 1,
        "config_sha256": _content_hash(config),
        "market_sha256": _sha256(Path(data)/"market.csv"),
        "risk_free_sha256": _sha256(Path(data)/"risk_free.csv"),
        "source_sha256": {name: _sha256(source/name) for name in
                           ["experiment.py", "models.py", "features.py", "backtest.py", "metrics.py", "data.py", "baselines.py"]},
        "runtime_versions": {name: version(name) for name in ["torch", "numpy", "pandas", "scipy"]},
    }


def _candidate_signature(identity, architecture, risk, turnover, seed):
    return _content_hash({"experiment": identity, "architecture": architecture,
                          "risk": float(risk), "turnover": float(turnover), "seed": int(seed)})


def _checkpoint_path(output, run):
    """Selected checkpoint paths are relative to the portable experiment root."""
    root = Path(output).resolve()
    candidate = (root/run["checkpoint"]).resolve()
    if not candidate.is_relative_to(root):
        raise RuntimeError("Selected checkpoint is outside the experiment directory")
    return candidate


def _prepare_training_output(data, output, config):
    identity = experiment_identity(data, config)
    identity_path = output/"experiment_identity.json"
    if identity_path.exists():
        if json.loads(identity_path.read_text()) != identity:
            raise RuntimeError("Cached training inputs/config/code differ; use a new output directory")
    elif (output/"training").exists():
        raise RuntimeError("Existing training has no input identity; use a new output directory")
    if (output/"config.json").exists() and _content_hash(json.loads((output/"config.json").read_text())) != identity["config_sha256"]:
        raise RuntimeError("Stored experiment configuration was modified")
    write_json(identity_path, identity)
    return identity


def _load_or_train_candidate(data, market, samples, config, architecture, risk, turnover, seed, directory, identity):
    signature = _candidate_signature(identity, architecture, risk, turnover, seed)
    metadata_path = directory/"run.json"
    checkpoint = directory/"checkpoint.pt"
    if metadata_path.exists():
        run = json.loads(metadata_path.read_text())
        if run.get("run_signature_sha256") != signature:
            raise RuntimeError(f"Cached candidate does not match inputs/config: {directory}")
        if not checkpoint.exists() or not (directory/"history.csv").exists():
            raise RuntimeError(f"Cached candidate is incomplete: {directory}")
        if run.get("checkpoint_sha256") != _sha256(checkpoint):
            raise RuntimeError(f"Cached checkpoint differs from its completed run: {directory}")
        return run
    if checkpoint.exists() or (directory/"history.csv").exists():
        raise RuntimeError(f"Incomplete candidate has no completion metadata; use a new output directory: {directory}")
    return train_candidate(data,market,samples,config,architecture,risk,turnover,seed,directory,
                           run_signature=signature)


def _validate_locked_experiment(data, output, config):
    """Fail before model loading or evaluation if any locked input changed."""
    output = Path(output)
    locked = json.loads((output/"locked_manifest.json").read_text())
    identity = experiment_identity(data, config)
    if locked.get("experiment_identity") != identity:
        raise RuntimeError("Locked experiment inputs/config/code/software differ from current evaluation")
    if json.loads((output/"experiment_identity.json").read_text()) != identity:
        raise RuntimeError("Stored experiment identity was modified")
    if _sha256(output/"config.json") != locked["config_sha256"]:
        raise RuntimeError("Stored experiment configuration was modified after locking")
    if _content_hash(json.loads((output/"config.json").read_text())) != identity["config_sha256"]:
        raise RuntimeError("Evaluation config differs from locked training config")
    if _sha256(output/"selection.json") != locked["selection_sha256"]:
        raise RuntimeError("Selected experiment was changed after locking")
    selection = json.loads((output/"selection.json").read_text())
    runs = [run for family in selection["selected"].values() for run in family["runs"]]
    if set(locked["checkpoints"]) != {run["run_id"] for run in runs}:
        raise RuntimeError("Locked checkpoint set differs from selected runs")
    for run in runs:
        checkpoint = _checkpoint_path(output, run)
        if not checkpoint.exists() or _sha256(checkpoint) != locked["checkpoints"][run["run_id"]]:
            raise RuntimeError(f"Selected checkpoint was modified or is missing: {run['run_id']}")
        signature = _candidate_signature(identity,run["architecture"],run["risk"],run["turnover"],run["seed"])
        if run.get("run_signature_sha256") != signature:
            raise RuntimeError(f"Selected run does not match locked training inputs: {run['run_id']}")
    return selection


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)


def build_dataset(data, config):
    market = load_market(data, config["tickers"])
    raw_features = make_features(market["close"], config["rolling_window"])
    scaler = TrainScaler().fit(raw_features, *config["splits"]["train"])
    features = scaler.transform(raw_features)
    samples = {name:weekly_samples(market["open"],features,*bounds,config["lookback"])
               for name,bounds in config["splits"].items()}
    return market, scaler, samples


def model_for(architecture, config):
    cls = TransformerAllocator if architecture == "transformer" else LSTMAllocator
    return cls(n_features=3*len(config["tickers"]), n_assets=len(config["tickers"]),
               d_model=config["d_model"],n_heads=config["n_heads"],
               n_layers=config["n_layers"],dropout=config["dropout"])


def predict(model, samples, device="cpu"):
    model.eval()
    with torch.no_grad():
        weights = model(torch.as_tensor(samples.x,device=device)).cpu().numpy()
    # Float64 normalization avoids accumulated float32 simplex tolerance errors.
    weights = weights.astype(float); weights /= weights.sum(axis=1,keepdims=True)
    return pd.DataFrame(weights,index=samples.execution_dates,columns=samples.assets)


def evaluate_weights(market, weights, samples, cost):
    prices = market["open"].loc[weights.index[0]:samples.end_dates[-1],samples.assets]
    return backtest(prices,weights,cost)


def train_candidate(data, market, samples, config, architecture, risk, turnover, seed, output, *, run_signature=None):
    """Never accesses test samples or test returns during selection."""
    seed_everything(seed)
    if run_signature is None:
        run_signature = _candidate_signature(experiment_identity(data,config),architecture,risk,turnover,seed)
    device = config["device"]
    model = model_for(architecture,config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(),lr=config["learning_rate"],weight_decay=config["weight_decay"])
    x = torch.as_tensor(samples["train"].x,device=device)
    y = torch.as_tensor(samples["train"].returns,device=device)
    best_score, best_epoch, state = -np.inf, 0, None
    history = []
    start = time.perf_counter()
    for epoch in range(1,config["epochs"]+1):
        model.train(); optimizer.zero_grad(set_to_none=True)
        weights = model(x)
        loss = sequential_objective(weights,y,risk,turnover)
        if not torch.isfinite(loss):
            raise RuntimeError("Nonfinite training objective")
        loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
        optimizer.step()
        if epoch == 1 or epoch % 5 == 0 or epoch == config["epochs"]:
            v_weights = predict(model,samples["validation"],device)
            v_result = evaluate_weights(market,v_weights,samples["validation"],config["selection_cost_bps"])
            rf = load_risk_free(data,v_result.index)
            score = summarize(v_result,rf)["net_sharpe"]
            if not np.isfinite(score):
                raise RuntimeError("Validation Sharpe is undefined")
            history.append({"epoch":epoch,"train_loss":float(loss.detach().cpu()),"validation_net_sharpe":score})
            if score > best_score + 1e-8:
                best_score, best_epoch = score, epoch
                state = {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            if epoch - best_epoch >= config["patience"]:
                break
    model.load_state_dict(state)
    output.mkdir(parents=True,exist_ok=True)
    temporary = output/"checkpoint.pt.tmp"
    torch.save({"model":state,"architecture":architecture,"seed":seed,"risk":risk,"turnover":turnover,
                "config":config,"best_epoch":best_epoch,"run_signature_sha256":run_signature},temporary)
    temporary.replace(output/"checkpoint.pt")
    pd.DataFrame(history).to_csv(output/"history.csv",index=False)
    metadata = {"architecture":architecture,"risk":risk,"turnover":turnover,"seed":seed,
                "validation_net_sharpe":best_score,"best_epoch":best_epoch,
                "epochs_run":epoch,"seconds":time.perf_counter()-start,"checkpoint":"checkpoint.pt",
                "run_signature_sha256":run_signature,"checkpoint_sha256":_sha256(output/"checkpoint.pt")}
    write_json(output/"run.json",metadata)
    return metadata


def train_experiment(data, output, config):
    output = Path(output); output.mkdir(parents=True,exist_ok=True)
    identity = _prepare_training_output(data,output,config)
    torch.set_num_threads(config.get("torch_threads",4))
    market, scaler, samples = build_dataset(data,config)
    write_json(output/"config.json",config)
    write_json(output/"scaler.json",scaler.state())
    description = {}
    for split,sample in samples.items():
        table = pd.DataFrame({"decision_date":sample.decision_dates,"execution_date":sample.execution_dates,"end_date":sample.end_dates})
        table.to_csv(output/f"{split}_calendar.csv",index=False)
        description[split] = {"weeks":len(sample.x),"first_decision":str(sample.decision_dates[0].date()),
                              "first_execution":str(sample.execution_dates[0].date()),
                              "last_valuation":str(sample.end_dates[-1].date())}
    write_json(output/"split_manifest.json",description)
    # Calibration is fixed to the first configured seed, without test selection.
    seed = config["seeds"][0]
    grids = {
        "transformer_return":("transformer",[0.],[0.]),
        "transformer_risk":("transformer",config["risk_grid"],[0.]),
        "transformer_turnover":("transformer",[0.],config["turnover_grid"]),
        "transformer_full":("transformer",config["risk_grid"],config["turnover_grid"]),
        "lstm_full":("lstm",config["risk_grid"],config["turnover_grid"]),
    }
    candidates, selected = [], {}
    for family,(architecture,risks,turnovers) in grids.items():
        family_runs = []
        for risk,turnover in itertools.product(risks,turnovers):
            run_id = f"{family}_s{seed}_r{risk:g}_t{turnover:g}"
            directory = output/"training"/run_id
            print(f"TRAIN/RESUME {run_id}",flush=True)
            run = _load_or_train_candidate(data,market,samples,config,architecture,risk,turnover,seed,directory,identity)
            run.update({"family":family,"run_id":run_id,"checkpoint":str((directory/"checkpoint.pt").relative_to(output))})
            candidates.append(run); family_runs.append(run)
            print(f"  val Sharpe={run['validation_net_sharpe']:.4f} epoch={run['best_epoch']} time={run['seconds']:.1f}s",flush=True)
        best = max(family_runs,key=lambda run:run["validation_net_sharpe"])
        selected[family] = {"risk":best["risk"],"turnover":best["turnover"],"runs":[best]}
        for other_seed in config["seeds"][1:]:
            run_id = f"{family}_s{other_seed}_r{best['risk']:g}_t{best['turnover']:g}"
            directory = output/"training"/run_id
            print(f"TRAIN/RESUME {run_id}",flush=True)
            run = _load_or_train_candidate(data,market,samples,config,architecture,best["risk"],best["turnover"],other_seed,directory,identity)
            run.update({"family":family,"run_id":run_id,"checkpoint":str((directory/"checkpoint.pt").relative_to(output))})
            selected[family]["runs"].append(run)
        write_json(output/"selection_in_progress.json",selected)
    pd.DataFrame(candidates).to_csv(output/"validation_search.csv",index=False)
    selection = {"criterion":f"maximum validation net excess Sharpe at {config['selection_cost_bps']} bps; first-seed penalty calibration, per-seed validation epoch selection",
                 "test_used_for_selection":False,"selected":selected}
    write_json(output/"selection.json",selection)
    # A digest makes the selected experiment state identifiable before testing.
    if experiment_identity(data,config) != identity:
        raise RuntimeError("Experiment inputs/code changed during training; refusing to lock mixed runs")
    manifest = {"experiment_identity":identity,
                "selection_sha256":hashlib.sha256((output/"selection.json").read_bytes()).hexdigest(),
                "config_sha256":hashlib.sha256((output/"config.json").read_bytes()).hexdigest(),
                "market_sha256":hashlib.sha256((Path(data)/"market.csv").read_bytes()).hexdigest(),
                "risk_free_sha256":hashlib.sha256((Path(data)/"risk_free.csv").read_bytes()).hexdigest(),
                "checkpoints":{r["run_id"]:hashlib.sha256(_checkpoint_path(output,r).read_bytes()).hexdigest()
                               for family in selected.values() for r in family["runs"]}}
    write_json(output/"locked_manifest.json",manifest)
    print("TRAINING COMPLETE; selection locked before test evaluation",flush=True)
    return selection


def evaluate_experiment(data,output,config,include_foundation=False):
    output = Path(output)
    selection = _validate_locked_experiment(data,output,config)
    market,scaler,samples = build_dataset(data,config)
    all_results, summary, yearly = {}, [], []
    for split in ["validation","test"]:
        sample = samples[split]
        targets,diagnostics = baseline_targets(market["close"],sample,config["baseline_window"],
                  config["covariance_shrinkage"],config["mean_variance_risk_aversion"])
        write_json(output/f"baseline_diagnostics_{split}.json",diagnostics)
        for family,selected in selection["selected"].items():
            seed_weights = []
            for run in selected["runs"]:
                checkpoint = torch.load(_checkpoint_path(output,run),map_location="cpu",weights_only=True)
                if checkpoint.get("run_signature_sha256") != run["run_signature_sha256"]:
                    raise RuntimeError("Checkpoint payload does not match selected candidate signature")
                model = model_for(checkpoint["architecture"],config)
                model.load_state_dict(checkpoint["model"])
                weights = predict(model,sample)
                targets[f"{family}_s{run['seed']}"] = weights; seed_weights.append(weights)
            targets[f"{family}_ensemble"] = sum(seed_weights)/len(seed_weights)
        if include_foundation:
            from .pretrained import forecast_weights
            targets["chronos2_synth"], _ = forecast_weights(market["close"],sample.decision_dates,
                    cache_dir=Path("../foundation-cache"),output_dir=output/"foundation_cache"/split)
            targets["chronos2_synth"].index = sample.execution_dates
        target_dir=output/"targets"/split; target_dir.mkdir(parents=True,exist_ok=True)
        for name,weights in targets.items():
            weights.to_csv(target_dir/f"{name}.csv",index_label="execution_date")
            for cost in config["cost_bps"]:
                result = evaluate_weights(market,weights,sample,cost)
                rf = load_risk_free(data,result.index)
                metrics = summarize(result,rf)
                summary.append({"split":split,"strategy":name,"cost_bps":cost,**metrics})
                result["risk_free_return"] = rf
                result_dir = output/"daily"/split; result_dir.mkdir(parents=True,exist_ok=True)
                result.to_csv(result_dir/f"{name}_{cost}bps.csv")
                if split == "test":
                    all_results[(name,cost)] = result
                    for year,frame in result.groupby(result.index.year):
                        yearly.append({"year":year,"strategy":name,"cost_bps":cost,**summarize(frame,rf.loc[frame.index])})
    pd.DataFrame(summary).to_csv(output/"metrics.csv",index=False)
    pd.DataFrame(yearly).to_csv(output/"yearly_metrics.csv",index=False)
    comparisons=[]
    names = [f"transformer_full_s{s}" for s in config["seeds"]]+["transformer_full_ensemble"]
    for name in names:
        control = name.replace("full","return")
        a,b = all_results[(name,10)],all_results[(control,10)]
        estimate = paired_sharpe_bootstrap(a.net_return,b.net_return,a.risk_free_return,
                    n_boot=config["bootstrap_repetitions"],block_length=config["bootstrap_block_length"],seed=2026)
        comparisons.append({"strategy":name,"control":control,"cost_bps":10,**estimate})
    # Primary comparison is predeclared full-ensemble versus return-ensemble.
    write_json(output/"bootstrap.json",{"primary":"transformer_full_ensemble vs transformer_return_ensemble at 10bps",
              "secondary":"individual-seed intervals are exploratory and not independent market replications",
              "comparisons":comparisons})
    print("EVALUATION COMPLETE",flush=True)
    return pd.DataFrame(summary)
