"""Small randomly initialized allocators; no pretrained market exposure."""
import math
import torch
from torch import nn


class SoftmaxAllocator(nn.Module):
    """Simplex mapping. Independent implementation of a standard softmax layer."""
    def forward(self, logits):
        return torch.softmax(logits, dim=-1)


class TransformerAllocator(nn.Module):
    def __init__(self, n_features=18, n_assets=6, d_model=32, n_heads=4,
                 n_layers=2, dropout=0.1, max_length=512):
        super().__init__()
        self.project = nn.Linear(n_features, d_model)
        position = torch.arange(max_length).unsqueeze(1)
        scale = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        encoding = torch.zeros(max_length, d_model)
        encoding[:, 0::2] = torch.sin(position * scale)
        encoding[:, 1::2] = torch.cos(position * scale)
        self.register_buffer("position", encoding.unsqueeze(0))
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads,
                dim_feedforward=2*d_model, dropout=dropout, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers, enable_nested_tensor=False)
        self.head = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, n_assets), SoftmaxAllocator())

    def forward(self, x):
        x = self.project(x) + self.position[:, :x.shape[1]]
        return self.head(self.encoder(x)[:, -1])


class LSTMAllocator(nn.Module):
    def __init__(self, n_features=18, n_assets=6, d_model=32, **kwargs):
        super().__init__()
        self.lstm = nn.LSTM(n_features, d_model, num_layers=1, batch_first=True)
        self.head = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, n_assets), SoftmaxAllocator())

    def forward(self, x):
        output, _ = self.lstm(x)
        return self.head(output[:, -1])


def sequential_objective(weights, asset_returns, risk_penalty=0., turnover_penalty=0.):
    """Weekly gross-return mean/variance and drift-aware L1 turnover.

    Whole chronological split is one batch; shuffled independent examples would
    destroy the holdings transition. Training penalty uses prefee targets; final
    evaluation charges exact self-financing fees separately in the backtester.
    """
    gross = (weights * asset_returns).sum(-1)
    previous_drifted = weights[:-1] * (1 + asset_returns[:-1])
    previous_drifted = previous_drifted / previous_drifted.sum(-1, keepdim=True)
    # First allocation from cash requires purchasing one unit of assets.
    turnover = torch.cat([weights[:1].abs().sum(-1), (weights[1:] - previous_drifted).abs().sum(-1)])
    return (-gross.mean() + risk_penalty * gross.var(unbiased=False)
            + turnover_penalty * turnover.mean())
