# 最终 Proposal 数据包：2006–2025

下载日期：2026-11-03。资产按三人最终稿确定：SPY、EFA、EEM、IEF、TLT、GLD；另包含 FRED DTB3。本包是历史数据快照，不包含模型训练结果或已计算的交易信号。

## 文件

| 文件 | 内容 |
|---|---|
| `SPY_2006_2025.csv` 等六个单资产文件 | 日期、代码、OHLC、复权开盘/收盘、复权因子、成交量、分红和拆分记录 |
| `ETF_all_2006_2025.csv` | 六个 ETF 的长表，共 30,186 条资产—日期记录 |
| `adjusted_open_six_ETFs_2006_2025.csv` | 六资产复权开盘价宽表，5,031 行 |
| `adjusted_close_six_ETFs_2006_2025.csv` | 六资产复权收盘价宽表，5,031 行 |
| `DTB3_2006_2025.csv` | FRED 官方 CSV 原样保存；利率仍是贴现报价百分数 |
| `SPY_warmup_2005.csv` 等六个预热文件 | 额外的 2005 年行情，仅供计算 2006 年初的 20 日特征和 60 日输入 |
| `metadata.json` | 下载版本、日期、覆盖、质量检查和文件 SHA256 |

日频数据无需每周重新下载。模型输入使用日频历史，周频调仓由回测系统按最终 proposal 的信号和执行时点决定。

## 数据来源

| 数据 | 来源页面 |
|---|---|
| SPY | https://finance.yahoo.com/quote/SPY/history/ |
| EFA | https://finance.yahoo.com/quote/EFA/history/ |
| EEM | https://finance.yahoo.com/quote/EEM/history/ |
| IEF | https://finance.yahoo.com/quote/IEF/history/ |
| TLT | https://finance.yahoo.com/quote/TLT/history/ |
| GLD | https://finance.yahoo.com/quote/GLD/history/ |
| DTB3 | https://fred.stlouisfed.org/series/DTB3 |

ETF 获取工具：[yfinance](https://github.com/ranaroussi/yfinance)，本次版本 1.2.0。工具与数据来源分别引用。下载参数为 daily、auto_adjust=False、back_adjust=False、actions=True、repair=False；请求起点为 2005-01-01，终点 2026-01-01 不包含当天。

FRED 原始 CSV 下载地址：

[DTB3：2006–2025 官方 CSV](https://fred.stlouisfed.org/graph/fredgraph.csv?id=DTB3&cosd=2006-01-01&coed=2025-12-31)

## 复权字段的含义

- `Adjusted Close`：Yahoo 返回的 Adj Close。
- `Adjustment Factor`：Adjusted Close / Close。
- `Adjusted Open`：Open × Adjustment Factor，与 yfinance 的 OHLC 自动调整方式一致；这是计算得到的复权开盘价，不是另一个独立下载的官方报价字段。
- Open、High、Low、Close 是 yfinance 在 auto_adjust=False 下返回的对应字段，不将其称为严格的原始交易所逐笔成交记录。
- 调整后的价格适用于收益研究，不代表真实可下单成交的价格。
- 使用复权收益时不要再重复加上已被复权处理的分红；如采用实际份额与现金记账，需一致使用价格和公司行动数据。

## 已完成检查

- 六个 ETF 的主体区间均为 2006-01-03 至 2025-12-31，每个 5,031 行。
- 六个 ETF 日期集合一致，日期无重复。
- Open、Close、Adjusted Open、Adjusted Close 均无缺失且为正。
- 合并长表的日期与代码组合无重复。
- 没有填补价格、截尾极端收益或删除金融危机时期。
- FRED 文件共 5,217 行，214 个空值，5,003 个有效利率观测，保留官方原始空值，不替换为零。
- 这些检查证明文件结构和基础完整性，不代表每个行情已与第二个供应商逐条核验。

## DTB3 使用注意

DTB3 为三个月国库券二级市场利率，单位是百分数，采用 discount basis。比如 4.07 表示 4.07% 的年化贴现报价，不是日收益率 4.07%，也不是 0.0407 的单日收益。

本包没有将它转换成日无风险收益，也没有与 ETF 日历强制合并。FRED 与股票市场的工作日和缺失日不完全相同。计算 Sharpe 前应明确贴现报价转换、持有期天数及信息可得时点；必要时只沿用过去已公布观测，不用未来值回填。特别是开盘执行时，不能默认同一天收盘后才公布的利率已知。

## 与现有工作区的区别

原 `data/adjusted_close.csv` 和原 README 使用 SPY、QQQ、IWM、TLT、GLD 五资产，以及旧版日频调仓设置。本次没有覆盖它们，也没有修改模型程序。

本包严格对应最终 proposal 的六资产；将其接入代码时还需要同步更新资产数、周频调仓、开盘执行、DTB3 和 0/10/25 bps 成本情景，不能把新文件直接套入旧设置后称为最终方案。

## 训练边界

暂定训练 2006–2017，验证 2018–2020，测试 2021–2025。标准化仅在训练区间拟合。2005 年预热数据帮助计算早期特征，不自动变成额外训练标签。测试集可以存储在本包中，但不得用于调参或选择模型。
