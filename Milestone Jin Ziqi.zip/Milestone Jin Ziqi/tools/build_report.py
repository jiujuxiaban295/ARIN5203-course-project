"""Build a three-page report from the editable Markdown source (reportlab)."""
from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT=Path(__file__).resolve().parents[1]
styles=getSampleStyleSheet()
styles.add(ParagraphStyle('BodyReport',fontName='Times-Roman',fontSize=10.2,leading=13.0,spaceAfter=7))
styles.add(ParagraphStyle('ReportTitle',fontName='Times-Bold',fontSize=19,leading=22,spaceAfter=5))
styles.add(ParagraphStyle('SubtitleReport',fontName='Times-Roman',fontSize=12,leading=15,spaceAfter=10))
styles.add(ParagraphStyle('SectionReport',fontName='Times-Bold',fontSize=11.5,leading=14,spaceBefore=9,spaceAfter=5,keepWithNext=True))
styles.add(ParagraphStyle('TableReport',fontName='Times-Roman',fontSize=8.5,leading=10.6))
styles.add(ParagraphStyle('CaptionReport',fontName='Times-Roman',fontSize=8.5,leading=10.6,spaceAfter=8))
styles.add(ParagraphStyle('ReferenceReport',fontName='Times-Roman',fontSize=8.5,leading=10.5,spaceAfter=4))

def inline(text):
    return escape(text).replace('−','-').replace('λr','lambda_r').replace('λt','lambda_t').replace('√252','sqrt(252)')

def footer(canvas,doc):
    canvas.setFont('Times-Roman',8)
    canvas.setFillColor(colors.HexColor('#555555'))
    canvas.drawString(43,27,'ARIN5203 | Jin Ziqi | Milestone report')
    canvas.drawRightString(A4[0]-43,27,str(doc.page))

def main():
    lines=(ROOT/'docs/Milestone_Report.md').read_text().splitlines()
    story=[];i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line=='<!-- PAGE BREAK -->':story.append(PageBreak());i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-:]+',c) for c in cells):
                    rows.append([Paragraph(inline(c),styles['TableReport']) for c in cells])
                i+=1
            widths=[106,76,79,76,78,94] if len(rows[0])==6 else [103,406]
            t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eaf0f5')),
                ('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#64748b')),
                ('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#94a3b8')),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),
                ('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),5),
                ('RIGHTPADDING',(0,0),(-1,-1),5)]))
            story.extend([t,Spacer(1,8)]);continue
        if line.startswith('!['):
            path=re.search(r'\]\((.+)\)',line).group(1)
            from PIL import Image as PILImage
            p=(ROOT/'docs'/path).resolve()
            with PILImage.open(p) as im:w,h=im.size
            story.append(Image(str(p),width=509,height=509*h/w));story.append(Spacer(1,5))
            i+=1;continue
        if line.startswith('### '):style='SectionReport';line=line[4:]
        elif line.startswith('## '):style='SubtitleReport';line=line[3:]
        elif line.startswith('# '):style='ReportTitle';line=line[2:]
        elif re.match(r'^\[\d+\]',line):style='ReferenceReport'
        elif line.startswith('Figure 1.'):style='CaptionReport'
        else:style='BodyReport'
        story.append(Paragraph(inline(line),styles[style]));i+=1
    doc=SimpleDocTemplate(str(ROOT/'docs/Milestone_Report.pdf'),pagesize=A4,
        rightMargin=43,leftMargin=43,topMargin=36,bottomMargin=40,
        title='ARIN5203 Milestone Report on Risk and Turnover Aware Portfolio Optimization',author='Jin Ziqi')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)

if __name__=='__main__':main()
