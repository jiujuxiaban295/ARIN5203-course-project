import unittest
import numpy as np
import pandas as pd
from baseline import backtest


class BacktestTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(42)
        self.p = pd.DataFrame(100*np.cumprod(1+rng.normal(0, .01, (110, 5)), axis=0),
                              index=pd.bdate_range('2017-09-01', periods=110),
                              columns=list('ABCDE'))

    def test_future_prices_do_not_change_prior_targets(self):
        a = backtest(self.p, 'Minimum Variance')
        changed = self.p.copy()
        changed.loc[a.index[3]:] *= np.array([2, 3, 4, 5, 6])
        b = backtest(changed, 'Minimum Variance')
        # Even the next day's target cannot use the changed price: execution lag.
        np.testing.assert_allclose(a.filter(like='weight_').iloc[:5],
                                   b.filter(like='weight_').iloc[:5])

    def test_drift_and_cost(self):
        a = backtest(self.p, 'Equal Weight', cost_bps=10)
        self.assertEqual(a.turnover.iloc[0], 0)
        r = self.p.pct_change().loc[a.index[0]].to_numpy()
        drift = .2*(1+r)/(1+np.mean(r))
        self.assertAlmostEqual(a.turnover.iloc[1], np.abs(.2-drift).sum())
        np.testing.assert_allclose(a.net_return, a.gross_return-.001*a.turnover)

    def test_constraints_and_execution(self):
        a = backtest(self.p, 'Minimum Variance')
        w = a.filter(like='weight_')
        np.testing.assert_allclose(w.sum(axis=1), 1)
        self.assertTrue((w >= 0).all().all())
        self.assertTrue((a.signal_date < a.execution_date).all())
        self.assertTrue((a.execution_date < a.index).all())


if __name__ == '__main__':
    unittest.main()
