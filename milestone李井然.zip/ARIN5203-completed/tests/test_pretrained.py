"""Contract tests for the optional foundation adapter; no weights/network needed."""
import numpy as np
import pandas as pd
import pytest

from portfolio.pretrained import history_windows, returns_to_weights


def test_window_has_no_post_signal_prices():
    dates = pd.bdate_range("2017-01-01", periods=90)
    prices = pd.DataFrame({"A": np.arange(90) + 100., "B": np.arange(90) + 200.}, index=dates)
    signal = dates[70]
    before, _ = history_windows(prices, [signal], 60)
    prices.loc[dates[71]:, :] = 1e9
    after, _ = history_windows(prices, [signal], 60)
    np.testing.assert_array_equal(before, after)
    np.testing.assert_array_equal(before[0, :, -1], [170., 270.])
    assert before.shape == (1, 2, 60)


def test_invalid_or_unobserved_history_is_rejected():
    dates = pd.bdate_range("2017-01-01", periods=90)
    prices = pd.DataFrame({"A": np.ones(90)}, index=dates)
    with pytest.raises(ValueError, match="complete, observed"):
        history_windows(prices, [dates[1]])
    with pytest.raises(ValueError, match="complete, observed"):
        history_windows(prices, [pd.Timestamp("2018-01-01")])
    prices.iloc[60, 0] = np.nan
    with pytest.raises(ValueError, match="finite and positive"):
        history_windows(prices, [dates[70]])


def test_fixed_mapping_is_longonly_and_price_unit_invariant():
    current = np.array([[100., 200., 20.]])
    forecast = current * np.array([[1.01, 0.99, 1.02]])
    weights = returns_to_weights(forecast, current)
    assert (weights > 0).all()
    np.testing.assert_allclose(weights.sum(axis=1), 1.)
    assert weights[0, 2] > weights[0, 0] > weights[0, 1]
    np.testing.assert_allclose(weights, returns_to_weights(forecast * 10, current * 10))
    np.testing.assert_allclose(returns_to_weights(current, current), np.full((1, 3), 1/3))


def test_invalid_temperature_cannot_silently_produce_weights():
    with pytest.raises(ValueError, match="temperature"):
        returns_to_weights(np.ones((1, 2)), np.ones((1, 2)), temperature=0)
