import unittest
import numpy as np
import pandas as pd
import torch
from baseline import backtest
from transformer_baseline import PortfolioTransformer, samples


class TransformerTests(unittest.TestCase):
    def test_features_and_scaler_do_not_see_validation_future(self):
        rng = np.random.default_rng(5)
        p = pd.DataFrame(100*np.cumprod(1+rng.normal(0, .01, (900, 5)), axis=0),
                         index=pd.bdate_range('2015-01-01', periods=900), columns=list('ABCDE'))
        x, y, dates, mean, std = samples(p)
        cutoff = pd.Timestamp('2018-02-01')
        changed = p.copy()
        changed.loc[cutoff:] *= np.array([2, 3, 4, 5, 6])
        xx, _, dd, mm, ss = samples(changed)
        np.testing.assert_allclose(mean, mm)
        np.testing.assert_allclose(std, ss)
        # Input for cutoff and next trading day must exclude cutoff price.
        eligible = dates <= p.index[p.index.get_loc(cutoff)+1]
        np.testing.assert_allclose(x[eligible], xx[eligible])
        np.testing.assert_allclose(y, p.pct_change().loc[dates].to_numpy(), rtol=1e-6)

    def test_output_constraints_and_gradient(self):
        model = PortfolioTransformer()
        w = model(torch.randn(4, 60, 15))
        self.assertEqual(tuple(w.shape), (4, 5))
        torch.testing.assert_close(w.sum(-1), torch.ones(4))
        self.assertTrue((w >= 0).all())
        loss = -(w*torch.randn(4, 5)).sum(-1).mean()
        loss.backward()
        self.assertTrue(torch.isfinite(model.projection.weight.grad).all())
        self.assertGreater(model.projection.weight.grad.abs().sum().item(), 0)

    def test_supplied_weights_use_same_backtester(self):
        rng = np.random.default_rng(6)
        p = pd.DataFrame(100*np.cumprod(1+rng.normal(0, .01, (120, 5)), axis=0),
                         index=pd.bdate_range('2017-09-01', periods=120), columns=list('ABCDE'))
        expected = backtest(p, 'Equal Weight')
        weights = pd.DataFrame(.2, index=expected.index, columns=p.columns)
        actual = backtest(p, 'Supplied', supplied_weights=weights)
        pd.testing.assert_frame_equal(expected, actual)


if __name__ == '__main__':
    unittest.main()
