#!/usr/bin/env python3
"""Run training and/or evaluation; CPU default works on the project Mac."""
import argparse
import json
import sys
from pathlib import Path
import pandas as pd
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from portfolio.experiment import train_experiment,evaluate_experiment

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--data",default="data/final_zip")
    parser.add_argument("--output",default="results/full")
    parser.add_argument("--config",default="configs/full.json")
    parser.add_argument("--stage",choices=["train","evaluate","all"],default="all")
    parser.add_argument("--foundation",action="store_true")
    args=parser.parse_args()
    config=json.loads(Path(args.config).read_text())
    previous_end=None
    for split in ["train","validation","test"]:
        start,end=map(pd.Timestamp,config["splits"][split])
        if start>=end or (previous_end is not None and start<=previous_end):
            raise ValueError("Splits must be increasing, disjoint train/validation/test intervals")
        previous_end=end
    if config["selection_cost_bps"]!=10 or 10 not in config["cost_bps"]:
        raise ValueError("This protocol fixes selection and primary inference at 10 bps")
    torch.set_num_threads(config.get("torch_threads",4))
    if args.stage in ["train","all"]:
        train_experiment(args.data,args.output,config)
    if args.stage in ["evaluate","all"]:
        evaluate_experiment(args.data,args.output,config,args.foundation)

if __name__=="__main__":
    main()
