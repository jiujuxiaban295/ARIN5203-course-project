"""Rolling long-only baselines sharing the neural models' information cutoff."""
import numpy as np
import pandas as pd
from scipy.optimize import minimize


def baseline_targets(close, samples, window=252, shrinkage=0.1, risk_aversion=5.):
    assets = samples.assets
    close = close[assets]
    returns = close.pct_change(fill_method=None)
    outputs = {name: [] for name in ["equal_weight", "minimum_variance", "mean_variance"]}
    n = len(assets)
    equal = np.full(n, 1/n)
    diagnostics = []
    for decision in samples.decision_dates:
        hist = returns.loc[:decision].tail(window).dropna()
        if len(hist) < 60:
            raise ValueError("Not enough past returns for baseline")
        cov = hist.cov().to_numpy() * 252
        cov = (1-shrinkage)*cov + shrinkage*np.diag(np.diag(cov)) + np.eye(n)*1e-8
        mu = hist.mean().to_numpy() * 252
        outputs["equal_weight"].append(equal.copy())
        for name in ["minimum_variance", "mean_variance"]:
            if name == "minimum_variance":
                objective = lambda w: w @ cov @ w
                jacobian = lambda w: 2*cov @ w
            else:
                objective = lambda w: risk_aversion/2*(w@cov@w)-mu@w
                jacobian = lambda w: risk_aversion*cov@w-mu
            fit = minimize(objective, equal, jac=jacobian, method="SLSQP",
                           bounds=[(0,1)]*n, constraints={"type":"eq", "fun":lambda w:w.sum()-1,
                           "jac":lambda w:np.ones(n)}, options={"maxiter":200,"ftol":1e-10})
            if not fit.success:
                raise RuntimeError(f"{name} optimizer failed at {decision}: {fit.message}")
            weights = np.maximum(fit.x, 0); weights /= weights.sum()
            outputs[name].append(weights)
            diagnostics.append({"strategy":name,"decision_date":str(decision.date()),
                                "observations":len(hist),"objective":float(fit.fun)})
    return {name:pd.DataFrame(w,index=samples.execution_dates,columns=assets)
            for name,w in outputs.items()}, diagnostics
