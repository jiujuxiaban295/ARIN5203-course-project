#!/usr/bin/env python3
"""Validate and import ONLY the team's versioned final dataset archive, offline."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np
import pandas as pd

from portfolio.data import TICKERS, load_market, load_risk_free, validate_market_long

FINAL_ARCHIVE = "5203最终版数据.zip"
FINAL_SHA256 = "97bf4b43d1825dbe2b0a976c5ab9da6fb59d46a674e4149e5fe889893d512fe7"
PREFIX = "proposal_final_2006_2025/"


def digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def validate_adjustments(frame: pd.DataFrame, ticker: str) -> None:
    required = {"Date", "Ticker", "Open", "Close", "Adjusted Open", "Adjusted Close", "Adjustment Factor"}
    if not required.issubset(frame):
        raise ValueError(f"{ticker}: missing required raw/adjusted columns")
    if set(frame["Ticker"]) != {ticker}:
        raise ValueError(f"{ticker}: incorrect ticker column")
    numeric = frame[["Open", "Close", "Adjusted Open", "Adjusted Close", "Adjustment Factor"]].to_numpy(float)
    if not np.isfinite(numeric).all() or (numeric <= 0).any():
        raise ValueError(f"{ticker}: invalid required raw/adjusted prices")
    for actual, expected, description in [
        (frame["Adjustment Factor"], frame["Adjusted Close"] / frame["Close"], "adjustment factor"),
        (frame["Adjusted Open"], frame["Open"] * frame["Adjustment Factor"], "adjusted open"),
    ]:
        if not np.allclose(actual, expected, rtol=2e-12, atol=2e-12):
            raise ValueError(f"{ticker}: inconsistent {description}")


def import_dataset(archive: Path, output: Path, expected_sha256: str = FINAL_SHA256) -> dict:
    archive, output = Path(archive), Path(output)
    archive_bytes = archive.read_bytes()
    actual_sha = digest(archive_bytes)
    if actual_sha != expected_sha256:
        raise ValueError(f"Archive SHA256 mismatch: {actual_sha}")
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as bundle:
        names = bundle.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive member names")
        for member in bundle.infolist():
            path = PurePosixPath(member.filename)
            if path.is_absolute() or ".." in path.parts or "\\" in member.filename:
                raise ValueError("Unsafe archive member path")
            if not member.filename.startswith(PREFIX) or member.file_size > 20_000_000:
                raise ValueError("Unexpected or excessively large archive member")
        contents = {name.removeprefix(PREFIX): bundle.read(name) for name in names if not name.endswith("/")}
    metadata = json.loads(contents["metadata.json"])
    for name, expected in metadata["sha256"].items():
        if name not in contents or digest(contents[name]) != expected:
            raise ValueError(f"Archive internal SHA256 mismatch: {name}")
    if list(metadata["assets"]) != list(TICKERS):
        raise ValueError("Archive asset universe differs from the final proposal")

    def csv(name: str) -> pd.DataFrame:
        return pd.read_csv(io.BytesIO(contents[name]), parse_dates=["Date"])

    main_frames, warmup_frames = [], []
    for ticker in TICKERS:
        main = csv(f"{ticker}_2006_2025.csv")
        warmup = csv(f"{ticker}_warmup_2005.csv")
        for frame, start, end, label in [
            (main, "2006-01-03", "2025-12-31", "main"),
            (warmup, "2005-01-03", "2005-12-30", "warmup"),
        ]:
            validate_adjustments(frame, ticker)
            if str(frame["Date"].min().date()) != start or str(frame["Date"].max().date()) != end:
                raise ValueError(f"{ticker}: incorrect {label} coverage")
            if frame["Date"].duplicated().any() or not frame["Date"].is_monotonic_increasing:
                raise ValueError(f"{ticker}: duplicate/unsorted {label} dates")
        if len(main) != 5031 or len(warmup) != 252:
            raise ValueError(f"{ticker}: incorrect session count")
        main_frames.append(main)
        warmup_frames.append(warmup)

    main_all = pd.concat(main_frames).sort_values(["Date", "Ticker"]).reset_index(drop=True)
    archived_all = csv("ETF_all_2006_2025.csv").sort_values(["Date", "Ticker"]).reset_index(drop=True)
    try:
        pd.testing.assert_frame_equal(main_all, archived_all, check_exact=True)
    except AssertionError as exc:
        raise ValueError("Merged ETF file disagrees with single-ticker source files") from exc
    for field, filename in [("Adjusted Open", "adjusted_open_six_ETFs_2006_2025.csv"),
                            ("Adjusted Close", "adjusted_close_six_ETFs_2006_2025.csv")]:
        derived = main_all.pivot(index="Date", columns="Ticker", values=field).reindex(columns=list(TICKERS))
        archived = csv(filename).set_index("Date").reindex(columns=list(TICKERS))
        if not derived.index.equals(archived.index) or not np.array_equal(derived.to_numpy(), archived.to_numpy()):
            raise ValueError(f"{filename} disagrees with single-ticker source files")

    all_prices = pd.concat(warmup_frames + main_frames).rename(
        columns={"Date": "date", "Ticker": "ticker", "Adjusted Open": "open", "Adjusted Close": "close"}
    )[["date", "ticker", "open", "close"]].sort_values(["date", "ticker"])
    quality = validate_market_long(all_prices)
    rates = pd.read_csv(io.BytesIO(contents["DTB3_2006_2025.csv"]))
    if list(rates.columns) != ["observation_date", "DTB3"]:
        raise ValueError("Unexpected DTB3 archive schema")
    rates = rates.rename(columns={"observation_date": "date"})
    rates["date"] = pd.to_datetime(rates["date"], errors="raise")
    rates["DTB3"] = pd.to_numeric(rates["DTB3"], errors="raise")
    if len(rates) != 5217 or rates["DTB3"].isna().sum() != 214 or rates["date"].duplicated().any():
        raise ValueError("DTB3 count/missingness differs from the versioned archive contract")

    # Write only validated known file bytes. No ZipFile.extract/extractall is used.
    output.mkdir(parents=True, exist_ok=True)
    raw = output / "raw"
    raw.mkdir(exist_ok=True)
    for name, content in contents.items():
        if len(PurePosixPath(name).parts) != 1:
            raise ValueError("Unexpected nested member in the declared source directory")
        (raw / name).write_bytes(content)
    all_prices.to_csv(output / "market.csv", index=False, float_format="%.17g")
    rates.to_csv(output / "risk_free.csv", index=False, float_format="%.17g")
    market = load_market(output)
    first_available = rates.loc[rates["DTB3"].notna(), "date"].min() + pd.offsets.BDay(2)
    eligible = market.index[market.index >= first_available]
    rf = load_risk_free(output, eligible)
    quality["main_sessions_per_asset"] = 5031
    quality["warmup_sessions_per_asset"] = 252
    quality["adjusted_open_matches_raw_formula"] = True
    quality["wide_prices_match_single_ticker_files_exactly"] = True
    quality["merged_prices_match_single_ticker_files_exactly"] = True
    quality["risk_free"] = {**rf.attrs, "observation_rows": len(rates),
                            "missing_quote_rows": int(rates["DTB3"].isna().sum()),
                            "first_usable_date_after_lag": str(first_available.date()),
                            "initial_undefined_policy": "No RF backfill; train objective does not use RF. Evaluation before first_usable_date is forbidden."}
    try:
        revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=archive.resolve().parent, text=True).strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        revision = None
    provenance = {
        "imported_at_utc": datetime.now(timezone.utc).isoformat(),
        "data_source": "Only the repository final dataset archive; no network acquisition or external substitution",
        "archive_filename": archive.name,
        "archive_sha256": actual_sha,
        "repository_revision": revision,
        "source_members": {PREFIX + name: digest(content) for name, content in contents.items()},
        "upstream_metadata": metadata,
        "normalization": {"market": "Adjusted Open and Adjusted Close from archive single-asset CSVs, 2005 warmup plus 2006–2025 main. No filling, deletion, rescaling or external data.",
                          "risk_free": "Original archive DTB3 percent observations and missing values retained. Evaluation loader applies two-business-day lag, backward-asof, 91-day discount-to-effective-yield conversion, then 252-trading-day equivalent."},
        "limitations": ["Adjusted open is a total-return research proxy and is not a literal executable cash-market quote.",
                        "Fixed surviving six-ETF universe has selection/survivorship limitations.",
                        "DTB3 is a retrieved current-vintage history rather than publication-time vintages; availability lag is conservative, not reconstructed release timestamps."],
        "normalized_files": {name: digest((output / name).read_bytes()) for name in ["market.csv", "risk_free.csv"]},
    }
    (output / "provenance.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output / "quality.json").write_text(json.dumps(quality, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return quality


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=Path(FINAL_ARCHIVE))
    parser.add_argument("--output", type=Path, default=Path("data/final_zip"))
    args = parser.parse_args()
    print(json.dumps(import_dataset(args.archive, args.output), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
