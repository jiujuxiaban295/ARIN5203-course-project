#!/usr/bin/env python3
"""Export failure-period and ablation evidence tables; no report prose."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def run(root):
    root=Path(root)
    metrics=pd.read_csv(root/"metrics.csv")
    metrics=metrics[(metrics.split=="test") & (metrics.cost_bps==10)].set_index("strategy")
    keys=["annualized_net_return","annualized_volatility","net_sharpe","max_drawdown","annualized_turnover"]
    deltas=[]
    for suffix in ["s11","s29","s47","ensemble"]:
        control=metrics.loc[f"transformer_return_{suffix}",keys]
        for family in ["risk","turnover","full"]:
            row=metrics.loc[f"transformer_{family}_{suffix}",keys]
            deltas.append({"variant":family,"replication":suffix,**{key:float(row[key]-control[key]) for key in keys}})
    pd.DataFrame(deltas).to_csv(root/"ablation_differences_vs_return.csv",index=False)
    monthly=[];worst=[];exposures=[]
    for name in metrics.index:
        frame=pd.read_csv(root/"daily"/"test"/f"{name}_10bps.csv",index_col="date",parse_dates=True)
        grouped=frame.net_return.groupby(frame.index.to_period("M"))
        totals=grouped.apply(lambda x:np.prod(1+x)-1)
        for month,value in totals.items():
            monthly.append({"strategy":name,"month":str(month),"net_return":value,
                            "n_sessions":len(grouped.get_group(month))})
        drawdown=frame.wealth/np.maximum.accumulate(np.r_[1,frame.wealth.to_numpy()])[1:]-1
        trough=drawdown.idxmin()
        lossday=frame.net_return.idxmin()
        record={"strategy":name,"worst_month":str(totals.idxmin()),"worst_month_return":float(totals.min()),
                "worst_day":str(lossday.date()),"worst_daily_return":float(frame.loc[lossday,"net_return"]),
                "drawdown_trough":str(trough.date()),"max_drawdown":float(drawdown.min())}
        record.update({column.replace("weight_","worst_day_weight_"):float(frame.loc[lossday,column])
                       for column in frame.columns if column.startswith("weight_")})
        worst.append(record)
        weights=pd.read_csv(root/"targets"/"test"/f"{name}.csv",index_col=0)
        for asset in weights:
            exposures.append({"strategy":name,"asset":asset,"mean_target_weight":weights[asset].mean(),
                "min_target_weight":weights[asset].min(),"max_target_weight":weights[asset].max(),
                "fraction_weeks_above_95pct":float((weights[asset]>.95).mean())})
    pd.DataFrame(monthly).to_csv(root/"monthly_returns.csv",index=False)
    pd.DataFrame(worst).to_csv(root/"failure_periods.csv",index=False)
    pd.DataFrame(exposures).to_csv(root/"allocation_diagnostics.csv",index=False)
    print("Exported ablation, monthly, worst-period and concentration tables")

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--results",default="results/full")
    run(p.parse_args().results)
