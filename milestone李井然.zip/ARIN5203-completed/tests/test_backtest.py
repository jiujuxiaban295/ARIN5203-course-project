import numpy as np
import pandas as pd
import pytest

from portfolio.backtest import backtest, cost_factor


def prices(values):
    return pd.DataFrame(values, index=pd.date_range("2020-01-06", periods=len(values), freq="B"), columns=["A", "B"])


def test_buy_and_hold_drifts_without_daily_rebalancing():
    p = prices([[1, 1], [2, 1], [2, 2]])
    target = pd.DataFrame([[0.5, 0.5]], index=p.index[:1], columns=p.columns)
    result = backtest(p, target, cost_bps=0)
    np.testing.assert_allclose(result.net_return, [0.5, 1 / 3])
    np.testing.assert_allclose(result.wealth, [1.5, 2])
    np.testing.assert_allclose(result.weight_A, [0.5, 2 / 3])
    np.testing.assert_allclose(result.turnover, [1, 0])
    assert result.index.equals(p.index[1:])


def test_initial_purchase_fee_is_self_financed():
    p = prices([[100, 100], [110, 100]])
    target = pd.DataFrame([[1.0, 0.0]], index=p.index[:1], columns=p.columns)
    result = backtest(p, target, cost_bps=100)
    assert result.wealth.iloc[-1] == pytest.approx(1.1 / 1.01)
    assert result.cost.iloc[0] == pytest.approx(0.01 / 1.01)
    assert result.turnover.iloc[0] == pytest.approx(1 / 1.01)


def test_rebalance_turnover_compares_with_drifted_holdings():
    p = prices([[1, 1], [2, 1], [2, 1]])
    target = pd.DataFrame([[0.5, 0.5], [0.5, 0.5]], index=p.index[:2], columns=p.columns)
    result = backtest(p, target, cost_bps=100)
    assert result.turnover.iloc[1] == pytest.approx(1 / 3)
    assert result.cost.iloc[1] == pytest.approx(0.01 / 3)
    assert result.wealth.iloc[-1] == pytest.approx(1.5 / 1.01 * (1 - 0.01 / 3))


def test_complete_rotation_charges_both_buys_and_sells():
    rate = 0.01
    mu = cost_factor(np.array([0, 1]), np.array([1, 0]), rate)
    assert mu == pytest.approx((1 - rate) / (1 + rate))
    assert mu + rate * (1 + mu) == pytest.approx(1)


def test_flat_prices_have_only_initial_cost_if_no_changes():
    p = prices([[1, 1]] * 5)
    target = pd.DataFrame([[0.5, 0.5]] * 4, index=p.index[:-1], columns=p.columns)
    result = backtest(p, target, cost_bps=25)
    assert result.wealth.iloc[-1] == pytest.approx(1 / 1.0025)
    np.testing.assert_allclose(result.cost.iloc[1:], 0, atol=1e-14)


def test_target_execution_has_return_only_after_that_open():
    p = prices([[1, 1], [10, 1], [20, 1], [30, 1]])
    target = pd.DataFrame([[1.0, 0.0]], index=p.index[1:2], columns=p.columns)
    result = backtest(p, target, cost_bps=0)
    assert result.index[0] == p.index[2]
    assert result.wealth.iloc[-1] == pytest.approx(3)


def test_weekly_training_labels_and_daily_backtest_value_same_holding_intervals():
    from portfolio.features import make_features, weekly_samples

    rng = np.random.default_rng(13)
    dates = pd.bdate_range("2018-01-01", "2020-06-30")
    p = pd.DataFrame(
        np.exp(np.cumsum(rng.normal(0, 0.01, (len(dates), 2)), axis=0)),
        index=dates,
        columns=["A", "B"],
    )
    features = make_features(p)
    samples = weekly_samples(p, features, "2020-01-01", "2020-06-30")
    weights = rng.dirichlet(np.ones(2), size=len(samples.execution_dates))
    targets = pd.DataFrame(weights, index=samples.execution_dates, columns=p.columns)
    result = backtest(p.loc[:samples.end_dates[-1]], targets, cost_bps=0)
    weekly_wealth = np.prod(1 + np.sum(weights * samples.returns, axis=1))
    assert result.wealth.iloc[-1] == pytest.approx(weekly_wealth, rel=1e-6)


@pytest.mark.parametrize("bad", ["negative", "sum", "missing_date", "last_date", "price_nan", "asset_order"])
def test_invalid_market_or_allocations_fail_closed(bad):
    p = prices([[1, 1], [2, 1], [3, 1]])
    target = pd.DataFrame([[0.5, 0.5]], index=p.index[:1], columns=p.columns)
    if bad == "negative":
        target.iloc[0] = [-0.1, 1.1]
    elif bad == "sum":
        target.iloc[0] = [0.1, 0.1]
    elif bad == "missing_date":
        target.index = target.index - pd.Timedelta(days=100)
    elif bad == "last_date":
        target.index = p.index[-1:]
    elif bad == "price_nan":
        p.iloc[1, 0] = np.nan
    elif bad == "asset_order":
        target = target[["B", "A"]]
    with pytest.raises(ValueError):
        backtest(p, target)
