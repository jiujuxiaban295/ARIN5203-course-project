"""Download frozen six-ETF and FRED inputs for the final proposal."""
import hashlib
import json
from pathlib import Path
import pandas as pd
import yfinance as yf

OUT = Path(__file__).resolve().parent/'data/final_proposal'
ASSETS = ['SPY','EFA','EEM','IEF','TLT','GLD']

def main():
    OUT.mkdir(exist_ok=True, parents=True)
    yf.set_tz_cache_location('/private/tmp/arin5203-yfinance-cache')
    raw = yf.download(ASSETS, start='2005-01-01', end='2026-01-01',
                      interval='1d', auto_adjust=False, actions=True, threads=False)
    raw.to_csv(OUT/'yahoo_raw.csv')
    close = raw['Adj Close'].reindex(columns=ASSETS)
    opening = raw['Open'].reindex(columns=ASSETS) * close / raw['Close'].reindex(columns=ASSETS)
    keep = close.notna().all(axis=1) & opening.notna().all(axis=1)
    close.loc[keep].to_csv(OUT/'adjusted_close.csv')
    opening.loc[keep].to_csv(OUT/'adjusted_open.csv')
    url = 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DTB3&cosd=2005-01-01&coed=2025-12-31'
    rf = pd.read_csv(url)
    rf.to_csv(OUT/'fred_dtb3.csv',index=False)
    meta = dict(assets=ASSETS, downloaded_utc=pd.Timestamp.now(tz='UTC').isoformat(),
                yfinance_version=yf.__version__, fred_url=url,
                price_rows=int(keep.sum()), dropped_rows=int((~keep).sum()),
                first=str(close.loc[keep].index[0]), last=str(close.loc[keep].index[-1]),
                adjusted_open='Open * Adj Close / Close; vendor adjustment factor',
                warmup_year=2005, study_years='2006–2025',
                missing_close=close.isna().sum().to_dict(),
                missing_open=opening.isna().sum().to_dict())
    meta['sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.glob('*.csv')}
    meta['proposal_sha256']=hashlib.sha256((OUT/'ARIN5203_Proposal.pdf').read_bytes()).hexdigest()
    (OUT/'metadata.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
