import unittest
import numpy as np
import pandas as pd
import torch
from baseline import backtest
from transformer_ablation import objective


class SequentialObjectiveTests(unittest.TestCase):
    def test_turnover_matches_backtester_with_context(self):
        rng = np.random.default_rng(33)
        p = pd.DataFrame(100*np.cumprod(1+rng.normal(0,.01,(120,5)),axis=0),
                         index=pd.bdate_range('2017-09-01',periods=120), columns=list('ABCDE'))
        dates = p.loc['2018':].index
        w = rng.dirichlet(np.ones(5),len(dates))
        frame = backtest(p,'external', supplied_weights=pd.DataFrame(w,index=dates,columns=p.columns))
        r = p.pct_change().loc[dates].to_numpy()
        wt, rt = torch.tensor(w), torch.tensor(r)
        _, ret, variance, turn = objective(wt,rt,1,.001)
        self.assertAlmostEqual(turn.item(),frame.turnover.iloc[1:].mean())
        self.assertAlmostEqual(ret.item(),frame.gross_return.iloc[1:].mean())
        self.assertAlmostEqual(variance.item(),frame.gross_return.iloc[1:].var(ddof=0))
        total, n = 0., 0
        for s in range(1,len(w),7):
            e = min(s+7,len(w))
            total += objective(wt[s-1:e],rt[s-1:e],0,1)[3].item()*(e-s)
            n += e-s
        self.assertAlmostEqual(total/n,turn.item())

    def test_penalty_gradients_include_prefix(self):
        logits = torch.randn(12,5,requires_grad=True)
        r = torch.randn(12,5)*.01
        loss, _, _, _ = objective(logits.softmax(-1),r,1,.001)
        loss.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertGreater(logits.grad[0].abs().sum().item(),0)


if __name__ == '__main__':
    unittest.main()
