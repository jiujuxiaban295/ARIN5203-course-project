#!/usr/bin/env python3
"""Independently audit saved experiment artifacts; emit verification.json.

This script does not call the production backtester, metrics functions or
feature builder. Lock verification deliberately uses the experiment's hash
validator; cash/share accounting and metric calculations are separate code.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.optimize import brentq

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from portfolio.experiment import _validate_locked_experiment


class Audit:
    def __init__(self):
        self.checks = []

    def record(self, name, passed, **details):
        self.checks.append({"name":name,"passed":bool(passed),**details})

    def close(self, name, observed, expected, atol=1e-10, rtol=1e-8):
        observed,expected = np.asarray(observed,dtype=float),np.asarray(expected,dtype=float)
        valid = observed.shape == expected.shape
        finite = valid and np.isfinite(observed).all() and np.isfinite(expected).all()
        passed = finite and np.allclose(observed,expected,atol=atol,rtol=rtol)
        max_error = float(np.max(np.abs(observed-expected))) if finite and observed.size else None
        self.record(name,passed,max_absolute_error=max_error)


def independent_metrics(frame):
    """Recompute from saved daily series, including the initial unit wealth."""
    r = frame["net_return"].to_numpy(dtype=float)
    excess = r-frame["risk_free_return"].to_numpy(dtype=float)
    wealth = np.multiply.accumulate(1+r)
    peak = np.maximum.accumulate(np.r_[1.,wealth])
    turnover = frame["turnover"].to_numpy(dtype=float)
    number_trades = np.count_nonzero(turnover>1e-12)
    return {
        "n_days":len(r),
        "total_net_return":wealth[-1]-1,
        "annualized_net_return":wealth[-1]**(252/len(r))-1,
        "annualized_volatility":np.sqrt(252*np.sum((r-r.mean())**2)/(len(r)-1)),
        "net_sharpe":np.sqrt(252)*excess.mean()/np.sqrt(np.sum((excess-excess.mean())**2)/(len(r)-1)),
        "max_drawdown":np.min(wealth/peak[1:]-1),
        "average_daily_turnover":turnover.sum()/len(r),
        "average_rebalance_turnover":turnover.sum()/number_trades if number_trades else 0.,
        "annualized_turnover":turnover.sum()*252/len(r),
        "total_cost_fractions":frame["cost"].sum(),
        "n_trades":number_trades,
    },wealth


def independent_share_accounting(opens, targets, cost_bps):
    """Rebuild NAV from actual share positions and cash, using a root solver.

    Each trade solves for post-fee invested dollars. This uses neither the
    backtest's drifted-weight recursion nor its bisection cost implementation.
    """
    rate = cost_bps/10000
    opens = opens.loc[targets.index[0]:]
    shares = np.zeros(len(opens.columns))
    cash = 1.
    nav,net,gross,turnover,costs = [],[],[],[],[]
    for day,next_day in zip(opens.index[:-1],opens.index[1:]):
        price = opens.loc[day].to_numpy(dtype=float)
        before_dollars = shares*price
        before = before_dollars.sum()+cash
        traded = fee = 0.
        if day in targets.index:
            weights = targets.loc[day].to_numpy(dtype=float)
            if rate:
                after = brentq(lambda value:value+rate*np.abs(value*weights-before_dollars).sum()-before,
                               0.,before,xtol=1e-14,rtol=1e-14)
            else:
                after = before
            after_dollars = after*weights
            traded = np.abs(after_dollars-before_dollars).sum()
            fee = before-after
            shares = after_dollars/price
            cash = 0.
        after = (shares*price).sum()+cash
        ending_nav = (shares*opens.loc[next_day].to_numpy(dtype=float)).sum()+cash
        nav.append(ending_nav)
        net.append(ending_nav/before-1)
        gross.append(ending_nav/after-1)
        turnover.append(traded/before)
        costs.append(fee/before)
    return pd.DataFrame({"wealth":nav,"net_return":net,"gross_return":gross,
                         "turnover":turnover,"cost":costs},index=opens.index[1:])


def verify(data, output, config):
    data,output = Path(data),Path(output)
    audit = Audit()
    _validate_locked_experiment(data,output,config)
    audit.record("all_locked_input_selection_and_checkpoint_hashes",True)
    market = pd.read_csv(data/"market.csv",parse_dates=["date"])
    opens = market.pivot(index="date",columns="ticker",values="open").sort_index()[config["tickers"]]
    closes = market.pivot(index="date",columns="ticker",values="close").sort_index()[config["tickers"]]
    metrics = pd.read_csv(output/"metrics.csv")
    audit.record("metric_rows_unique",not metrics.duplicated(["split","strategy","cost_bps"]).any(),rows=len(metrics))
    audit.record("expected_splits",set(metrics["split"])=={"validation","test"})
    selection = json.loads((output/"selection.json").read_text())
    audit.record("test_explicitly_excluded_from_selection",selection.get("test_used_for_selection") is False)
    search = pd.read_csv(output/"validation_search.csv")
    audit.record("search_uses_only_predeclared_calibration_seed",set(search.seed)=={config["seeds"][0]})
    audit.record("search_has_no_test_score_fields",not any("test" in c.lower() for c in search.columns))
    for family,chosen in selection["selected"].items():
        family_search = search.loc[search.family==family]
        best = family_search.loc[family_search.validation_net_sharpe.idxmax()]
        audit.record(f"selection/{family}/validation_argmax",
                     chosen["risk"]==best.risk and chosen["turnover"]==best.turnover)
        audit.record(f"selection/{family}/all_seeds",
                     sorted(r["seed"] for r in chosen["runs"])==sorted(config["seeds"]))
    # Independently reconstruct the training-only feature scaler.
    returns = closes/closes.shift()-1
    window = config["rolling_window"]
    features = pd.concat({"return":returns,"volatility":returns.rolling(window).std(ddof=1),
                          "momentum":closes/closes.shift(window)-1},axis=1)
    fit = features.loc[config["splits"]["train"][0]:config["splits"]["train"][1]].dropna()
    scaler = json.loads((output/"scaler.json").read_text())
    audit.record("scaler/feature_column_order",scaler["columns"]==[list(c) for c in fit.columns])
    audit.close("scaler/train_only_mean",scaler["mean"],fit.mean().to_numpy())
    audit.close("scaler/train_only_std",scaler["std"],fit.std(ddof=0).clip(lower=1e-6).to_numpy())
    calendars = {}
    prior_end = None
    for split in ["train","validation","test"]:
        start,end = map(pd.Timestamp,config["splits"][split])
        audit.record(f"calendar/{split}/disjoint_split",start<end and (prior_end is None or start>prior_end))
        prior_end = end
        calendar = pd.read_csv(output/f"{split}_calendar.csv",parse_dates=["decision_date","execution_date","end_date"])
        calendars[split] = calendar
        positions = opens.index.get_indexer(calendar.execution_date)
        valid = (positions>0).all()
        decisions = pd.DatetimeIndex(calendar.decision_date)
        audit.record(f"calendar/{split}/previous_close_cutoff",
                     valid and decisions.equals(opens.index[positions-1]))
        audit.record(f"calendar/{split}/labels_stay_inside_split",
                     calendar.execution_date.ge(start).all() and calendar.end_date.le(end).all()
                     and calendar.end_date.gt(calendar.execution_date).all())
        audit.record(f"calendar/{split}/nonoverlapping_holding_labels",
                     calendar.end_date.iloc[:-1].reset_index(drop=True).equals(calendar.execution_date.iloc[1:].reset_index(drop=True)))
    target_count,daily_count,accounting_count = 0,0,0
    strategy_sets = {}
    for split in ["validation","test"]:
        calendar = calendars[split]
        expected_executions = pd.DatetimeIndex(calendar.execution_date)
        expected_daily = opens.loc[expected_executions[0]:calendar.end_date.iloc[-1]].index[1:]
        split_rows = metrics.loc[metrics.split==split]
        strategy_sets[split] = set(split_rows.strategy)
        saved = {}
        risk_free_reference = None
        for name in sorted(strategy_sets[split]):
            targets = pd.read_csv(output/"targets"/split/f"{name}.csv",index_col=0,parse_dates=True)
            target_count += 1
            audit.record(f"targets/{split}/{name}/assets_and_dates",
                         targets.columns.tolist()==config["tickers"] and targets.index.equals(expected_executions))
            values = targets.to_numpy(dtype=float)
            audit.record(f"targets/{split}/{name}/simplex",
                         np.isfinite(values).all() and (values>=-1e-10).all()
                         and np.allclose(values.sum(axis=1),1,atol=1e-7,rtol=0))
            strategy_rows = split_rows.loc[split_rows.strategy==name]
            audit.record(f"daily/{split}/{name}/all_cost_scenarios",
                         set(strategy_rows.cost_bps)==set(config["cost_bps"]))
            for cost in sorted(config["cost_bps"]):
                frame = pd.read_csv(output/"daily"/split/f"{name}_{cost}bps.csv",index_col=0,parse_dates=True)
                daily_count += 1
                saved[(name,cost)] = frame
                label = f"daily/{split}/{name}/{cost}bps"
                audit.record(label+"/common_dates",frame.index.equals(expected_daily) and not frame.index.has_duplicates)
                audit.record(label+"/finite",
                             np.isfinite(frame[["net_return","gross_return","turnover","cost","wealth","risk_free_return"]]).all().all())
                expected_metrics,expected_wealth = independent_metrics(frame)
                audit.close(label+"/wealth_recursion",frame.wealth,expected_wealth)
                reported = strategy_rows.loc[strategy_rows.cost_bps==cost].iloc[0]
                for metric,value in expected_metrics.items():
                    audit.close(label+f"/metric/{metric}",[reported[metric]],[value])
                audit.close(label+"/cost_equals_rate_times_traded_dollars",frame.cost,
                            frame.turnover.to_numpy()*cost/10000,atol=1e-12)
                audit.close(label+"/net_includes_cost",frame.net_return,
                            (1-frame.cost.to_numpy())*(1+frame.gross_return.to_numpy())-1,atol=1e-12)
                if risk_free_reference is None:
                    risk_free_reference = frame.risk_free_return
                else:
                    audit.close(label+"/shared_risk_free",frame.risk_free_return,risk_free_reference)
                if name in ["equal_weight","transformer_full_ensemble","chronos2_synth"]:
                    independently = independent_share_accounting(opens.loc[:calendar.end_date.iloc[-1]],targets,cost)
                    audit.record(label+"/share_accounting_dates",independently.index.equals(frame.index))
                    for field in ["wealth","net_return","gross_return","turnover","cost"]:
                        audit.close(label+f"/independent_cash_share/{field}",frame[field],independently[field],atol=1e-10)
                    accounting_count += 1
            costs = sorted(config["cost_bps"])
            for lower,higher in zip(costs[:-1],costs[1:]):
                low,high = saved[(name,lower)],saved[(name,higher)]
                audit.record(f"cost_sensitivity/{split}/{name}/{lower}_to_{higher}/wealth_monotonic",
                             (high.wealth.to_numpy()<=low.wealth.to_numpy()+1e-10).all())
                audit.close(f"cost_sensitivity/{split}/{name}/{lower}_to_{higher}/same_gross_returns",
                            low.gross_return,high.gross_return)
    audit.record("same_strategy_set_across_splits",strategy_sets["validation"]==strategy_sets["test"])
    bootstrap = json.loads((output/"bootstrap.json").read_text())
    audit.record("bootstrap/primary_comparison_predeclared",
                 bootstrap["primary"]=="transformer_full_ensemble vs transformer_return_ensemble at 10bps")
    for result in bootstrap["comparisons"]:
        label = f"bootstrap/{result['strategy']}"
        audit.record(label+"/valid_inference",
                     result["ci_low"]<=result["ci_high"] and 0<=result["p_value"]<=1
                     and result["valid_bootstrap_draws"]>=.9*config["bootstrap_repetitions"]
                     and result["block_length"]==config["bootstrap_block_length"])
        a = pd.read_csv(output/"daily"/"test"/f"{result['strategy']}_10bps.csv",index_col=0,parse_dates=True)
        b = pd.read_csv(output/"daily"/"test"/f"{result['control']}_10bps.csv",index_col=0,parse_dates=True)
        ma,_ = independent_metrics(a)
        mb,_ = independent_metrics(b)
        audit.close(label+"/difference_matches_daily_returns",[result["sharpe_difference"]],
                    [ma["net_sharpe"]-mb["net_sharpe"]])
    return {
        "generated_utc":datetime.now(timezone.utc).isoformat(),
        "passed":all(c["passed"] for c in audit.checks),
        "checks_passed":sum(c["passed"] for c in audit.checks),
        "checks_total":len(audit.checks),
        "metric_rows":len(metrics),"target_files":target_count,"daily_files":daily_count,
        "independent_cash_share_replays":accounting_count,
        "market_sha256":hashlib.sha256((data/"market.csv").read_bytes()).hexdigest(),
        "risk_free_sha256":hashlib.sha256((data/"risk_free.csv").read_bytes()).hexdigest(),
        "checks":audit.checks,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data",default="data/final_zip")
    parser.add_argument("--output",default="results/full")
    parser.add_argument("--config",default="configs/full.json")
    args = parser.parse_args()
    output = Path(args.output)
    config = json.loads(Path(args.config).read_text())
    try:
        result = verify(args.data,output,config)
    except Exception as exc:
        result = {"generated_utc":datetime.now(timezone.utc).isoformat(),"passed":False,
                  "error_type":type(exc).__name__,"error":str(exc)}
    destination = output/"verification.json"
    temporary = destination.with_name(destination.name+".tmp")
    temporary.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    temporary.replace(destination)
    print(json.dumps({key:value for key,value in result.items() if key!="checks"},indent=2))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
