"""A shared, long-only, self-financing open-to-open portfolio backtester.

``targets`` are indexed by their *execution* date. The caller must construct
them using information available by the preceding close. Daily returns are
indexed by the ending open, so a trade on Monday is charged to Monday-to-
Tuesday's return. The initial state is cash, and initial purchases incur fees.

Costs use total bought plus sold dollars (L1), rather than the half-L1
convention. If ``v`` is the drifted pretrade risky allocation and ``w`` the
target allocation, the post-cost wealth fraction ``mu`` solves
``mu = 1 - c * sum(abs(mu*w - v))``. This accounts for cash spent on fees and
does not assume that trading costs can be financed outside the portfolio.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def cost_factor(target: np.ndarray, drifted: np.ndarray, rate: float) -> float:
    """Return post-fee/pre-fee wealth; initial all-cash state is a zero vector."""
    target = np.asarray(target, dtype=float)
    drifted = np.asarray(drifted, dtype=float)
    if not 0 <= rate < 1:
        raise ValueError("Proportional transaction-cost rate must be in [0, 1).")
    if rate == 0:
        return 1.0
    low, high = 0.0, 1.0
    # Continuous, strictly increasing for c<1. Bisection is also robust at
    # the absolute-value kinks where a traded position changes direction.
    for _ in range(60):
        mid = (low + high) / 2
        residual = mid + rate * np.abs(mid * target - drifted).sum() - 1
        if residual > 0:
            high = mid
        else:
            low = mid
    return (low + high) / 2


def _validate(open_prices: pd.DataFrame, targets: pd.DataFrame) -> None:
    for name, frame in (("open_prices", open_prices), ("targets", targets)):
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            raise ValueError(f"{name} must be a nonempty pandas DataFrame.")
        if not isinstance(frame.index, pd.DatetimeIndex):
            raise ValueError(f"{name} must have a DatetimeIndex.")
        if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
            raise ValueError(f"{name} dates must be unique and increasing.")
        if not frame.columns.is_unique or not np.isfinite(frame.to_numpy(dtype=float)).all():
            raise ValueError(f"{name} must have unique columns and finite values.")
    if not open_prices.columns.equals(targets.columns):
        raise ValueError("Price and target columns must have the same assets in the same order.")
    if (open_prices.to_numpy(dtype=float) <= 0).any():
        raise ValueError("All adjusted open prices must be positive.")
    weights = targets.to_numpy(dtype=float)
    if (weights < -1e-10).any() or not np.allclose(weights.sum(axis=1), 1, atol=1e-7, rtol=0):
        raise ValueError("Targets must be nonnegative and sum to one.")
    if not targets.index.isin(open_prices.index).all():
        raise ValueError("Every execution date must exist in the price index.")
    if targets.index[-1] >= open_prices.index[-1]:
        raise ValueError("Every target must have at least one subsequent open for valuation.")


def backtest(
    open_prices: pd.DataFrame,
    targets: pd.DataFrame,
    cost_bps: float = 10.0,
) -> pd.DataFrame:
    """Evaluate predetermined execution weights under common fee assumptions.

    Supplying prices beyond the intended evaluation period extends the final
    holding interval. The caller therefore passes prices clipped to the
    valuation endpoint. No trading is performed on dates absent from targets.
    ``turnover`` is traded dollars/pretrade wealth, ``cost`` is the charged
    fraction of pretrade wealth, and ``wealth`` starts from unit cash wealth.
    ``weight_*`` stores risky allocation after the trade and before the day's
    price change; these rows sum to one after initial investment.
    """
    _validate(open_prices, targets)
    rate = float(cost_bps) / 10_000
    if not np.isfinite(rate) or not 0 <= rate < 1:
        raise ValueError("cost_bps must be finite and in [0, 10000).")
    start = open_prices.index.get_loc(targets.index[0])
    values = open_prices.to_numpy(dtype=float)
    rows = []
    drifted = np.zeros(len(open_prices.columns), dtype=float)
    wealth = 1.0
    for i in range(start, len(open_prices) - 1):
        execution_date = open_prices.index[i]
        mu, turnover = 1.0, 0.0
        if execution_date in targets.index:
            target = targets.loc[execution_date].to_numpy(dtype=float)
            mu = cost_factor(target, drifted, rate)
            turnover = float(np.abs(mu * target - drifted).sum())
            weights = target
        else:
            weights = drifted
        relatives = values[i + 1] / values[i]
        portfolio_relative = float(weights @ relatives)
        gross_return = portfolio_relative - 1
        net_return = mu * portfolio_relative - 1
        wealth *= 1 + net_return
        drifted = weights * relatives / portfolio_relative
        row = {
            "execution_date": execution_date,
            "gross_return": gross_return,
            "net_return": net_return,
            "turnover": turnover,
            "cost": 1 - mu,
            "wealth": wealth,
        }
        row.update({f"weight_{asset}": float(w) for asset, w in zip(open_prices.columns, weights)})
        rows.append(row)
    result = pd.DataFrame(rows, index=open_prices.index[start + 1 :])
    result.index.name = "date"
    result.attrs.update({
        "cost_bps": float(cost_bps),
        "turnover_convention": "L1 bought-plus-sold dollars / pretrade wealth",
        "return_convention": "adjusted open-to-open; index is ending session",
        "initial_state": "cash; initial investment charged once; no final liquidation",
    })
    return result
