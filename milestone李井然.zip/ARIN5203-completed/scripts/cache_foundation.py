#!/usr/bin/env python3
"""Download/pin Chronos-2-Synth, then optionally cache causal weekly weights."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import pandas as pd

from portfolio.data import load_market
from portfolio.pretrained import MODEL_ID, download_checkpoint, forecast_weights


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="data", help="Directory containing long-form market.csv")
    parser.add_argument("--prices", help="Alternative wide CSV: date/Date plus asset adjusted-close columns")
    parser.add_argument("--signals", help="CSV with date column of the experiment's actual decision dates")
    parser.add_argument("--start", default="2006-01-01")
    parser.add_argument("--end", default="2025-12-31")
    parser.add_argument("--cache-dir", default="../foundation-cache")
    parser.add_argument("--output-dir", default="results/foundation")
    parser.add_argument("--revision", default="main", help="Commit hash or main; first download records exact hash")
    parser.add_argument("--model-id", default=MODEL_ID)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--batch-size", type=int, default=96)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--download-only", action="store_true")
    args = parser.parse_args()
    if args.download_only:
        _, metadata = download_checkpoint(args.cache_dir, args.model_id, args.revision)
        print(json.dumps(metadata, indent=2, ensure_ascii=False))
        return
    import torch
    torch.set_num_threads(args.threads)
    if args.prices:
        prices = pd.read_csv(args.prices)
        date_column = next((c for c in prices if c.lower() == "date"), None)
        if date_column is None:
            parser.error("--prices needs a date or Date column")
        prices[date_column] = pd.to_datetime(prices[date_column], errors="raise")
        prices = prices.set_index(date_column).sort_index()
    else:
        prices = load_market(args.data_dir)["close"]
    if args.signals:
        signals = pd.DatetimeIndex(pd.read_csv(args.signals, parse_dates=["date"])["date"])
    else:
        # First session of each ISO week executes, previous close decides. A
        # runner should pass --signals to match its split-boundary treatment.
        dates = prices.index
        executions = dates[~dates.to_period("W-SUN").duplicated()]
        executions = executions[(executions >= args.start) & (executions <= args.end)]
        positions = dates.get_indexer(executions)
        signals = dates[positions[positions >= 60] - 1]
    _, metadata = forecast_weights(
        prices, signals, cache_dir=args.cache_dir, output_dir=args.output_dir,
        model_id=args.model_id, revision=args.revision, device=args.device,
        batch_size=args.batch_size,
    )
    print(json.dumps({k: metadata[k] for k in ["decisions", "input_sha256", "checkpoint", "device"]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
