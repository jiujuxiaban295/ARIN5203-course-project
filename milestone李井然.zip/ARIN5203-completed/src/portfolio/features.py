"""Causal close-time features and next-open, non-overlapping weekly labels."""
from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class WeeklySamples:
    x: np.ndarray
    returns: np.ndarray
    execution_dates: pd.DatetimeIndex
    decision_dates: pd.DatetimeIndex
    end_dates: pd.DatetimeIndex
    assets: list[str]


def make_features(close: pd.DataFrame, rolling_window: int = 20) -> pd.DataFrame:
    returns = close.pct_change(fill_method=None)
    volatility = returns.rolling(rolling_window, min_periods=rolling_window).std(ddof=1)
    momentum = close / close.shift(rolling_window) - 1
    return pd.concat({"return": returns, "volatility": volatility, "momentum": momentum}, axis=1)


class TrainScaler:
    def fit(self, features: pd.DataFrame, start: str, end: str):
        fit = features.loc[start:end].dropna()
        if len(fit) < 60:
            raise ValueError("Insufficient training features")
        self.mean = fit.mean()
        self.std = fit.std(ddof=0).clip(lower=1e-6)
        self.fit_start = str(fit.index.min().date())
        self.fit_end = str(fit.index.max().date())
        return self

    def transform(self, features: pd.DataFrame) -> pd.DataFrame:
        if not features.columns.equals(self.mean.index):
            raise ValueError("Feature order differs from fitted training scaler")
        return (features - self.mean) / self.std

    def state(self):
        return {"columns": [list(c) for c in self.mean.index], "mean": self.mean.tolist(),
                "std": self.std.tolist(), "fit_start": self.fit_start, "fit_end": self.fit_end}


def weekly_samples(open_prices: pd.DataFrame, features: pd.DataFrame,
                   start: str, end: str, lookback: int = 60) -> WeeklySamples:
    """Trade first available session of ISO week, using previous session's close.

    The final week's label is truncated at the final observed open in the split;
    no label ever uses an open from another split. The daily final close cannot
    be valued in an open-to-open backtest and is deliberately outside coverage.
    """
    if not open_prices.index.equals(features.index):
        raise ValueError("Price and feature calendars must match")
    idx = open_prices.index
    dates = idx[(idx >= pd.Timestamp(start)) & (idx <= pd.Timestamp(end))]
    if len(dates) < 2:
        raise ValueError("Split has fewer than two price sessions")
    week = dates.to_period("W-SUN")
    executions = dates[~week.duplicated()]
    xs, ys, ds, es, ends = [], [], [], [], []
    for i, execution in enumerate(executions):
        endpoint = executions[i + 1] if i + 1 < len(executions) else dates[-1]
        pos = idx.get_loc(execution)
        if pos < lookback or endpoint <= execution:
            continue
        history = features.iloc[pos-lookback:pos]
        if not np.isfinite(history.to_numpy()).all():
            continue
        xs.append(history.to_numpy(dtype=np.float32))
        ys.append((open_prices.loc[endpoint] / open_prices.loc[execution] - 1).to_numpy(dtype=np.float32))
        ds.append(idx[pos-1]); es.append(execution); ends.append(endpoint)
    if not xs:
        raise ValueError("No complete causal weekly samples")
    return WeeklySamples(np.stack(xs), np.stack(ys), pd.DatetimeIndex(es),
                         pd.DatetimeIndex(ds), pd.DatetimeIndex(ends), list(open_prices.columns))
